'use strict';

const { app, BrowserWindow, shell, Menu, dialog } = require('electron');
const path = require('path');
const http = require('http');
const { pathToFileURL } = require('url');

const PORT = 5000;
let mainWindow = null;

function waitForServer(maxAttempts = 40) {
  return new Promise((resolve, reject) => {
    let attempts = 0;
    const attempt = () => {
      const req = http.get(`http://127.0.0.1:${PORT}/api/whatsapp/status`, (res) => {
        resolve();
      });
      req.on('error', () => {
        attempts++;
        if (attempts < maxAttempts) {
          setTimeout(attempt, 800);
        } else {
          reject(new Error('Server did not start in time'));
        }
      });
      req.setTimeout(1500, () => { req.destroy(); });
      req.end();
    };
    attempt();
  });
}

async function startServer() {
  // Set env before importing server so it picks up ELECTRON_USER_DATA
  const userDataPath = app.getPath('userData');
  process.env.NODE_ENV = 'production';
  process.env.PORT = String(PORT);
  process.env.ELECTRON_USER_DATA = userDataPath;

  const serverPath = app.isPackaged
    ? path.join(process.resourcesPath, 'app', 'dist', 'index.js')
    : path.join(__dirname, '..', 'dist', 'index.js');

  console.log('[Electron] Loading server from:', serverPath);

  try {
    await import(pathToFileURL(serverPath).href);
    console.log('[Electron] Server started');
  } catch (err) {
    console.error('[Electron] Failed to start server:', err.message);
    dialog.showErrorBox(
      'BulkSender Pro — Startup Error',
      `Failed to start the server:\n${err.message}\n\nMake sure you ran "npm run build" before launching.`
    );
    app.quit();
  }
}

async function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1440,
    height: 900,
    minWidth: 1024,
    minHeight: 700,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
    },
    title: 'BulkSender Pro',
    show: false,
    backgroundColor: '#0f172a',
  });

  Menu.setApplicationMenu(null);

  console.log('[Electron] Waiting for server...');
  try {
    await waitForServer();
    console.log('[Electron] Server ready — loading app');
  } catch (e) {
    console.error('[Electron] Server wait timed out:', e.message);
  }

  mainWindow.loadURL(`http://127.0.0.1:${PORT}`);

  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
    mainWindow.focus();
  });

  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

app.whenReady().then(async () => {
  await startServer();
  await createWindow();

  app.on('activate', () => {
    if (mainWindow === null) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});
