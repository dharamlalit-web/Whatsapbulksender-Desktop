@echo off
setlocal EnableDelayedExpansion
title BulkSender Pro - Setup ^& Launch
color 0A

echo.
echo  ============================================
echo    BulkSender Pro - One-Click Launcher
echo  ============================================
echo.

:: ── Always run from the folder where this bat file lives ──────────────────────
cd /d "%~dp0"

:: ── STEP 1: Get Node.js (portable — no system install needed) ─────────────────
echo [1/3] Checking Node.js...

if exist "node_runtime\node.exe" (
  echo [OK] Node.js ready
  goto node_ready
)

echo [INFO] Setting up Node.js for the first time ^(~30 MB, one-time download^)...
echo.

set "NODE_ZIP=%~dp0node_runtime.zip"
set "NODE_URL=https://nodejs.org/dist/v22.17.0/node-v22.17.0-win-x64.zip"
set "NODE_FOLDER=node-v22.17.0-win-x64"

echo [INFO] Downloading Node.js...
curl.exe -L --progress-bar -o "%NODE_ZIP%" "%NODE_URL%"
if errorlevel 1 (
  echo [WARN] curl failed, trying PowerShell...
  powershell -NoProfile -ExecutionPolicy Bypass -Command ^
    "[Net.ServicePointManager]::SecurityProtocol='Tls12'; (New-Object Net.WebClient).DownloadFile('%NODE_URL%','%NODE_ZIP%')"
)

if not exist "%NODE_ZIP%" (
  echo.
  echo [ERROR] Download failed. Check your internet connection and try again.
  pause & exit /b 1
)

echo [INFO] Extracting Node.js...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "Expand-Archive -LiteralPath '%NODE_ZIP%' -DestinationPath '%~dp0node_extract' -Force"

if not exist "%~dp0node_extract\%NODE_FOLDER%\node.exe" (
  echo [ERROR] Extraction failed.
  del "%NODE_ZIP%" >nul 2>&1
  rmdir /s /q "%~dp0node_extract" >nul 2>&1
  pause & exit /b 1
)

move "%~dp0node_extract\%NODE_FOLDER%" "%~dp0node_runtime" >nul
rmdir /s /q "%~dp0node_extract" >nul 2>&1
del "%NODE_ZIP%" >nul 2>&1

echo [OK] Node.js ready

:node_ready
set "PATH=%~dp0node_runtime;%~dp0node_runtime\node_modules\.bin;%PATH%"
set "ELECTRON_SKIP_BINARY_DOWNLOAD=1"
echo.

:: ── STEP 2: Install server packages only (no build needed — app is pre-built) ──
echo [2/3] Checking server packages...

if not exist "node_modules\express" (
  echo [INFO] Installing server packages ^(2-4 minutes^)...
  echo        Downloading packages — screen will show progress below.
  echo        Do NOT close this window.
  echo.
  node_runtime\npm.cmd install --omit=dev --ignore-scripts --loglevel=http 2^>^&1
  if errorlevel 1 (
    echo.
    echo [ERROR] Package install failed.
    pause & exit /b 1
  )
  echo.
  echo [OK] Packages installed
) else (
  echo [OK] Packages ready
)
echo.

:: ── STEP 3: Launch ────────────────────────────────────────────────────────────
echo [3/3] Starting BulkSender Pro...
echo.
echo  App will open in your browser at: http://localhost:5000
echo  Keep this window open while using the app.
echo  To quit: press Ctrl+C here, then close this window.
echo.
echo  ============================================
echo.

start "" /B cmd /c "timeout /t 4 /nobreak >nul && start http://localhost:5000"

set "NODE_ENV=production"
node_runtime\node.exe dist/index.js

echo.
echo  BulkSender Pro has exited.
pause
