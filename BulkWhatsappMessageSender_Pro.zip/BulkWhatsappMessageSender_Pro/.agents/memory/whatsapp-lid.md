---
name: WhatsApp LID sending fix
description: How to send messages correctly in whatsapp-web.js with multi-device protocol
---

WhatsApp's multi-device protocol assigns every user a Linked Device ID (LID) like `231516051349510@lid`. Sending to `PHONE@c.us` fails with "No LID for user" because the routing system requires the LID.

**The fix:**
```typescript
const numberId = await (client as any).getNumberId(cleanPhone);
if (!numberId) throw new Error(`${cleanPhone} is not registered on WhatsApp`);
await client.sendMessage(numberId._serialized, message); // e.g. "231516051349510@lid"
```

**Why:** `getNumberId()` returns the correct serialized ID (`@lid` for multi-device users, `@c.us` for legacy). Using this directly bypasses the LID resolution step that fails when you hardcode `@c.us`.

**How to apply:** Always call `getNumberId()` before `sendMessage()`. Never construct `PHONE@c.us` manually for sending.

**Note:** `getNumberId()` returns `null` if the number is not on WhatsApp — use this to mark contacts as failed gracefully.

**whatsapp-web.js version:** 1.34.7 with puppeteer 24.38.0 on Chromium at `/nix/store/zi4f80l169xlmivz8vja8wlphq74qqk0-chromium-125.0.6422.141/bin/chromium`.

**tsx caching issue:** When editing backend TypeScript files, `tsx` sometimes serves stale compiled code even after file saves. A manual `restart_workflow` call is required to force fresh compilation.
