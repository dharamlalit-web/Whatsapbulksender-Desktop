import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, jsonb, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const contacts = pgTable("contacts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  phone: text("phone").notNull(),
  company: text("company"),
  email: text("email"),
  customFields: jsonb("custom_fields"),
  isWhatsAppVerified: boolean("is_whatsapp_verified").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const templates = pgTable("templates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  content: text("content").notNull(),
  variables: jsonb("variables"), // Array of variable names used in template
  category: text("category").default("general"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const campaigns = pgTable("campaigns", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  templateId: varchar("template_id").references(() => templates.id),
  message: text("message").notNull(),
  contactIds: jsonb("contact_ids").notNull(), // Array of contact IDs
  status: text("status").notNull().default("pending"), // pending, running, paused, completed, failed
  sendingPace: text("sending_pace").notNull().default("medium"), // slow, medium, fast
  delaySeconds: integer("delay_seconds").default(5), // custom delay in seconds (overrides sendingPace)
  scheduledAt: timestamp("scheduled_at"),
  startedAt: timestamp("started_at"),
  completedAt: timestamp("completed_at"),
  totalContacts: integer("total_contacts").notNull(),
  sentCount: integer("sent_count").default(0),
  deliveredCount: integer("delivered_count").default(0),
  failedCount: integer("failed_count").default(0),
  // Media attachment (stored as base64 for in-memory compatibility)
  mediaBase64: text("media_base64"),
  mediaFilename: text("media_filename"),
  mediaMimeType: text("media_mime_type"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const messageLogs = pgTable("message_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  campaignId: varchar("campaign_id").references(() => campaigns.id),
  contactId: varchar("contact_id").references(() => contacts.id),
  contactName: text("contact_name"),
  contactPhone: text("contact_phone"),
  message: text("message").notNull(),
  status: text("status").notNull().default("pending"), // pending, sent, delivered, failed
  error: text("error"),
  sentAt: timestamp("sent_at"),
  deliveredAt: timestamp("delivered_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const contactLists = pgTable("contact_lists", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  filename: text("filename"),
  contactCount: integer("contact_count").notNull(),
  uploadedAt: timestamp("uploaded_at").defaultNow(),
});

// Insert schemas
export const insertContactSchema = createInsertSchema(contacts).omit({
  id: true,
  createdAt: true,
});

export const insertTemplateSchema = createInsertSchema(templates).omit({
  id: true,
  createdAt: true,
});

export const insertCampaignSchema = createInsertSchema(campaigns, {
  scheduledAt: z.coerce.date().nullable().optional(),
}).omit({
  id: true,
  createdAt: true,
  startedAt: true,
  completedAt: true,
});

export const insertMessageLogSchema = createInsertSchema(messageLogs).omit({
  id: true,
  createdAt: true,
  deliveredAt: true,
});

export const insertContactListSchema = createInsertSchema(contactLists).omit({
  id: true,
  uploadedAt: true,
});

// Types
export type Contact = typeof contacts.$inferSelect;
export type InsertContact = z.infer<typeof insertContactSchema>;

export type Template = typeof templates.$inferSelect;
export type InsertTemplate = z.infer<typeof insertTemplateSchema>;

export type Campaign = typeof campaigns.$inferSelect;
export type InsertCampaign = z.infer<typeof insertCampaignSchema>;

export type MessageLog = typeof messageLogs.$inferSelect;
export type InsertMessageLog = z.infer<typeof insertMessageLogSchema>;

export type ContactList = typeof contactLists.$inferSelect;
export type InsertContactList = z.infer<typeof insertContactListSchema>;
