import {
  type Contact,
  type InsertContact,
  type Template,
  type InsertTemplate,
  type Campaign,
  type InsertCampaign,
  type MessageLog,
  type InsertMessageLog,
  type ContactList,
  type InsertContactList,
  contacts,
  templates,
  campaigns,
  messageLogs,
  contactLists,
} from "@shared/schema";
import { db as _dbMaybe } from "./db";
import { eq, inArray, and, gte, sql } from "drizzle-orm";
import { Low } from "lowdb";
import { JSONFile } from "lowdb/node";
import path from "path";
import fs from "fs";

// DbStorage is only instantiated when db is non-null (DATABASE_URL is set)
const db = _dbMaybe as NonNullable<typeof _dbMaybe>;

export interface IStorage {
  // Contacts
  getContact(id: string): Promise<Contact | undefined>;
  getContactByPhone(phone: string): Promise<Contact | undefined>;
  createContact(contact: InsertContact): Promise<Contact>;
  getContacts(): Promise<Contact[]>;
  getContactsByIds(ids: string[]): Promise<Contact[]>;
  updateContact(id: string, updates: Partial<Contact>): Promise<Contact | undefined>;
  deleteContact(id: string): Promise<boolean>;

  // Templates
  getTemplate(id: string): Promise<Template | undefined>;
  createTemplate(template: InsertTemplate): Promise<Template>;
  getTemplates(): Promise<Template[]>;
  updateTemplate(id: string, updates: Partial<Template>): Promise<Template | undefined>;
  deleteTemplate(id: string): Promise<boolean>;

  // Campaigns
  getCampaign(id: string): Promise<Campaign | undefined>;
  createCampaign(campaign: InsertCampaign): Promise<Campaign>;
  getCampaigns(): Promise<Campaign[]>;
  getActiveCampaigns(): Promise<Campaign[]>;
  updateCampaign(id: string, updates: Partial<Campaign>): Promise<Campaign | undefined>;
  deleteCampaign(id: string): Promise<boolean>;

  // Message Logs
  getMessageLog(id: string): Promise<MessageLog | undefined>;
  createMessageLog(log: InsertMessageLog): Promise<MessageLog>;
  getMessageLogsByCampaign(campaignId: string): Promise<MessageLog[]>;
  updateMessageLog(id: string, updates: Partial<MessageLog>): Promise<MessageLog | undefined>;

  // Contact Lists
  getContactList(id: string): Promise<ContactList | undefined>;
  createContactList(list: InsertContactList, contactIds?: string[]): Promise<ContactList>;
  getContactLists(): Promise<ContactList[]>;
  deleteContactList(id: string): Promise<boolean>;
  getContactsByListId(listId: string): Promise<Contact[]>;

  // Stats
  getDashboardStats(): Promise<{
    messagesSentToday: number;
    deliveryRate: number;
    activeContacts: number;
    campaignSuccess: number;
  }>;
}

// contact_list_members junction table stored as jsonb on contacts via tag.
// We use a separate in-db approach: store list membership in a contacts column.
// Since schema already has contactLists without a junction table, we store
// contactIds array on campaigns and resolve list→contacts via a listId tag on contacts.
// For getContactsByListId we use a JSON query on contacts.customFields.listIds array.

export class DbStorage implements IStorage {
  // Contacts
  async getContact(id: string): Promise<Contact | undefined> {
    const rows = await db.select().from(contacts).where(eq(contacts.id, id));
    return rows[0];
  }

  async getContactByPhone(phone: string): Promise<Contact | undefined> {
    const rows = await db.select().from(contacts).where(eq(contacts.phone, phone));
    return rows[0];
  }

  async createContact(insertContact: InsertContact): Promise<Contact> {
    const rows = await db.insert(contacts).values(insertContact).returning();
    return rows[0];
  }

  async getContacts(): Promise<Contact[]> {
    return db.select().from(contacts);
  }

  async getContactsByIds(ids: string[]): Promise<Contact[]> {
    if (ids.length === 0) return [];
    return db.select().from(contacts).where(inArray(contacts.id, ids));
  }

  async updateContact(id: string, updates: Partial<Contact>): Promise<Contact | undefined> {
    const rows = await db.update(contacts).set(updates).where(eq(contacts.id, id)).returning();
    return rows[0];
  }

  async deleteContact(id: string): Promise<boolean> {
    const rows = await db.delete(contacts).where(eq(contacts.id, id)).returning();
    return rows.length > 0;
  }

  // Templates
  async getTemplate(id: string): Promise<Template | undefined> {
    const rows = await db.select().from(templates).where(eq(templates.id, id));
    return rows[0];
  }

  async createTemplate(insertTemplate: InsertTemplate): Promise<Template> {
    const rows = await db.insert(templates).values(insertTemplate).returning();
    return rows[0];
  }

  async getTemplates(): Promise<Template[]> {
    return db.select().from(templates);
  }

  async updateTemplate(id: string, updates: Partial<Template>): Promise<Template | undefined> {
    const rows = await db.update(templates).set(updates).where(eq(templates.id, id)).returning();
    return rows[0];
  }

  async deleteTemplate(id: string): Promise<boolean> {
    const rows = await db.delete(templates).where(eq(templates.id, id)).returning();
    return rows.length > 0;
  }

  // Campaigns
  async getCampaign(id: string): Promise<Campaign | undefined> {
    const rows = await db.select().from(campaigns).where(eq(campaigns.id, id));
    return rows[0];
  }

  async createCampaign(insertCampaign: InsertCampaign): Promise<Campaign> {
    const rows = await db.insert(campaigns).values({
      ...insertCampaign,
      startedAt: null,
      completedAt: null,
    }).returning();
    return rows[0];
  }

  async getCampaigns(): Promise<Campaign[]> {
    return db.select().from(campaigns);
  }

  async getActiveCampaigns(): Promise<Campaign[]> {
    return db.select().from(campaigns).where(
      sql`${campaigns.status} IN ('running', 'paused')`
    );
  }

  async updateCampaign(id: string, updates: Partial<Campaign>): Promise<Campaign | undefined> {
    const rows = await db.update(campaigns).set(updates).where(eq(campaigns.id, id)).returning();
    return rows[0];
  }

  async deleteCampaign(id: string): Promise<boolean> {
    const rows = await db.delete(campaigns).where(eq(campaigns.id, id)).returning();
    return rows.length > 0;
  }

  // Message Logs
  async getMessageLog(id: string): Promise<MessageLog | undefined> {
    const rows = await db.select().from(messageLogs).where(eq(messageLogs.id, id));
    return rows[0];
  }

  async createMessageLog(insertLog: InsertMessageLog): Promise<MessageLog> {
    const rows = await db.insert(messageLogs).values(insertLog).returning();
    return rows[0];
  }

  async getMessageLogsByCampaign(campaignId: string): Promise<MessageLog[]> {
    return db.select().from(messageLogs).where(eq(messageLogs.campaignId, campaignId));
  }

  async updateMessageLog(id: string, updates: Partial<MessageLog>): Promise<MessageLog | undefined> {
    const rows = await db.update(messageLogs).set(updates).where(eq(messageLogs.id, id)).returning();
    return rows[0];
  }

  // Contact Lists
  async getContactList(id: string): Promise<ContactList | undefined> {
    const rows = await db.select().from(contactLists).where(eq(contactLists.id, id));
    return rows[0];
  }

  async createContactList(insertList: InsertContactList, contactIds?: string[]): Promise<ContactList> {
    const rows = await db.insert(contactLists).values(insertList).returning();
    const list = rows[0];

    // Tag each contact with this list's ID via customFields.listIds
    if (contactIds && contactIds.length > 0) {
      for (const contactId of contactIds) {
        const existing = await this.getContact(contactId);
        if (existing) {
          const cf = (existing.customFields as any) || {};
          const listIds: string[] = cf.listIds || [];
          if (!listIds.includes(list.id)) {
            listIds.push(list.id);
          }
          await this.updateContact(contactId, {
            customFields: { ...cf, listIds },
          });
        }
      }
    }
    return list;
  }

  async getContactLists(): Promise<ContactList[]> {
    return db.select().from(contactLists);
  }

  async deleteContactList(id: string): Promise<boolean> {
    // Delete all contacts that belong only to this list
    const members = await this.getContactsByListId(id);
    for (const contact of members) {
      const cf = (contact.customFields as any) || {};
      const listIds: string[] = (cf.listIds || []).filter((lid: string) => lid !== id);
      if (listIds.length === 0) {
        await this.deleteContact(contact.id);
      } else {
        await this.updateContact(contact.id, { customFields: { ...cf, listIds } });
      }
    }
    const rows = await db.delete(contactLists).where(eq(contactLists.id, id)).returning();
    return rows.length > 0;
  }

  async getContactsByListId(listId: string): Promise<Contact[]> {
    // Contacts tagged with this listId in customFields.listIds
    const all = await this.getContacts();
    return all.filter((c) => {
      const cf = (c.customFields as any) || {};
      return Array.isArray(cf.listIds) && cf.listIds.includes(listId);
    });
  }

  // Stats
  async getDashboardStats(): Promise<{
    messagesSentToday: number;
    deliveryRate: number;
    activeContacts: number;
    campaignSuccess: number;
  }> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const logsToday = await db.select().from(messageLogs).where(gte(messageLogs.createdAt, today));

    const messagesSentToday = logsToday.filter((l) => l.status !== "pending").length;
    const deliveredToday = logsToday.filter((l) => l.status === "delivered").length;
    const deliveryRate = messagesSentToday > 0 ? (deliveredToday / messagesSentToday) * 100 : 0;

    const allContacts = await db.select({ id: contacts.id }).from(contacts);
    const activeContacts = allContacts.length;

    const allCampaigns = await db.select().from(campaigns);
    const completedCampaigns = allCampaigns.filter((c) => c.status === "completed");
    const successfulCampaigns = completedCampaigns.filter(
      (c) => (c.failedCount || 0) < c.totalContacts * 0.1
    );
    const campaignSuccess =
      completedCampaigns.length > 0
        ? (successfulCampaigns.length / completedCampaigns.length) * 100
        : 100;

    return { messagesSentToday, deliveryRate, activeContacts, campaignSuccess };
  }
}

// ─── In-memory storage for desktop/local mode (no DATABASE_URL) ─────────────
export class MemStorage implements IStorage {
  private contacts = new Map<string, Contact>();
  private templates = new Map<string, Template>();
  private campaigns = new Map<string, Campaign>();
  private messageLogs = new Map<string, MessageLog>();
  private contactLists = new Map<string, ContactList>();

  private newId() { return crypto.randomUUID(); }
  private now() { return new Date(); }

  async getContact(id: string) { return this.contacts.get(id); }
  async getContactByPhone(phone: string) {
    return [...this.contacts.values()].find(c => c.phone === phone);
  }
  async createContact(data: InsertContact): Promise<Contact> {
    const c: Contact = { id: this.newId(), createdAt: this.now(), isWhatsAppVerified: false, company: null, email: null, customFields: null, ...data };
    this.contacts.set(c.id, c);
    return c;
  }
  async getContacts() { return [...this.contacts.values()]; }
  async getContactsByIds(ids: string[]) { return ids.map(id => this.contacts.get(id)).filter(Boolean) as Contact[]; }
  async updateContact(id: string, updates: Partial<Contact>) {
    const c = this.contacts.get(id);
    if (!c) return undefined;
    const updated = { ...c, ...updates };
    this.contacts.set(id, updated);
    return updated;
  }
  async deleteContact(id: string) { return this.contacts.delete(id); }

  async getTemplate(id: string) { return this.templates.get(id); }
  async createTemplate(data: InsertTemplate): Promise<Template> {
    const t: Template = { id: this.newId(), createdAt: this.now(), variables: null, category: 'general', ...data };
    this.templates.set(t.id, t);
    return t;
  }
  async getTemplates() { return [...this.templates.values()]; }
  async updateTemplate(id: string, updates: Partial<Template>) {
    const t = this.templates.get(id);
    if (!t) return undefined;
    const updated = { ...t, ...updates };
    this.templates.set(id, updated);
    return updated;
  }
  async deleteTemplate(id: string) { return this.templates.delete(id); }

  async getCampaign(id: string) { return this.campaigns.get(id); }
  async createCampaign(data: InsertCampaign): Promise<Campaign> {
    const c: Campaign = {
      id: this.newId(), createdAt: this.now(),
      startedAt: null, completedAt: null, scheduledAt: null,
      sentCount: 0, deliveredCount: 0, failedCount: 0,
      templateId: null, delaySeconds: 5,
      mediaBase64: null, mediaFilename: null, mediaMimeType: null,
      ...data,
    };
    this.campaigns.set(c.id, c);
    return c;
  }
  async getCampaigns() { return [...this.campaigns.values()]; }
  async getActiveCampaigns() { return [...this.campaigns.values()].filter(c => c.status === 'running' || c.status === 'paused'); }
  async updateCampaign(id: string, updates: Partial<Campaign>) {
    const c = this.campaigns.get(id);
    if (!c) return undefined;
    const updated = { ...c, ...updates };
    this.campaigns.set(id, updated);
    return updated;
  }
  async deleteCampaign(id: string) { return this.campaigns.delete(id); }

  async getMessageLog(id: string) { return this.messageLogs.get(id); }
  async createMessageLog(data: InsertMessageLog): Promise<MessageLog> {
    const l: MessageLog = { id: this.newId(), createdAt: this.now(), sentAt: null, deliveredAt: null, error: null, campaignId: null, contactId: null, ...data };
    this.messageLogs.set(l.id, l);
    return l;
  }
  async getMessageLogsByCampaign(campaignId: string) { return [...this.messageLogs.values()].filter(l => l.campaignId === campaignId); }
  async updateMessageLog(id: string, updates: Partial<MessageLog>) {
    const l = this.messageLogs.get(id);
    if (!l) return undefined;
    const updated = { ...l, ...updates };
    this.messageLogs.set(id, updated);
    return updated;
  }

  async getContactList(id: string) { return this.contactLists.get(id); }
  async createContactList(data: InsertContactList, contactIds?: string[]): Promise<ContactList> {
    const list: ContactList = { id: this.newId(), uploadedAt: this.now(), filename: null, ...data };
    this.contactLists.set(list.id, list);
    if (contactIds?.length) {
      for (const contactId of contactIds) {
        const c = this.contacts.get(contactId);
        if (c) {
          const cf = (c.customFields as any) || {};
          const listIds: string[] = cf.listIds || [];
          if (!listIds.includes(list.id)) listIds.push(list.id);
          await this.updateContact(contactId, { customFields: { ...cf, listIds } });
        }
      }
    }
    return list;
  }
  async getContactLists() { return [...this.contactLists.values()]; }
  async deleteContactList(id: string) {
    const members = await this.getContactsByListId(id);
    for (const c of members) {
      const cf = (c.customFields as any) || {};
      const listIds: string[] = (cf.listIds || []).filter((lid: string) => lid !== id);
      if (listIds.length === 0) { this.contacts.delete(c.id); }
      else { await this.updateContact(c.id, { customFields: { ...cf, listIds } }); }
    }
    return this.contactLists.delete(id);
  }
  async getContactsByListId(listId: string) {
    return [...this.contacts.values()].filter(c => {
      const cf = (c.customFields as any) || {};
      return Array.isArray(cf.listIds) && cf.listIds.includes(listId);
    });
  }

  async getDashboardStats() {
    const today = new Date(); today.setHours(0, 0, 0, 0);
    const logsToday = [...this.messageLogs.values()].filter(l => l.createdAt && l.createdAt >= today);
    const messagesSentToday = logsToday.filter(l => l.status !== 'pending').length;
    const deliveredToday = logsToday.filter(l => l.status === 'delivered').length;
    const deliveryRate = messagesSentToday > 0 ? (deliveredToday / messagesSentToday) * 100 : 0;
    const activeContacts = this.contacts.size;
    const allCampaigns = [...this.campaigns.values()];
    const completed = allCampaigns.filter(c => c.status === 'completed');
    const successful = completed.filter(c => (c.failedCount || 0) < c.totalContacts * 0.1);
    const campaignSuccess = completed.length > 0 ? (successful.length / completed.length) * 100 : 100;
    return { messagesSentToday, deliveryRate, activeContacts, campaignSuccess };
  }
}

// ─── Helpers ─────────────────────────────────────────────────────────────────
function toDate(val: any): Date | null {
  if (!val) return null;
  if (val instanceof Date) return val;
  const d = new Date(val);
  return isNaN(d.getTime()) ? null : d;
}
function newId() { return crypto.randomUUID(); }
function now() { return new Date(); }

type DbSchema = {
  contacts: Contact[];
  templates: Template[];
  campaigns: Campaign[];
  messageLogs: MessageLog[];
  contactLists: ContactList[];
};

const DEFAULT_DATA: DbSchema = {
  contacts: [],
  templates: [],
  campaigns: [],
  messageLogs: [],
  contactLists: [],
};

// ─── File-based storage using lowdb (persists across restarts) ───────────────
export class LowdbStorage implements IStorage {
  private db!: Low<DbSchema>;
  private ready: Promise<void>;

  constructor() {
    const dataDir = process.env.ELECTRON_USER_DATA || process.cwd();
    const file = path.join(dataDir, "bulksender_data.json");
    const adapter = new JSONFile<DbSchema>(file);
    this.db = new Low<DbSchema>(adapter, DEFAULT_DATA);
    this.ready = this.db.read().then(() => {
      // Ensure all collections exist (forward-compatible with older files)
      this.db.data.contacts     ??= [];
      this.db.data.templates    ??= [];
      this.db.data.campaigns    ??= [];
      this.db.data.messageLogs  ??= [];
      this.db.data.contactLists ??= [];
    });
  }

  private async r<T>(fn: (d: DbSchema) => T): Promise<T> {
    await this.ready;
    return fn(this.db.data);
  }
  private async w<T>(fn: (d: DbSchema) => T): Promise<T> {
    await this.ready;
    const result = fn(this.db.data);
    await this.db.write();
    return result;
  }

  // Dates come back from JSON as strings — fix them on read
  private fixContact(c: any): Contact {
    return { ...c, createdAt: toDate(c.createdAt) };
  }
  private fixTemplate(t: any): Template {
    return { ...t, createdAt: toDate(t.createdAt) };
  }
  private fixCampaign(c: any): Campaign {
    return { ...c, createdAt: toDate(c.createdAt), startedAt: toDate(c.startedAt), completedAt: toDate(c.completedAt), scheduledAt: toDate(c.scheduledAt) };
  }
  private fixLog(l: any): MessageLog {
    return { ...l, createdAt: toDate(l.createdAt), sentAt: toDate(l.sentAt), deliveredAt: toDate(l.deliveredAt) };
  }
  private fixList(l: any): ContactList {
    return { ...l, uploadedAt: toDate(l.uploadedAt) };
  }

  // ── Contacts ──────────────────────────────────────────────────────────────
  async getContact(id: string) {
    return this.r(d => { const c = d.contacts.find(c => c.id === id); return c ? this.fixContact(c) : undefined; });
  }
  async getContactByPhone(phone: string) {
    return this.r(d => { const c = d.contacts.find(c => c.phone === phone); return c ? this.fixContact(c) : undefined; });
  }
  async createContact(data: InsertContact): Promise<Contact> {
    return this.w(d => {
      const c: Contact = { id: newId(), createdAt: now(), isWhatsAppVerified: false, company: null, email: null, customFields: null, ...data };
      d.contacts.push(c);
      return c;
    });
  }
  async getContacts() {
    return this.r(d => d.contacts.map(c => this.fixContact(c)));
  }
  async getContactsByIds(ids: string[]) {
    return this.r(d => d.contacts.filter(c => ids.includes(c.id)).map(c => this.fixContact(c)));
  }
  async updateContact(id: string, updates: Partial<Contact>) {
    return this.w(d => {
      const i = d.contacts.findIndex(c => c.id === id);
      if (i === -1) return undefined;
      d.contacts[i] = { ...d.contacts[i], ...updates };
      return this.fixContact(d.contacts[i]);
    });
  }
  async deleteContact(id: string) {
    return this.w(d => {
      const i = d.contacts.findIndex(c => c.id === id);
      if (i === -1) return false;
      d.contacts.splice(i, 1);
      return true;
    });
  }

  // ── Templates ─────────────────────────────────────────────────────────────
  async getTemplate(id: string) {
    return this.r(d => { const t = d.templates.find(t => t.id === id); return t ? this.fixTemplate(t) : undefined; });
  }
  async createTemplate(data: InsertTemplate): Promise<Template> {
    return this.w(d => {
      const t: Template = { id: newId(), createdAt: now(), variables: null, category: 'general', ...data };
      d.templates.push(t);
      return t;
    });
  }
  async getTemplates() {
    return this.r(d => d.templates.map(t => this.fixTemplate(t)));
  }
  async updateTemplate(id: string, updates: Partial<Template>) {
    return this.w(d => {
      const i = d.templates.findIndex(t => t.id === id);
      if (i === -1) return undefined;
      d.templates[i] = { ...d.templates[i], ...updates };
      return this.fixTemplate(d.templates[i]);
    });
  }
  async deleteTemplate(id: string) {
    return this.w(d => {
      const i = d.templates.findIndex(t => t.id === id);
      if (i === -1) return false;
      d.templates.splice(i, 1);
      return true;
    });
  }

  // ── Campaigns ─────────────────────────────────────────────────────────────
  async getCampaign(id: string) {
    return this.r(d => { const c = d.campaigns.find(c => c.id === id); return c ? this.fixCampaign(c) : undefined; });
  }
  async createCampaign(data: InsertCampaign): Promise<Campaign> {
    return this.w(d => {
      const c: Campaign = {
        id: newId(), createdAt: now(),
        startedAt: null, completedAt: null, scheduledAt: null,
        sentCount: 0, deliveredCount: 0, failedCount: 0,
        templateId: null, delaySeconds: 5,
        mediaBase64: null, mediaFilename: null, mediaMimeType: null,
        ...data,
      };
      d.campaigns.push(c);
      return c;
    });
  }
  async getCampaigns() {
    return this.r(d => d.campaigns.map(c => this.fixCampaign(c)));
  }
  async getActiveCampaigns() {
    return this.r(d => d.campaigns.filter(c => c.status === 'running' || c.status === 'paused').map(c => this.fixCampaign(c)));
  }
  async updateCampaign(id: string, updates: Partial<Campaign>) {
    return this.w(d => {
      const i = d.campaigns.findIndex(c => c.id === id);
      if (i === -1) return undefined;
      d.campaigns[i] = { ...d.campaigns[i], ...updates };
      return this.fixCampaign(d.campaigns[i]);
    });
  }
  async deleteCampaign(id: string) {
    return this.w(d => {
      const i = d.campaigns.findIndex(c => c.id === id);
      if (i === -1) return false;
      d.campaigns.splice(i, 1);
      return true;
    });
  }

  // ── Message Logs ──────────────────────────────────────────────────────────
  async getMessageLog(id: string) {
    return this.r(d => { const l = d.messageLogs.find(l => l.id === id); return l ? this.fixLog(l) : undefined; });
  }
  async createMessageLog(data: InsertMessageLog): Promise<MessageLog> {
    return this.w(d => {
      const l: MessageLog = {
        id: newId(), createdAt: now(),
        sentAt: null, deliveredAt: null,
        error: null, campaignId: null, contactId: null,
        contactName: null, contactPhone: null,
        ...data,
      };
      d.messageLogs.push(l);
      return l;
    });
  }
  async getMessageLogsByCampaign(campaignId: string) {
    return this.r(d => d.messageLogs.filter(l => l.campaignId === campaignId).map(l => this.fixLog(l)));
  }
  async updateMessageLog(id: string, updates: Partial<MessageLog>) {
    return this.w(d => {
      const i = d.messageLogs.findIndex(l => l.id === id);
      if (i === -1) return undefined;
      d.messageLogs[i] = { ...d.messageLogs[i], ...updates };
      return this.fixLog(d.messageLogs[i]);
    });
  }

  // ── Contact Lists ─────────────────────────────────────────────────────────
  async getContactList(id: string) {
    return this.r(d => { const l = d.contactLists.find(l => l.id === id); return l ? this.fixList(l) : undefined; });
  }
  async createContactList(data: InsertContactList, contactIds?: string[]): Promise<ContactList> {
    const list = await this.w(d => {
      const l: ContactList = { id: newId(), uploadedAt: now(), filename: null, ...data };
      d.contactLists.push(l);
      return l;
    });
    if (contactIds?.length) {
      for (const contactId of contactIds) {
        const c = await this.getContact(contactId);
        if (c) {
          const cf = (c.customFields as any) || {};
          const listIds: string[] = cf.listIds || [];
          if (!listIds.includes(list.id)) listIds.push(list.id);
          await this.updateContact(contactId, { customFields: { ...cf, listIds } });
        }
      }
    }
    return list;
  }
  async getContactLists() {
    return this.r(d => d.contactLists.map(l => this.fixList(l)));
  }
  async deleteContactList(id: string) {
    const members = await this.getContactsByListId(id);
    for (const c of members) {
      const cf = (c.customFields as any) || {};
      const listIds: string[] = (cf.listIds || []).filter((lid: string) => lid !== id);
      if (listIds.length === 0) { await this.deleteContact(c.id); }
      else { await this.updateContact(c.id, { customFields: { ...cf, listIds } }); }
    }
    return this.w(d => {
      const i = d.contactLists.findIndex(l => l.id === id);
      if (i === -1) return false;
      d.contactLists.splice(i, 1);
      return true;
    });
  }
  async getContactsByListId(listId: string) {
    return this.r(d => d.contacts.filter(c => {
      const cf = (c.customFields as any) || {};
      return Array.isArray(cf.listIds) && cf.listIds.includes(listId);
    }).map(c => this.fixContact(c)));
  }

  // ── Stats ─────────────────────────────────────────────────────────────────
  async getDashboardStats() {
    return this.r(d => {
      const today = new Date(); today.setHours(0, 0, 0, 0);
      const logsToday = d.messageLogs.filter(l => {
        const created = toDate(l.createdAt);
        return created && created >= today;
      });
      const messagesSentToday = logsToday.filter(l => l.status !== 'pending').length;
      const deliveredToday = logsToday.filter(l => l.status === 'delivered').length;
      const deliveryRate = messagesSentToday > 0 ? (deliveredToday / messagesSentToday) * 100 : 0;
      const activeContacts = d.contacts.length;
      const completed = d.campaigns.filter(c => c.status === 'completed');
      const successful = completed.filter(c => (c.failedCount || 0) < c.totalContacts * 0.1);
      const campaignSuccess = completed.length > 0 ? (successful.length / completed.length) * 100 : 100;
      return { messagesSentToday, deliveryRate, activeContacts, campaignSuccess };
    });
  }
}

export const storage: IStorage = _dbMaybe ? new DbStorage() : new LowdbStorage();
