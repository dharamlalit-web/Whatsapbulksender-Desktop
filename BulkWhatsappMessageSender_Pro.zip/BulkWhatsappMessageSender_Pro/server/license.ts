import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import { execFileSync } from 'child_process';

// ─── KEEP THIS SECRET — never share or commit to public repos ─────────────────
const MASTER_SECRET = 'BSP_MASTER_KEY_2026_XK9Q7R3M_V1';

// ─── Windows Registry helpers (no-op on non-Windows) ─────────────────────────
const REG_KEY = 'HKCU\\Software\\BulkSenderPro';
const IS_WINDOWS = process.platform === 'win32';

function regRead(name: string): number | null {
  if (!IS_WINDOWS) return null;
  try {
    const out = execFileSync('reg', ['query', REG_KEY, '/v', name], {
      encoding: 'utf8',
      timeout: 3000,
    });
    // Output line looks like:  "    TotalSent    REG_DWORD    0x7d0"
    const match = out.match(/REG_(?:DWORD|QWORD|SZ)\s+(\S+)/);
    if (match) {
      const raw = match[1];
      // DWORD values come as hex (0x…), SZ as decimal string
      return parseInt(raw, raw.startsWith('0x') ? 16 : 10);
    }
  } catch {
    // key or value missing — treat as not present
  }
  return null;
}

function regWrite(name: string, value: number): void {
  if (!IS_WINDOWS) return;
  try {
    execFileSync(
      'reg',
      ['add', REG_KEY, '/v', name, '/t', 'REG_DWORD', '/d', String(value), '/f'],
      { timeout: 3000 }
    );
  } catch (e) {
    console.warn('[License] Registry write failed:', e);
  }
}
export const FREE_LIMIT = 2000;

export interface LicenseData {
  totalSent: number;
  dailySent: number;
  lastResetDate: string;
  key: string | null;
  activatedAt: string | null;
  expiresAt: string | null;
  dailyLimit: number;
}

export interface LicenseStatus {
  totalSent: number;
  dailySent: number;
  dailyLimit: number;
  freeLimit: number;
  freeRemaining: number;
  hasKey: boolean;
  isExpired: boolean;
  isLicensed: boolean;
  blocked: boolean;
  blockReason: string | null;
  key: string | null;
  activatedAt: string | null;
  expiresAt: string | null;
}

function getLicenseFilePath(): string {
  const dir = process.env.ELECTRON_USER_DATA || process.cwd();
  return path.join(dir, 'bsp_license.json');
}

function loadLicense(): LicenseData {
  let fileData: LicenseData | null = null;
  try {
    const fp = getLicenseFilePath();
    if (fs.existsSync(fp)) {
      fileData = JSON.parse(fs.readFileSync(fp, 'utf8')) as LicenseData;
    }
  } catch {}

  // Read the registry backup counter (Windows only)
  const regTotal = regRead('TotalSent');

  if (fileData) {
    // Take the higher of file vs registry so deleting the file doesn't reset the counter
    if (regTotal !== null && regTotal > fileData.totalSent) {
      console.log(
        `[License] Registry counter (${regTotal}) is higher than file (${fileData.totalSent}). Using registry value.`
      );
      fileData.totalSent = regTotal;
    }
    return fileData;
  }

  // File missing — bootstrap from registry if available
  const bootstrapTotal = regTotal ?? 0;
  if (bootstrapTotal > 0) {
    console.log(`[License] License file missing; restoring totalSent=${bootstrapTotal} from registry.`);
  }
  return {
    totalSent: bootstrapTotal,
    dailySent: 0,
    lastResetDate: new Date().toISOString().split('T')[0],
    key: null,
    activatedAt: null,
    expiresAt: null,
    dailyLimit: 0,
  };
}

function saveLicense(data: LicenseData): void {
  try {
    fs.writeFileSync(getLicenseFilePath(), JSON.stringify(data, null, 2), 'utf8');
  } catch (e) {
    console.error('[License] Failed to save file:', e);
  }
  // Always mirror the total message count to the registry as a tamper-resistant backup
  regWrite('TotalSent', data.totalSent);
}

function resetDailyIfNeeded(data: LicenseData): LicenseData {
  const today = new Date().toISOString().split('T')[0];
  if (data.lastResetDate !== today) {
    data.dailySent = 0;
    data.lastResetDate = today;
    saveLicense(data);
  }
  return data;
}

// ─── Parse & validate a key string ───────────────────────────────────────────
export function parseKey(keyStr: string): {
  valid: boolean;
  dailyLimit: number;
  expiryDays: number;
  error?: string;
} {
  try {
    const normalized = keyStr.trim().toUpperCase();
    const parts = normalized.split('-');
    if (parts.length !== 3 || parts[0] !== 'BSP') {
      return { valid: false, dailyLimit: 0, expiryDays: 0, error: 'Invalid key format. Expected BSP-XXXXX-XXXXXX' };
    }
    const [, hexPayload, providedHmac] = parts;

    const expectedHmac = crypto
      .createHmac('sha256', MASTER_SECRET)
      .update(hexPayload)
      .digest('hex')
      .substring(0, 8)
      .toUpperCase();

    if (expectedHmac !== providedHmac) {
      return { valid: false, dailyLimit: 0, expiryDays: 0, error: 'Key is invalid or has been tampered with' };
    }

    const payload = Buffer.from(hexPayload, 'hex').toString('utf8');
    const [dailyLimitStr, expiryDaysStr] = payload.split(':');
    const dailyLimit = parseInt(dailyLimitStr, 10);
    const expiryDays = parseInt(expiryDaysStr, 10);

    if (isNaN(dailyLimit) || isNaN(expiryDays) || dailyLimit < 0 || expiryDays < 1) {
      return { valid: false, dailyLimit: 0, expiryDays: 0, error: 'Corrupted key data' };
    }

    return { valid: true, dailyLimit, expiryDays };
  } catch {
    return { valid: false, dailyLimit: 0, expiryDays: 0, error: 'Key parse error' };
  }
}

// ─── Public API ───────────────────────────────────────────────────────────────
export function getLicenseStatus(): LicenseStatus {
  let data = loadLicense();
  data = resetDailyIfNeeded(data);

  const now = new Date();
  const hasKey = !!data.key;
  const isExpired = hasKey && !!data.expiresAt && new Date(data.expiresAt) < now;
  const isLicensed = hasKey && !isExpired;

  let blocked = false;
  let blockReason: string | null = null;

  if (isExpired) {
    blocked = true;
    blockReason = 'Your license key has expired. Enter a new key to continue.';
  } else if (!isLicensed && data.totalSent >= FREE_LIMIT) {
    blocked = true;
    blockReason = `Free trial limit of ${FREE_LIMIT} messages reached.`;
  } else if (isLicensed && data.dailyLimit > 0 && data.dailySent >= data.dailyLimit) {
    blocked = true;
    blockReason = `Daily limit of ${data.dailyLimit} messages reached. Resets at midnight.`;
  }

  return {
    totalSent: data.totalSent,
    dailySent: data.dailySent,
    dailyLimit: isLicensed ? data.dailyLimit : 0,
    freeLimit: FREE_LIMIT,
    freeRemaining: Math.max(0, FREE_LIMIT - data.totalSent),
    hasKey,
    isExpired,
    isLicensed,
    blocked,
    blockReason,
    key: data.key,
    activatedAt: data.activatedAt,
    expiresAt: data.expiresAt,
  };
}

export function recordMessagesSent(count: number = 1): void {
  let data = loadLicense();
  data = resetDailyIfNeeded(data);
  data.totalSent += count;
  data.dailySent += count;
  saveLicense(data);
}

export function activateLicense(keyStr: string): {
  success: boolean;
  error?: string;
  expiresAt?: string;
  dailyLimit?: number;
  expiryDays?: number;
} {
  const parsed = parseKey(keyStr);
  if (!parsed.valid) {
    return { success: false, error: parsed.error };
  }

  let data = loadLicense();
  const expiresAt = new Date(Date.now() + parsed.expiryDays * 24 * 60 * 60 * 1000).toISOString();

  data.key = keyStr.trim().toUpperCase();
  data.activatedAt = new Date().toISOString();
  data.expiresAt = expiresAt;
  data.dailyLimit = parsed.dailyLimit;
  data.dailySent = 0; // reset daily counter on new activation

  saveLicense(data);
  return { success: true, expiresAt, dailyLimit: parsed.dailyLimit, expiryDays: parsed.expiryDays };
}
