import pkg from 'whatsapp-web.js';
const { Client, LocalAuth, MessageMedia } = pkg as any;
import qrcode from 'qrcode';
import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';

export type ConnectionStatus = 'disconnected' | 'initializing' | 'qr_ready' | 'connected' | 'auth_failed';

export interface WhatsAppState {
  status: ConnectionStatus;
  qrDataUrl: string | null;
  phoneNumber: string | null;
}

let client: any = null;
let state: WhatsAppState = {
  status: 'disconnected',
  qrDataUrl: null,
  phoneNumber: null,
};

let broadcastFn: ((data: any) => void) | null = null;

export function setBroadcast(fn: (data: any) => void) {
  broadcastFn = fn;
}

function broadcast(data: any) {
  if (broadcastFn) broadcastFn(data);
}

export function getWhatsAppState(): WhatsAppState {
  return { ...state };
}

// Resolve the connected phone number from the live Puppeteer page and update state.
// Safe to call at any time — no-ops if not connected or page unavailable.
export async function resolveConnectedPhone(): Promise<string | null> {
  console.log(`[WhatsApp] resolveConnectedPhone: client=${!!client}, status=${state.status}`);
  if (!client || state.status !== 'connected') return null;
  try {
    const result = await client.pupPage?.evaluate(() => {
      try {
        const pnUser = (window as any).require('WAWebUserPrefsMeUser').getMaybeMePnUser();
        if (pnUser?.user) return pnUser.user;
        if (pnUser?._serialized) return (pnUser._serialized as string).split('@')[0];
        const conn = (window as any).require('WAWebConnModel').Conn.serialize();
        return conn?.phone || conn?.me?.user || null;
      } catch (e: any) { return 'ERR:' + e.message; }
    });
    console.log('[WhatsApp] resolveConnectedPhone page result:', result);
    if (result && !String(result).startsWith('ERR:')) {
      state = { ...state, phoneNumber: result as string };
      if (broadcastFn) broadcastFn({ type: 'whatsapp_status', data: state });
      return result as string;
    }
    return null;
  } catch (err: any) {
    console.error('[WhatsApp] resolveConnectedPhone error:', err.message);
    return null;
  }
}

// Find chromium binary — supports Linux (Nix/system), Windows, and macOS
function findChromium(): string {
  const isWindows = process.platform === 'win32';
  const isMac = process.platform === 'darwin';

  const candidates: string[] = [];

  if (isWindows) {
    // Windows — look for installed Chrome/Chromium
    const pf = process.env['PROGRAMFILES'] || 'C:\\Program Files';
    const pf86 = process.env['PROGRAMFILES(X86)'] || 'C:\\Program Files (x86)';
    const local = process.env['LOCALAPPDATA'] || '';
    candidates.push(
      path.join(pf, 'Google', 'Chrome', 'Application', 'chrome.exe'),
      path.join(pf86, 'Google', 'Chrome', 'Application', 'chrome.exe'),
      path.join(local, 'Google', 'Chrome', 'Application', 'chrome.exe'),
      path.join(pf, 'Chromium', 'Application', 'chrome.exe'),
      path.join(pf86, 'Chromium', 'Application', 'chrome.exe'),
      path.join(local, 'Chromium', 'Application', 'chrome.exe'),
    );
  } else if (isMac) {
    candidates.push(
      '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
      '/Applications/Chromium.app/Contents/MacOS/Chromium',
      '/usr/bin/chromium',
      '/usr/bin/google-chrome',
    );
  } else {
    // Linux / Nix
    candidates.push(
      '/nix/store/zi4f80l169xlmivz8vja8wlphq74qqk0-chromium-125.0.6422.141/bin/chromium',
      '/usr/bin/chromium',
      '/usr/bin/chromium-browser',
      '/usr/bin/google-chrome',
      '/usr/bin/google-chrome-stable',
    );
  }

  for (const p of candidates) {
    if (p && fs.existsSync(p)) return p;
  }

  if (!isWindows && !isMac) {
    // Try nix store glob
    try {
      const result = execSync('find /nix/store -maxdepth 3 -name "chromium" -type f 2>/dev/null | head -1', {
        timeout: 5000,
        encoding: 'utf8',
      }).trim();
      if (result) return result;
    } catch (_) {}

    // Try which
    try {
      const result = execSync('which chromium || which chromium-browser || which google-chrome', {
        timeout: 3000,
        encoding: 'utf8',
      }).trim().split('\n')[0];
      if (result) return result;
    } catch (_) {}
  }

  throw new Error(
    isWindows
      ? 'Google Chrome not found. Please install Chrome from https://www.google.com/chrome/ and try again.'
      : isMac
        ? 'Google Chrome not found. Please install Chrome from https://www.google.com/chrome/ and try again.'
        : 'Chromium binary not found. Cannot start WhatsApp.'
  );
}

// On a fresh server start (new deployment container), stale Chromium lock
// files from the previous container's process persist on the shared filesystem.
// pkill cannot kill a dead process from another container, so lock-file-only
// removal is unreliable. Instead, we wipe the entire .wwebjs_auth dir on the
// first initWhatsApp() call of this process (new deploy), then only remove
// lock files on in-session reconnects.
let isFirstInit = true;

function getDataDir(): string {
  return process.env.ELECTRON_USER_DATA || process.cwd();
}

function getAuthDir(): string {
  return path.resolve(getDataDir(), '.wwebjs_auth');
}

function deleteLockFilesRecursively(dir: string) {
  if (!fs.existsSync(dir)) return;
  const lockNames = new Set(['SingletonLock', 'SingletonSocket', 'SingletonCookie']);
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    if (lockNames.has(entry.name)) {
      try { fs.unlinkSync(fullPath); } catch (_) {}
    } else if (entry.isDirectory()) {
      deleteLockFilesRecursively(fullPath);
    }
  }
}

function wipeAuthDir() {
  try {
    const authDir = getAuthDir();
    if (fs.existsSync(authDir)) {
      fs.rmSync(authDir, { recursive: true, force: true });
      console.log('[WhatsApp] Wiped .wwebjs_auth (fresh deploy startup)');
    }
  } catch (err: any) {
    console.error('[WhatsApp] Failed to wipe .wwebjs_auth:', err.message);
  }
}

function removeSessionLocks() {
  const isWindows = process.platform === 'win32';

  if (!isWindows) {
    // Kill stale chromium processes (Linux/Mac only)
    try { execSync('pkill -9 -f chromium 2>/dev/null || true', { timeout: 5000 }); } catch (_) {}
    try { execSync('sleep 1', { timeout: 3000 }); } catch (_) {}
  }

  // Remove lock files cross-platform
  try {
    deleteLockFilesRecursively(getAuthDir());
    console.log('[WhatsApp] Removed Chromium lock files');
  } catch (_) {}
}

let autoReconnectEnabled = true;

export async function initWhatsApp() {
  autoReconnectEnabled = true;

  const freshStart = isFirstInit;
  isFirstInit = false;

  // Fully destroy any existing client first
  if (client) {
    try {
      client.removeAllListeners();
      await client.destroy();
    } catch (_) {}
    client = null;
    await new Promise(r => setTimeout(r, 1500));
  }

  if (freshStart) {
    // First initWhatsApp() of this process — remove stale Chromium singleton locks
    // left by the previous process (their PIDs are gone). We only remove locks, NOT
    // the session data, so an existing LocalAuth session is reused and no QR scan
    // is needed after a server restart or redeploy.
    removeSessionLocks();
  } else {
    // In-session reconnect — same: only remove lock files, keep session data.
    removeSessionLocks();
  }

  state = { status: 'initializing', qrDataUrl: null, phoneNumber: null };
  broadcast({ type: 'whatsapp_status', data: state });

  let chromiumPath: string;
  try {
    chromiumPath = findChromium();
    console.log('[WhatsApp] Using Chromium at:', chromiumPath);
  } catch (err: any) {
    console.error('[WhatsApp]', err.message);
    state = { status: 'disconnected', qrDataUrl: null, phoneNumber: null };
    broadcast({ type: 'whatsapp_status', data: state });
    return;
  }

  client = new Client({
    authStrategy: new LocalAuth({ dataPath: getAuthDir() }),
    puppeteer: {
      executablePath: chromiumPath,
      args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-dev-shm-usage',
        '--disable-accelerated-2d-canvas',
        '--no-first-run',
        '--disable-gpu',
        '--disable-software-rasterizer',
        '--disable-extensions',
        '--disable-background-networking',
        '--disable-background-timer-throttling',
        '--disable-backgrounding-occluded-windows',
        '--disable-renderer-backgrounding',
        '--disable-default-apps',
        '--mute-audio',
        '--disable-features=TranslateUI,VizDisplayCompositor',
        '--disable-ipc-flooding-protection',
        '--disable-hang-monitor',
        '--disable-client-side-phishing-detection',
        '--disable-popup-blocking',
        '--disable-prompt-on-repost',
        '--disable-sync',
        '--metrics-recording-only',
        '--safebrowsing-disable-auto-update',
        '--password-store=basic',
        '--use-mock-keychain',
        // Keep JS heap tight — WhatsApp Web doesn't need 512 MB
        '--js-flags=--max-old-space-size=256',
      ],
      headless: 'new' as any,
    },
  });

  client.on('qr', async (qr: string) => {
    try {
      const dataUrl = await qrcode.toDataURL(qr, { width: 300 });
      state = { status: 'qr_ready', qrDataUrl: dataUrl, phoneNumber: null };
      broadcast({ type: 'whatsapp_status', data: state });
    } catch (err) {
      console.error('[WhatsApp] QR generation error:', err);
    }
  });

  client.on('ready', async () => {
    // In multi-device WhatsApp, getMaybeMePnUser() returns null and wid is a LID
    // (e.g. "12345:7@lid"), not the phone number. Evaluate the page directly to
    // get the real phone number from WhatsApp's connection model.
    const resolvePhoneFromPage = async (): Promise<string | null> => {
      try {
        const result = await client?.pupPage?.evaluate(() => {
          try {
            // Try PN user (phone-number-based) first
            const pnUser = (window as any).require('WAWebUserPrefsMeUser').getMaybeMePnUser();
            if (pnUser?.user) return pnUser.user;
            if (pnUser?._serialized) return (pnUser._serialized as string).split('@')[0];
            // Fall back to Conn serialized data
            const conn = (window as any).require('WAWebConnModel').Conn.serialize();
            return conn?.phone || conn?.me?.user || null;
          } catch (_) {
            return null;
          }
        });
        return result ?? null;
      } catch (_) {
        return null;
      }
    };

    // Also try from client.info as a quick synchronous fallback
    const fromInfo = (() => {
      const info = client?.info as any;
      const raw = info?.wid?.user ?? info?.wid?._serialized?.split('@')[0] ?? null;
      // Skip LID format — it contains ':' and is not a phone number
      if (raw && raw.includes(':')) return null;
      return raw ?? null;
    })();

    const phoneNumber = fromInfo ?? await resolvePhoneFromPage();
    state = { status: 'connected', qrDataUrl: null, phoneNumber };
    broadcast({ type: 'whatsapp_status', data: state });
    console.log('[WhatsApp] Connected, phone:', phoneNumber);

    // Keepalive: evaluate a no-op in the page every 25s to prevent
    // the Puppeteer execution context from being destroyed by inactivity.
    const keepaliveInterval = setInterval(async () => {
      if (!client || state.status !== 'connected') {
        clearInterval(keepaliveInterval);
        return;
      }
      try {
        await client.pupPage?.evaluate(() => true);
      } catch (_) {
        // If the page is gone the disconnect event will fire and reconnect
        clearInterval(keepaliveInterval);
      }
    }, 25_000);
  });

  client.on('auth_failure', (msg: string) => {
    console.error('[WhatsApp] Auth failure:', msg);
    state = { status: 'auth_failed', qrDataUrl: null, phoneNumber: null };
    broadcast({ type: 'whatsapp_status', data: state });
  });

  client.on('disconnected', async (reason: string) => {
    console.log('[WhatsApp] Disconnected, reason:', reason);
    state = { status: 'disconnected', qrDataUrl: null, phoneNumber: null };
    broadcast({ type: 'whatsapp_status', data: state });

    // CRITICAL: destroy the Puppeteer browser BEFORE nulling the client.
    // Without this, every reconnect spawns a new Chromium while the old one
    // keeps running as a zombie — they accumulate and trigger an OOM kill.
    const deadClient = client;
    client = null;
    try {
      deadClient?.removeAllListeners();
      await deadClient?.destroy();
    } catch (_) {}

    // Auto-reconnect whenever the user has not intentionally clicked Disconnect.
    // This includes LOGOUT reason — in production containers, WhatsApp detects
    // the new environment fingerprint and forces LOGOUT, but we should reconnect
    // and show a fresh QR code rather than staying stuck in disconnected state.
    if (autoReconnectEnabled) {
      console.log(`[WhatsApp] Auto-reconnecting in 8s (reason was: ${reason})...`);
      setTimeout(() => {
        if (autoReconnectEnabled) {
          initWhatsApp().catch(err =>
            console.error('[WhatsApp] Auto-reconnect failed:', err.message)
          );
        }
      }, 8000);
    } else {
      console.log('[WhatsApp] Auto-reconnect disabled (user intentionally disconnected).');
    }
  });

  // Timeout safety — if Chromium/WhatsApp doesn't reach QR/ready within 90s, bail.
  let initTimeout: ReturnType<typeof setTimeout>;
  const clearInit = () => clearTimeout(initTimeout);

  initTimeout = setTimeout(async () => {
    if (state.status === 'initializing' || state.status === 'qr_ready') {
      console.error('[WhatsApp] Initialization timed out after 90s');
      try { client?.removeAllListeners(); await client?.destroy(); } catch (_) {}
      client = null;
      state = { status: 'disconnected', qrDataUrl: null, phoneNumber: null };
      broadcast({ type: 'whatsapp_status', data: state });
    }
  }, 90_000);

  // Clear the init timeout once we're fully connected
  client.once('ready', clearInit);

  // Wrap initialize() — absorb rejections so the process never crashes.
  // State transitions are already handled by the event listeners above.
  client.initialize().catch((err: any) => {
    console.error('[WhatsApp] Initialize error:', err?.message ?? err);
    clearInit();
    if (state.status === 'initializing') {
      state = { status: 'disconnected', qrDataUrl: null, phoneNumber: null };
      broadcast({ type: 'whatsapp_status', data: state });
      client = null;
    }
  });
}

export async function disconnectWhatsApp() {
  autoReconnectEnabled = false; // stop auto-reconnect on intentional logout
  if (client) {
    try {
      client.removeAllListeners();
      await client.destroy();
    } catch (_) {}
    client = null;
  }
  state = { status: 'disconnected', qrDataUrl: null, phoneNumber: null };
  broadcast({ type: 'whatsapp_status', data: state });
}

export interface WhatsAppMedia {
  base64: string;
  mimeType: string;
  filename: string;
}

export async function sendWhatsAppMessage(
  phone: string,
  message: string,
  media?: WhatsAppMedia
): Promise<void> {
  if (!client || state.status !== 'connected') {
    console.error(`[WhatsApp] sendMessage guard: client=${!!client}, status=${state.status}`);
    throw new Error('WhatsApp not connected');
  }

  let cleanPhone = phone.replace(/\D/g, '');

  // Auto-prepend country code 91 for 10-digit Indian mobile numbers (starts 6-9)
  if (cleanPhone.length === 10 && /^[6-9]/.test(cleanPhone)) {
    cleanPhone = '91' + cleanPhone;
  }

  // Verify the number is registered on WhatsApp
  const numberId = await client.getNumberId(cleanPhone);
  if (!numberId) {
    throw new Error(`${cleanPhone} is not registered on WhatsApp`);
  }

  // Always use the @c.us chat ID for sending — in multi-device mode, getNumberId()
  // may return a @lid (device-local ID) which sendMessage() can't resolve to a chat.
  // The actual message chat ID is always {phone}@c.us regardless of device mode.
  const chatId = `${cleanPhone}@c.us`;
  console.log(`[WhatsApp] Sending to ${chatId}...`);

  if (media) {
    const waMedia = new MessageMedia(media.mimeType, media.base64, media.filename);
    const sendOpts: any = { caption: message };
    // Send OGG audio as voice note
    if (media.mimeType === 'audio/ogg' || media.mimeType === 'audio/ogg; codecs=opus') {
      sendOpts.sendAudioAsVoice = true;
    }
    await client.sendMessage(chatId, waMedia, sendOpts);
  } else {
    await client.sendMessage(chatId, message);
  }

  console.log(`[WhatsApp] Sent successfully to ${chatId}`);
}

export function isConnected(): boolean {
  return state.status === 'connected';
}

export async function checkNumberOnWhatsApp(
  phone: string
): Promise<{ phone: string; exists: boolean; whatsappId?: string }> {
  if (!client || state.status !== 'connected') {
    throw new Error('WhatsApp not connected');
  }

  let cleanPhone = phone.replace(/\D/g, '');
  if (cleanPhone.length === 10 && /^[6-9]/.test(cleanPhone)) {
    cleanPhone = '91' + cleanPhone;
  }

  const numberId = await client.getNumberId(cleanPhone);
  return {
    phone,
    exists: !!numberId,
    whatsappId: numberId?._serialized,
  };
}
