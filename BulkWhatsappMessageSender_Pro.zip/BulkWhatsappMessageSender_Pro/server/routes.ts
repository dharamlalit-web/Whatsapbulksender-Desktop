import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import multer from "multer";
import fs from "fs";
import path from "path";
import Papa from "papaparse";
import { storage } from "./storage";
import { getLicenseStatus, activateLicense, recordMessagesSent } from "./license";
import { insertContactSchema, insertTemplateSchema, insertCampaignSchema } from "@shared/schema";
import {
  getWhatsAppState,
  initWhatsApp,
  disconnectWhatsApp,
  sendWhatsAppMessage,
  checkNumberOnWhatsApp,
  setBroadcast,
  isConnected,
  resolveConnectedPhone,
  type WhatsAppMedia,
} from "./whatsapp";

// ─── In-memory settings ───────────────────────────────────────────────────────
const appSettings: Record<string, any> = {
  defaultDelaySeconds: 5,
};

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 50 * 1024 * 1024 },
});

const delay = (ms: number) => new Promise((r) => setTimeout(r, ms));

const PACE_DELAY: Record<string, number> = {
  slow: 15000,
  medium: 8000,
  fast: 5000,
};

// ─── CSV Parsing Helper ──────────────────────────────────────────────────────

const PHONE_HEADERS = ["phone", "mobile", "number", "whatsapp", "contact", "cell",
  "phone number", "mobile number", "contact number", "whatsapp number", "phone no",
  "mobile no", "contact no", "phonenumber", "mobilenumber", "contactnumber"];
const NAME_HEADERS  = ["name", "full name", "fullname", "contact name", "customer name",
  "person name", "first name", "firstname"];
const EMAIL_HEADERS = ["email", "email address", "emailaddress", "e-mail"];
const COMPANY_HEADERS = ["company", "organization", "org", "business", "firm", "company name"];

async function parseCsvAndSave(fileBuffer: Buffer, originalName: string) {
  const raw = fileBuffer.toString("utf-8").replace(/^\uFEFF/, ""); // strip BOM
  console.log("[CSV] Raw first 200 chars:", raw.substring(0, 200));

  const { data, errors } = Papa.parse<Record<string, string>>(raw, {
    header: true,
    skipEmptyLines: true,
    transformHeader: (h) => h.trim().toLowerCase().replace(/['"]/g, ""),
    transform: (v) => v.trim(),
  });

  if (errors.length && data.length === 0) {
    throw new Error("Could not parse file — make sure it is a CSV with a header row");
  }

  const headers = data.length > 0 ? Object.keys(data[0]) : [];
  console.log("[CSV] Detected headers:", headers);
  console.log("[CSV] Total rows parsed:", data.length);
  if (data.length > 0) console.log("[CSV] First row sample:", JSON.stringify(data[0]));

  const phoneKey   = headers.find((h) => PHONE_HEADERS.includes(h));
  const nameKey    = headers.find((h) => NAME_HEADERS.includes(h));
  const emailKey   = headers.find((h) => EMAIL_HEADERS.includes(h));
  const companyKey = headers.find((h) => COMPANY_HEADERS.includes(h));

  if (!phoneKey) {
    const known = headers.join(", ");
    throw new Error(
      `No phone column found. Columns in your file: [${known}]. ` +
      `Please name it one of: phone, mobile, contact, whatsapp, number`
    );
  }

  const standardKeys = new Set([phoneKey, nameKey, emailKey, companyKey].filter(Boolean) as string[]);
  const customKeys   = headers.filter((h) => !standardKeys.has(h));

  const contactIds: string[] = [];
  let upsertedCount = 0;

  for (const row of data) {
    const phone = (row[phoneKey] || "").replace(/\s+/g, "");
    if (!phone) continue;

    const customFields: Record<string, string> = {};
    for (const k of customKeys) {
      if (row[k]) customFields[k] = row[k];
    }

    const contactData = {
      name: (nameKey && row[nameKey]) ? row[nameKey] : "Unknown",
      phone,
      email: (emailKey && row[emailKey]) ? row[emailKey] : null,
      company: (companyKey && row[companyKey]) ? row[companyKey] : null,
      customFields: Object.keys(customFields).length > 0 ? customFields : null,
      isWhatsAppVerified: false,
    };

    const existing = await storage.getContactByPhone(phone);
    if (existing) {
      await storage.updateContact(existing.id, contactData);
      contactIds.push(existing.id);
    } else {
      const contact = await storage.createContact(contactData);
      contactIds.push(contact.id);
    }
    upsertedCount++;
  }

  console.log(`[CSV] Imported ${upsertedCount} contacts from "${originalName}"`);

  const listName = originalName.replace(/\.[^/.]+$/, "");
  await storage.createContactList(
    { name: listName, filename: originalName, contactCount: upsertedCount },
    contactIds
  );

  return { contactsCreated: upsertedCount, contactsAdded: upsertedCount, contactIds };
}

// Wait for WhatsApp to reconnect (up to maxWaitMs)
async function waitForConnection(maxWaitMs = 30000): Promise<boolean> {
  const start = Date.now();
  while (!isConnected() && Date.now() - start < maxWaitMs) {
    await delay(2000);
  }
  return isConnected();
}

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  const wss = new WebSocketServer({ server: httpServer, path: "/ws" });
  const clients = new Set<WebSocket>();

  wss.on("connection", (ws) => {
    clients.add(ws);
    ws.send(JSON.stringify({ type: "whatsapp_status", data: getWhatsAppState() }));
    ws.on("close", () => clients.delete(ws));
  });

  function broadcast(data: any) {
    const msg = JSON.stringify(data);
    clients.forEach((client) => {
      if (client.readyState === WebSocket.OPEN) client.send(msg);
    });
  }

  setBroadcast(broadcast);

  // If WhatsApp reconnected (LocalAuth) before broadcast was wired up, the
  // phoneNumber might be null. Resolve it now from the live Puppeteer page.
  setTimeout(async () => {
    const s = getWhatsAppState();
    if (s.status === 'connected' && !s.phoneNumber) {
      await resolveConnectedPhone();
    }
  }, 3000);

  // ─── WhatsApp ───────────────────────────────────────────────────────────────

  app.get("/api/whatsapp/status", (_req, res) => {
    res.setHeader("Cache-Control", "no-store");
    res.json(getWhatsAppState());
  });

  app.post("/api/whatsapp/connect", async (_req, res) => {
    try {
      initWhatsApp().catch((err) => console.error("[WhatsApp] init error:", err));
      res.json({ message: "Initializing WhatsApp connection..." });
    } catch (err) {
      res.status(500).json({ error: "Failed to start WhatsApp" });
    }
  });

  app.post("/api/whatsapp/disconnect", async (_req, res) => {
    try {
      await disconnectWhatsApp();
      res.json({ message: "Disconnected" });
    } catch (err) {
      res.status(500).json({ error: "Failed to disconnect" });
    }
  });

  // ─── Quick Send (manual numbers, no CSV) ────────────────────────────────────

  app.post("/api/quick-send", async (req, res) => {
    const { phones, message, mediaBase64, mediaMimeType, mediaFilename } =
      req.body as {
        phones: string[];
        message: string;
        mediaBase64?: string;
        mediaMimeType?: string;
        mediaFilename?: string;
      };
    if (!phones?.length || !message?.trim()) {
      return res.status(400).json({ error: "phones and message are required" });
    }

    if (!isConnected()) {
      return res.status(400).json({ error: "WhatsApp is not connected" });
    }

    // ── License guard ──────────────────────────────────────────────────────────
    const licCheck = getLicenseStatus();
    if (licCheck.blocked) {
      return res.status(403).json({ error: licCheck.blockReason, code: "license_required" });
    }

    const media: WhatsAppMedia | undefined =
      mediaBase64 && mediaMimeType
        ? { base64: mediaBase64, mimeType: mediaMimeType, filename: mediaFilename ?? "file" }
        : undefined;

    const results: { phone: string; status: "sent" | "failed"; error?: string }[] = [];

    for (const rawPhone of phones) {
      const phone = rawPhone.trim();
      if (!phone) continue;

      // Re-check license before each message (daily limit may be hit mid-batch)
      const midCheck = getLicenseStatus();
      if (midCheck.blocked) {
        results.push({ phone, status: "failed", error: midCheck.blockReason ?? "License limit reached" });
        continue;
      }

      try {
        await sendWhatsAppMessage(phone, message, media);
        recordMessagesSent(1);
        results.push({ phone, status: "sent" });
      } catch (err: any) {
        results.push({ phone, status: "failed", error: err.message });
      }
      if (phones.indexOf(rawPhone) < phones.length - 1) await delay(1500);
    }

    res.json({ results });
  });

  // ─── Verify Numbers ─────────────────────────────────────────────────────────

  app.post("/api/verify-numbers", async (req, res) => {
    const { phones } = req.body as { phones: string[] };
    if (!phones?.length) {
      return res.status(400).json({ error: "phones array is required" });
    }
    if (!isConnected()) {
      return res.status(400).json({ error: "WhatsApp is not connected" });
    }

    const results = [];
    for (const phone of phones) {
      const trimmed = phone.trim();
      if (!trimmed) continue;
      try {
        const result = await checkNumberOnWhatsApp(trimmed);
        results.push(result);
      } catch (err: any) {
        results.push({ phone: trimmed, exists: false, error: err.message });
      }
      // small delay between checks to avoid rate limiting
      if (phones.indexOf(phone) < phones.length - 1) await delay(500);
    }

    res.json({ results });
  });

  // ─── Contacts ───────────────────────────────────────────────────────────────

  app.get("/api/contacts", async (_req, res) => {
    const contacts = await storage.getContacts();
    res.json(contacts);
  });

  app.post("/api/contacts", async (req, res) => {
    const result = insertContactSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({ error: result.error.issues });
    }
    const contact = await storage.createContact(result.data);
    res.json(contact);
  });

  app.put("/api/contacts/:id", async (req, res) => {
    const contact = await storage.updateContact(req.params.id, req.body);
    if (!contact) return res.status(404).json({ error: "Contact not found" });
    res.json(contact);
  });

  app.delete("/api/contacts/:id", async (req, res) => {
    const deleted = await storage.deleteContact(req.params.id);
    if (!deleted) return res.status(404).json({ error: "Contact not found" });
    res.json({ success: true });
  });

  // ─── Contact Lists ───────────────────────────────────────────────────────────

  app.get("/api/contact-lists", async (_req, res) => {
    res.setHeader("Cache-Control", "no-store");
    const lists = await storage.getContactLists();
    res.json(lists);
  });

  app.get("/api/contact-lists/:id/contacts", async (req, res) => {
    const contacts = await storage.getContactsByListId(req.params.id);
    res.json(contacts);
  });

  app.delete("/api/contact-lists/:id", async (req, res) => {
    const deleted = await storage.deleteContactList(req.params.id);
    if (!deleted) return res.status(404).json({ error: "Contact list not found" });
    res.json({ success: true });
  });

  // ─── CSV Upload ──────────────────────────────────────────────────────────────

  app.post("/api/upload-csv", upload.single("file"), async (req, res) => {
    if (!req.file) return res.status(400).json({ error: "No file uploaded" });
    try {
      const result = await parseCsvAndSave(req.file.buffer, req.file.originalname);
      res.json({ success: true, ...result });
    } catch (err: any) {
      console.error("CSV upload error:", err);
      res.status(400).json({ error: err.message || "Failed to process CSV file" });
    }
  });

  // Used by the upload-area component — receives CSV as plain JSON text (avoids multipart proxy issues)
  app.post("/api/contacts/bulk", async (req, res) => {
    const { csv, filename } = req.body as { csv?: string; filename?: string };
    console.log("[Bulk] hit, filename:", filename, "csv length:", csv?.length);
    if (!csv) return res.status(400).json({ error: "No CSV content received" });
    try {
      const result = await parseCsvAndSave(Buffer.from(csv, "utf-8"), filename || "upload.csv");
      res.json({ success: true, ...result });
    } catch (err: any) {
      console.error("CSV bulk upload error:", err);
      res.status(400).json({ error: err.message || "Failed to process CSV file" });
    }
  });

  // ─── Templates ──────────────────────────────────────────────────────────────

  app.get("/api/templates", async (_req, res) => {
    const templates = await storage.getTemplates();
    res.json(templates);
  });

  app.post("/api/templates", async (req, res) => {
    const result = insertTemplateSchema.safeParse(req.body);
    if (!result.success) return res.status(400).json({ error: result.error.issues });
    const template = await storage.createTemplate(result.data);
    res.json(template);
  });

  app.put("/api/templates/:id", async (req, res) => {
    const template = await storage.updateTemplate(req.params.id, req.body);
    if (!template) return res.status(404).json({ error: "Template not found" });
    res.json(template);
  });

  app.delete("/api/templates/:id", async (req, res) => {
    const deleted = await storage.deleteTemplate(req.params.id);
    if (!deleted) return res.status(404).json({ error: "Template not found" });
    res.json({ success: true });
  });

  // ─── Campaigns ──────────────────────────────────────────────────────────────

  app.get("/api/campaigns", async (_req, res) => {
    const campaigns = await storage.getCampaigns();
    res.json(campaigns);
  });

  app.get("/api/campaigns/active", async (_req, res) => {
    const campaigns = await storage.getActiveCampaigns();
    res.json(campaigns);
  });

  app.post("/api/campaigns", async (req, res) => {
    const result = insertCampaignSchema.safeParse(req.body);
    if (!result.success) return res.status(400).json({ error: result.error.issues });
    const campaign = await storage.createCampaign(result.data);
    res.json(campaign);
  });

  app.post("/api/campaigns/:id/start", async (req, res) => {
    const campaign = await storage.getCampaign(req.params.id);
    if (!campaign) return res.status(404).json({ error: "Campaign not found" });

    await storage.updateCampaign(campaign.id, {
      status: "running",
      startedAt: new Date(),
      scheduledAt: null,
    });

    runCampaign(campaign.id, broadcast).catch((err) =>
      console.error("[Campaign] Runner error:", err)
    );

    res.json({ message: "Campaign started" });
  });

  app.post("/api/campaigns/:id/pause", async (req, res) => {
    const campaign = await storage.updateCampaign(req.params.id, { status: "paused" });
    if (!campaign) return res.status(404).json({ error: "Campaign not found" });
    res.json(campaign);
  });

  app.delete("/api/campaigns/:id", async (req, res) => {
    const deleted = await storage.deleteCampaign(req.params.id);
    if (!deleted) return res.status(404).json({ error: "Campaign not found" });
    res.json({ success: true });
  });

  // ─── Campaign Audit Logs ────────────────────────────────────────────────────

  app.get("/api/campaigns/:id/logs", async (req, res) => {
    const logs = await storage.getMessageLogsByCampaign(req.params.id);
    const enriched = logs.map((log) => ({
      ...log,
      contactName: log.contactName ?? "Unknown",
      contactPhone: log.contactPhone ?? "—",
    }));
    res.json(enriched);
  });

  // ─── Stats ──────────────────────────────────────────────────────────────────

  app.get("/api/stats", async (_req, res) => {
    const stats = await storage.getDashboardStats();
    res.json(stats);
  });

  // ─── Number Verification ────────────────────────────────────────────────────

  app.post("/api/verify-numbers", async (req, res) => {
    const { contactIds } = req.body as { contactIds: string[] };
    if (!isConnected()) {
      return res.status(400).json({ error: "WhatsApp not connected" });
    }
    try {
      const results = [];
      for (const id of contactIds) {
        const contact = await storage.getContact(id);
        if (!contact) continue;
        try {
          const { isConnected: isOnWhatsApp } = await import("./whatsapp");
          results.push({ id, phone: contact.phone, isRegistered: true });
          await storage.updateContact(id, { isWhatsAppVerified: true });
        } catch {
          results.push({ id, phone: contact.phone, isRegistered: false });
        }
      }
      res.json({ results });
    } catch (err) {
      res.status(500).json({ error: "Failed to verify numbers" });
    }
  });

  // ─── Scheduled Campaign Checker ─────────────────────────────────────────────
  // Checks every 15 seconds and immediately on startup for due campaigns

  async function checkScheduledCampaigns() {
    try {
      const all = await storage.getCampaigns();
      const now = new Date();
      for (const campaign of all) {
        if (
          campaign.status === "pending" &&
          campaign.scheduledAt &&
          new Date(campaign.scheduledAt) <= now
        ) {
          console.log(`[Scheduler] Starting scheduled campaign: ${campaign.name}`);
          await storage.updateCampaign(campaign.id, {
            status: "running",
            startedAt: new Date(),
            scheduledAt: null,
          });
          runCampaign(campaign.id, broadcast).catch((err) =>
            console.error("[Campaign] Scheduled runner error:", err)
          );
        }
      }
    } catch (err) {
      console.error("[Scheduler] Error:", err);
    }
  }

  // Run immediately on startup, then every 15 seconds
  checkScheduledCampaigns();
  setInterval(checkScheduledCampaigns, 15_000);

  // ─── License ─────────────────────────────────────────────────────────────────

  app.get("/api/license/status", (_req, res) => {
    res.json(getLicenseStatus());
  });

  app.post("/api/license/activate", (req, res) => {
    const { key } = req.body as { key: string };
    if (!key?.trim()) {
      return res.status(400).json({ success: false, error: "Key is required" });
    }
    const result = activateLicense(key.trim());
    if (!result.success) {
      return res.status(400).json(result);
    }
    res.json(result);
  });

  // ─── Settings ────────────────────────────────────────────────────────────────

  app.get("/api/settings", (_req, res) => {
    res.json(appSettings);
  });

  app.post("/api/settings", (req, res) => {
    Object.assign(appSettings, req.body);
    res.json(appSettings);
  });

  return httpServer;
}

// ─── Campaign Runner ──────────────────────────────────────────────────────────

async function runCampaign(campaignId: string, broadcast: (d: any) => void) {
  const campaign = await storage.getCampaign(campaignId);
  if (!campaign) return;

  const contactIds = (campaign.contactIds as string[]) || [];
  // Use custom delaySeconds if set (in seconds), otherwise fall back to sendingPace
  const paceDelay = campaign.delaySeconds
    ? campaign.delaySeconds * 1000
    : (PACE_DELAY[campaign.sendingPace] ?? PACE_DELAY.medium);

  let sentCount = 0;
  let deliveredCount = 0;
  let failedCount = 0;

  for (let i = 0; i < contactIds.length; i++) {
    const contactId = contactIds[i];

    // Check if campaign was paused/cancelled
    const current = await storage.getCampaign(campaignId);
    if (!current || current.status === "paused" || current.status === "completed") break;

    const contact = await storage.getContact(contactId);
    if (!contact) continue;

    // Substitute variables
    let message = campaign.message
      .replace(/\{\{name\}\}/gi, contact.name || "")
      .replace(/\{\{company\}\}/gi, contact.company || "")
      .replace(/\{\{email\}\}/gi, contact.email || "")
      .replace(/\{\{phone\}\}/gi, contact.phone || "");

    const customFields = (contact.customFields as Record<string, string>) || {};
    for (const [key, value] of Object.entries(customFields)) {
      message = message.replace(new RegExp(`\\{\\{${key}\\}\\}`, "gi"), value || "");
    }

    let status: "sent" | "failed" = "failed";
    let errorMsg: string | null = null;

    // ── License guard (per-message, catches daily limit mid-campaign) ──────────
    const licCheck = getLicenseStatus();
    if (licCheck.blocked) {
      console.warn(`[Campaign] License blocked: ${licCheck.blockReason}`);
      await storage.updateCampaign(campaignId, {
        status: "paused",
      });
      broadcast({ type: "campaign_progress", data: { ...(await storage.getCampaign(campaignId)), licenseBlocked: true } });
      break;
    }

    // Per-message connection check — if disconnected, wait up to 30s
    if (!isConnected()) {
      console.warn(`[Campaign] WhatsApp disconnected at contact ${i + 1}/${contactIds.length}, waiting up to 30s...`);
      const reconnected = await waitForConnection(30000);
      if (!reconnected) {
        errorMsg = "WhatsApp disconnected and did not reconnect within 30s";
        failedCount++;
        sentCount++;
        await storage.createMessageLog({ campaignId, contactId, contactName: contact.name, contactPhone: contact.phone, message, status: "failed", error: errorMsg });
        const updated = await storage.updateCampaign(campaignId, { sentCount, deliveredCount, failedCount });
        broadcast({ type: "campaign_progress", data: updated });
        continue;
      }
    }

    try {
      const media: WhatsAppMedia | undefined =
        campaign.mediaBase64 && campaign.mediaMimeType
          ? {
              base64: campaign.mediaBase64 as string,
              mimeType: campaign.mediaMimeType as string,
              filename: (campaign.mediaFilename as string) || "media",
            }
          : undefined;
      await sendWhatsAppMessage(contact.phone, message, media);
      recordMessagesSent(1);
      status = "sent";
      sentCount++;
      deliveredCount++;
    } catch (err: any) {
      const msg = err.message || "Send failed";
      console.error(`[Campaign] Failed to send to ${contact.phone}: ${msg}`);
      errorMsg = msg;
      status = "failed";
      failedCount++;
      sentCount++;
    }

    await storage.createMessageLog({
      campaignId,
      contactId,
      contactName: contact.name,
      contactPhone: contact.phone,
      message,
      status,
      error: errorMsg,
      sentAt: status === "sent" ? new Date().toISOString() : null,
    });

    const updated = await storage.updateCampaign(campaignId, { sentCount, deliveredCount, failedCount });
    broadcast({ type: "campaign_progress", data: updated });

    if (i < contactIds.length - 1) {
      await delay(paceDelay);
    }
  }

  const final = await storage.updateCampaign(campaignId, {
    status: "completed",
    completedAt: new Date(),
    sentCount,
    deliveredCount,
    failedCount,
  });

  broadcast({ type: "campaign_completed", data: final });
}
