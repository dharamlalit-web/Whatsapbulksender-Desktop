import { neon } from "@neondatabase/serverless";
import { drizzle } from "drizzle-orm/neon-http";
import * as schema from "@shared/schema";

let _db: ReturnType<typeof drizzle> | null = null;

if (process.env.DATABASE_URL) {
  const sql = neon(process.env.DATABASE_URL);
  _db = drizzle(sql, { schema });
} else {
  console.log('[DB] No DATABASE_URL set — using in-memory storage (desktop mode)');
}

export { _db as db };
