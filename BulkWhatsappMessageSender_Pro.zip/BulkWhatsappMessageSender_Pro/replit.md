# Overview

BulkSender Pro is a WhatsApp bulk messaging automation platform built with a full-stack TypeScript architecture. The application enables users to manage contacts, create message templates, and run large-scale messaging campaigns with real-time progress tracking. It features a modern React frontend with shadcn/ui components and an Express.js backend with PostgreSQL database integration.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query for server state management and caching
- **UI Framework**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS variables for theming
- **Build Tool**: Vite with custom configuration for development and production

## Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Design**: RESTful endpoints with WebSocket support for real-time updates
- **File Handling**: Multer middleware for CSV file uploads with 50MB limit
- **Development**: Custom Vite middleware integration for hot module replacement

## Data Storage Architecture
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Schema Design**: Normalized tables for contacts, templates, campaigns, message logs, and contact lists
- **Database Provider**: Neon Database (@neondatabase/serverless)
- **Migrations**: Drizzle Kit for schema migrations and database management

## Real-time Communication
- **WebSocket Integration**: Custom WebSocket server for campaign progress updates
- **Connection Management**: Automatic reconnection with exponential backoff
- **Event Broadcasting**: Real-time updates for campaign status and message delivery

## Authentication & Session Management
- **Session Storage**: PostgreSQL-based session management with connect-pg-simple
- **Security**: Express session middleware with secure cookie configuration

## File Processing Architecture
- **CSV Parsing**: Papa Parse library for robust CSV file processing
- **Contact Validation**: Custom phone number validation and formatting
- **Bulk Operations**: Optimized batch processing for large contact lists

## Component Architecture
- **Design System**: Consistent component library with variants and themes
- **Form Handling**: React Hook Form with Zod validation schemas
- **Data Fetching**: Custom hooks for API interactions and WebSocket connections
- **Error Handling**: Global error boundaries with toast notifications

# External Dependencies

## Database Services
- **Neon Database**: Serverless PostgreSQL hosting and management
- **Drizzle ORM**: Type-safe database operations and schema management

## Development Tools
- **Replit Integration**: Custom Vite plugins for development environment
- **TypeScript**: Static type checking and enhanced developer experience
- **ESLint/Prettier**: Code quality and formatting tools

## UI and Styling
- **Radix UI**: Accessible component primitives for complex UI elements
- **Tailwind CSS**: Utility-first CSS framework with custom design tokens
- **Lucide React**: Icon library for consistent iconography

## Form and Data Handling
- **React Hook Form**: Performant form management with validation
- **Zod**: Schema validation for type-safe data handling
- **Papa Parse**: CSV parsing and data processing

## Utilities and Libraries
- **date-fns**: Date manipulation and formatting utilities
- **clsx**: Conditional className utility for dynamic styling
- **nanoid**: Unique ID generation for database records