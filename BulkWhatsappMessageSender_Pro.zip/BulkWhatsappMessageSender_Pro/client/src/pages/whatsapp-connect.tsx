import { useEffect, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Loader2, Smartphone, Wifi, WifiOff, RefreshCw, LogOut, ArrowLeftRight } from "lucide-react";

type ConnectionStatus = "disconnected" | "initializing" | "qr_ready" | "connected" | "auth_failed";

interface WhatsAppState {
  status: ConnectionStatus;
  qrDataUrl: string | null;
  phoneNumber: string | null;
}

export default function WhatsAppConnect() {
  const queryClient = useQueryClient();
  const [wsState, setWsState] = useState<WhatsAppState | null>(null);

  const { data: apiState } = useQuery<WhatsAppState>({
    queryKey: ["/api/whatsapp/status"],
    refetchInterval: 3000,
  });

  // Merge api state with live WebSocket state
  const state: WhatsAppState = wsState ?? apiState ?? { status: "disconnected", qrDataUrl: null, phoneNumber: null };

  // WebSocket for live QR + status updates
  useEffect(() => {
    const protocol = window.location.protocol === "https:" ? "wss" : "ws";
    const ws = new WebSocket(`${protocol}://${window.location.host}/ws`);

    ws.onmessage = (e) => {
      try {
        const msg = JSON.parse(e.data);
        if (msg.type === "whatsapp_status") {
          setWsState(msg.data);
          queryClient.invalidateQueries({ queryKey: ["/api/whatsapp/status"] });
        }
      } catch (_) {}
    };

    return () => ws.close();
  }, [queryClient]);

  const connectMutation = useMutation({
    mutationFn: () => apiRequest("POST", "/api/whatsapp/connect"),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/whatsapp/status"] });
    },
  });

  const disconnectMutation = useMutation({
    mutationFn: () => apiRequest("POST", "/api/whatsapp/disconnect"),
    onSuccess: () => {
      setWsState({ status: "disconnected", qrDataUrl: null, phoneNumber: null });
      queryClient.invalidateQueries({ queryKey: ["/api/whatsapp/status"] });
    },
  });

  const statusConfig: Record<ConnectionStatus, { label: string; color: string; icon: any }> = {
    disconnected: { label: "Disconnected", color: "destructive", icon: WifiOff },
    initializing: { label: "Initializing…", color: "secondary", icon: Loader2 },
    qr_ready: { label: "Scan QR Code", color: "default", icon: Smartphone },
    connected: { label: "Connected", color: "default", icon: Wifi },
    auth_failed: { label: "Auth Failed", color: "destructive", icon: WifiOff },
  };

  const cfg = statusConfig[state.status];
  const StatusIcon = cfg.icon;

  return (
    <div className="flex-1 overflow-auto p-6">
      <header className="mb-6">
        <h2 className="text-xl font-semibold" data-testid="page-title">WhatsApp Connection</h2>
        <p className="text-muted-foreground text-sm">
          Connect your WhatsApp account to send real bulk messages
        </p>
      </header>

      <div className="max-w-2xl mx-auto space-y-6">

        {/* Status Card */}
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-base">Connection Status</CardTitle>
              <Badge
                variant={cfg.color === "destructive" ? "destructive" : cfg.color === "default" && state.status === "connected" ? "default" : "secondary"}
                className={state.status === "connected" ? "bg-green-500 text-white" : ""}
              >
                <StatusIcon className={`w-3 h-3 mr-1 ${state.status === "initializing" ? "animate-spin" : ""}`} />
                {cfg.label}
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            {state.status === "connected" && state.phoneNumber && (
              <p className="text-sm text-muted-foreground">
                Connected as <span className="font-medium text-foreground">+{state.phoneNumber}</span>
              </p>
            )}
            {state.status === "auth_failed" && (
              <p className="text-sm text-destructive">Authentication failed. Please try connecting again.</p>
            )}
            {state.status === "disconnected" && (
              <p className="text-sm text-muted-foreground">
                Not connected. Click "Connect WhatsApp" to scan a QR code with your phone.
              </p>
            )}
          </CardContent>
        </Card>

        {/* QR Code Card */}
        {(state.status === "qr_ready" || state.status === "initializing") && (
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Scan with WhatsApp</CardTitle>
            </CardHeader>
            <CardContent className="flex flex-col items-center space-y-4">
              {state.status === "initializing" && (
                <div className="flex flex-col items-center py-8 space-y-3">
                  <Loader2 className="w-12 h-12 animate-spin text-primary" />
                  <p className="text-muted-foreground text-sm">Starting WhatsApp Web, please wait…</p>
                </div>
              )}
              {state.status === "qr_ready" && state.qrDataUrl && (
                <>
                  <img
                    src={state.qrDataUrl}
                    alt="WhatsApp QR Code"
                    className="border-4 border-white rounded-lg shadow-lg"
                    data-testid="img-qr-code"
                    style={{ width: 280, height: 280 }}
                  />
                  <div className="text-center space-y-1">
                    <p className="font-medium text-sm">How to scan:</p>
                    <ol className="text-sm text-muted-foreground space-y-1 text-left list-decimal list-inside">
                      <li>Open WhatsApp on your phone</li>
                      <li>Tap Menu (⋮) → Linked Devices</li>
                      <li>Tap "Link a Device"</li>
                      <li>Point your camera at this QR code</li>
                    </ol>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => connectMutation.mutate()}
                    data-testid="button-refresh-qr"
                  >
                    <RefreshCw className="w-4 h-4 mr-2" />
                    Refresh QR Code
                  </Button>
                </>
              )}
            </CardContent>
          </Card>
        )}

        {/* Action Buttons */}
        <div className="flex gap-3 flex-wrap">
          {(state.status === "disconnected" || state.status === "auth_failed") && (
            <Button
              onClick={() => connectMutation.mutate()}
              disabled={connectMutation.isPending}
              className="flex-1"
              data-testid="button-connect-whatsapp"
            >
              {connectMutation.isPending ? (
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              ) : (
                <Smartphone className="w-4 h-4 mr-2" />
              )}
              Connect WhatsApp
            </Button>
          )}

          {state.status === "connected" && (
            <Button
              variant="outline"
              onClick={() => connectMutation.mutate()}
              disabled={connectMutation.isPending}
              className="flex-1"
              data-testid="button-switch-account"
            >
              {connectMutation.isPending ? (
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              ) : (
                <ArrowLeftRight className="w-4 h-4 mr-2" />
              )}
              Switch Account
            </Button>
          )}

          {(state.status === "connected" || state.status === "initializing" || state.status === "qr_ready") && (
            <Button
              variant="destructive"
              onClick={() => disconnectMutation.mutate()}
              disabled={disconnectMutation.isPending}
              data-testid="button-disconnect-whatsapp"
            >
              {disconnectMutation.isPending ? (
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              ) : (
                <LogOut className="w-4 h-4 mr-2" />
              )}
              Disconnect
            </Button>
          )}
        </div>

        {/* Info */}
        <Card className="border-amber-200 bg-amber-50 dark:bg-amber-950/20">
          <CardContent className="p-4">
            <p className="text-sm text-amber-800 dark:text-amber-200">
              <strong>Note:</strong> Only one WhatsApp account can be active at a time.
              Use <strong>Switch Account</strong> to let a different user connect their number —
              the current session will be logged out automatically.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
