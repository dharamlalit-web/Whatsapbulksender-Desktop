import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { type Campaign } from "@shared/schema";
import {
  BarChart2,
  Send,
  CheckCircle2,
  XCircle,
  Clock,
  Users,
  TrendingUp,
  CalendarClock,
} from "lucide-react";
import { formatDistanceToNow, format } from "date-fns";

export default function Analytics() {
  const { data: campaigns = [], isLoading: campaignsLoading } = useQuery<Campaign[]>({
    queryKey: ["/api/campaigns"],
  });

  const { data: stats, isLoading: statsLoading } = useQuery<any>({
    queryKey: ["/api/stats"],
  });

  const { data: contacts = [] } = useQuery<any[]>({
    queryKey: ["/api/contacts"],
  });

  const isLoading = campaignsLoading || statsLoading;

  // Aggregate metrics across all campaigns
  const totalSent = campaigns.reduce((s, c) => s + (c.sentCount ?? 0), 0);
  const totalDelivered = campaigns.reduce((s, c) => s + (c.deliveredCount ?? 0), 0);
  const totalFailed = campaigns.reduce((s, c) => s + (c.failedCount ?? 0), 0);
  const totalMessages = campaigns.reduce((s, c) => s + (c.totalContacts ?? 0), 0);

  const completed = campaigns.filter((c) => c.status === "completed").length;
  const running = campaigns.filter((c) => c.status === "running").length;
  const pending = campaigns.filter((c) => c.status === "pending").length;
  const failed = campaigns.filter((c) => c.status === "failed").length;

  const overallDeliveryRate =
    totalSent > 0 ? Math.round((totalDelivered / totalSent) * 100) : 0;
  const overallSuccessRate =
    totalMessages > 0 ? Math.round((totalSent / totalMessages) * 100) : 0;

  const statusColor: Record<string, string> = {
    completed: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200",
    running: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200",
    pending: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200",
    paused: "bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300",
    failed: "bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-300",
  };

  if (isLoading) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-auto">
      <header className="bg-card border-b border-border px-6 py-4">
        <h2 className="text-xl font-semibold" data-testid="page-title">Analytics</h2>
        <p className="text-muted-foreground text-sm">Campaign performance and delivery insights</p>
      </header>

      <div className="p-6 space-y-6">

        {/* Top KPI cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-5">
              <div className="flex items-center justify-between mb-3">
                <p className="text-sm text-muted-foreground">Total Campaigns</p>
                <BarChart2 className="h-4 w-4 text-primary" />
              </div>
              <p className="text-3xl font-bold" data-testid="stat-total-campaigns">{campaigns.length}</p>
              <p className="text-xs text-muted-foreground mt-1">
                {completed} completed · {running} running
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-5">
              <div className="flex items-center justify-between mb-3">
                <p className="text-sm text-muted-foreground">Messages Sent</p>
                <Send className="h-4 w-4 text-blue-500" />
              </div>
              <p className="text-3xl font-bold text-blue-600" data-testid="stat-total-sent">{totalSent}</p>
              <p className="text-xs text-muted-foreground mt-1">out of {totalMessages} total</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-5">
              <div className="flex items-center justify-between mb-3">
                <p className="text-sm text-muted-foreground">Delivery Rate</p>
                <CheckCircle2 className="h-4 w-4 text-green-500" />
              </div>
              <p className="text-3xl font-bold text-green-600" data-testid="stat-delivery-rate">{overallDeliveryRate}%</p>
              <p className="text-xs text-muted-foreground mt-1">{totalDelivered} delivered</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-5">
              <div className="flex items-center justify-between mb-3">
                <p className="text-sm text-muted-foreground">Total Contacts</p>
                <Users className="h-4 w-4 text-accent" />
              </div>
              <p className="text-3xl font-bold" data-testid="stat-total-contacts">
                {(contacts as any[]).length}
              </p>
              <p className="text-xs text-muted-foreground mt-1">in contact database</p>
            </CardContent>
          </Card>
        </div>

        {/* Overall progress bar */}
        <Card>
          <CardContent className="p-5">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold">Overall Message Delivery</h3>
              <span className="text-sm font-medium text-muted-foreground">{overallSuccessRate}% sent</span>
            </div>
            <div className="space-y-3">
              <div>
                <div className="flex justify-between text-xs text-muted-foreground mb-1">
                  <span>Sent</span><span>{totalSent} / {totalMessages}</span>
                </div>
                <Progress value={overallSuccessRate} className="h-2" />
              </div>
              <div className="grid grid-cols-3 gap-3 pt-2">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-green-500 flex-shrink-0" />
                  <div>
                    <p className="text-sm font-semibold text-green-600">{totalDelivered}</p>
                    <p className="text-xs text-muted-foreground">Delivered</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Send className="h-4 w-4 text-blue-500 flex-shrink-0" />
                  <div>
                    <p className="text-sm font-semibold text-blue-600">{totalSent - totalDelivered}</p>
                    <p className="text-xs text-muted-foreground">Sent (unread)</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <XCircle className="h-4 w-4 text-red-500 flex-shrink-0" />
                  <div>
                    <p className="text-sm font-semibold text-red-500">{totalFailed}</p>
                    <p className="text-xs text-muted-foreground">Failed</p>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Campaign status breakdown */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            { label: "Completed", count: completed, icon: CheckCircle2, color: "text-green-600", bg: "bg-green-50 dark:bg-green-950/30" },
            { label: "Running", count: running, icon: TrendingUp, color: "text-blue-600", bg: "bg-blue-50 dark:bg-blue-950/30" },
            { label: "Scheduled", count: pending, icon: CalendarClock, color: "text-yellow-600", bg: "bg-yellow-50 dark:bg-yellow-950/30" },
            { label: "Failed", count: failed, icon: XCircle, color: "text-red-500", bg: "bg-red-50 dark:bg-red-950/30" },
          ].map(({ label, count, icon: Icon, color, bg }) => (
            <Card key={label}>
              <CardContent className={`p-4 ${bg} rounded-lg`}>
                <div className="flex items-center gap-3">
                  <Icon className={`h-6 w-6 ${color} flex-shrink-0`} />
                  <div>
                    <p className={`text-2xl font-bold ${color}`}>{count}</p>
                    <p className="text-xs text-muted-foreground">{label}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Per-campaign table */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Campaign Breakdown</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            {campaigns.length === 0 ? (
              <div className="py-12 text-center text-muted-foreground">
                <BarChart2 className="h-10 w-10 mx-auto mb-3 opacity-30" />
                <p>No campaigns yet. Start a campaign to see analytics.</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-muted border-b border-border">
                    <tr>
                      <th className="text-left px-4 py-3 font-medium">Campaign</th>
                      <th className="text-left px-4 py-3 font-medium">Status</th>
                      <th className="text-right px-4 py-3 font-medium">Total</th>
                      <th className="text-right px-4 py-3 font-medium">Sent</th>
                      <th className="text-right px-4 py-3 font-medium">Delivered</th>
                      <th className="text-right px-4 py-3 font-medium">Failed</th>
                      <th className="text-right px-4 py-3 font-medium">Rate</th>
                      <th className="text-left px-4 py-3 font-medium">Created</th>
                    </tr>
                  </thead>
                  <tbody>
                    {[...campaigns].reverse().map((campaign) => {
                      const rate =
                        campaign.totalContacts > 0
                          ? Math.round(((campaign.sentCount ?? 0) / campaign.totalContacts) * 100)
                          : 0;
                      return (
                        <tr
                          key={campaign.id}
                          className="border-b border-border last:border-0 hover:bg-muted/50 transition-colors"
                          data-testid={`analytics-row-${campaign.id}`}
                        >
                          <td className="px-4 py-3 font-medium max-w-[180px] truncate">{campaign.name}</td>
                          <td className="px-4 py-3">
                            <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${statusColor[campaign.status] ?? "bg-muted text-muted-foreground"}`}>
                              {campaign.status.charAt(0).toUpperCase() + campaign.status.slice(1)}
                            </span>
                          </td>
                          <td className="px-4 py-3 text-right tabular-nums">{campaign.totalContacts}</td>
                          <td className="px-4 py-3 text-right tabular-nums text-blue-600">{campaign.sentCount ?? 0}</td>
                          <td className="px-4 py-3 text-right tabular-nums text-green-600">{campaign.deliveredCount ?? 0}</td>
                          <td className="px-4 py-3 text-right tabular-nums text-red-500">{campaign.failedCount ?? 0}</td>
                          <td className="px-4 py-3 text-right">
                            <div className="flex items-center justify-end gap-2">
                              <Progress value={rate} className="w-16 h-1.5" />
                              <span className="tabular-nums text-xs w-8 text-right">{rate}%</span>
                            </div>
                          </td>
                          <td className="px-4 py-3 text-muted-foreground text-xs whitespace-nowrap">
                            {campaign.createdAt
                              ? formatDistanceToNow(new Date(campaign.createdAt), { addSuffix: true })
                              : "—"}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                  <tfoot className="bg-muted/50 border-t border-border font-semibold">
                    <tr>
                      <td className="px-4 py-3" colSpan={2}>Totals</td>
                      <td className="px-4 py-3 text-right tabular-nums">{totalMessages}</td>
                      <td className="px-4 py-3 text-right tabular-nums text-blue-600">{totalSent}</td>
                      <td className="px-4 py-3 text-right tabular-nums text-green-600">{totalDelivered}</td>
                      <td className="px-4 py-3 text-right tabular-nums text-red-500">{totalFailed}</td>
                      <td className="px-4 py-3 text-right text-xs">{overallSuccessRate}%</td>
                      <td className="px-4 py-3" />
                    </tr>
                  </tfoot>
                </table>
              </div>
            )}
          </CardContent>
        </Card>

      </div>
    </div>
  );
}
