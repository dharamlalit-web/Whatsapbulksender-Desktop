import { useState, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Slider } from "@/components/ui/slider";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { readMediaFile } from "@/lib/compress-media";
import { type Campaign } from "@shared/schema";
import { PlusIcon, PlayIcon, PauseIcon, CheckCircledIcon, FileTextIcon, Cross1Icon } from "@radix-ui/react-icons";
import { CheckCircle2, XCircle, Clock, CalendarClock, ImageIcon, Music, Mic, Upload } from "lucide-react";
import { formatDistanceToNow, format } from "date-fns";

interface MediaFile {
  base64: string;
  mimeType: string;
  filename: string;
  previewUrl?: string;
}

export default function Campaigns() {
  const [selectedStatus, setSelectedStatus] = useState("all");
  const [auditCampaign, setAuditCampaign] = useState<Campaign | null>(null);
  const [showNew, setShowNew] = useState(false);
  const { toast } = useToast();

  // New campaign form state
  const [form, setForm] = useState({
    name: "",
    contactListId: "",
    message: "",
    delaySeconds: 5,
    scheduleType: "now" as "now" | "later",
    scheduledAt: "",
  });
  const [media, setMedia] = useState<MediaFile | null>(null);
  const mediaInputRef = useRef<HTMLInputElement>(null);

  const { data: campaigns, isLoading } = useQuery({
    queryKey: ["/api/campaigns"],
    refetchInterval: 5000,
  });

  const { data: contactLists = [] } = useQuery<any[]>({
    queryKey: ["/api/contact-lists"],
  });

  const { data: templates = [] } = useQuery<any[]>({
    queryKey: ["/api/templates"],
  });

  const { data: auditLogs, isLoading: auditLoading } = useQuery<any[]>({
    queryKey: ["/api/campaigns", auditCampaign?.id, "logs"],
    queryFn: async () => {
      if (!auditCampaign) return [];
      const r = await fetch(`/api/campaigns/${auditCampaign.id}/logs`);
      return r.json();
    },
    enabled: !!auditCampaign,
  });

  const pauseCampaignMutation = useMutation({
    mutationFn: (id: string) => apiRequest("POST", `/api/campaigns/${id}/pause`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/campaigns"] });
      toast({ title: "Paused", description: "Campaign paused successfully" });
    },
  });

  const startCampaignMutation = useMutation({
    mutationFn: (id: string) => apiRequest("POST", `/api/campaigns/${id}/start`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/campaigns"] });
      toast({ title: "Resumed", description: "Campaign resumed successfully" });
    },
  });

  const deleteCampaignMutation = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/campaigns/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/campaigns"] });
      toast({ title: "Deleted", description: "Campaign deleted" });
    },
    onError: () => toast({ title: "Error", description: "Failed to delete campaign", variant: "destructive" }),
  });

  const cancelScheduleMutation = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/campaigns/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/campaigns"] });
      toast({ title: "Cancelled", description: "Scheduled campaign cancelled" });
    },
    onError: () => toast({ title: "Error", description: "Failed to cancel", variant: "destructive" }),
  });

  const createCampaignMutation = useMutation({
    mutationFn: async () => {
      const list = (contactLists as any[]).find((l: any) => l.id === form.contactListId);
      if (!list) throw new Error("Select a contact list");
      if (!form.message.trim()) throw new Error("Message cannot be empty");
      if (!form.name.trim()) throw new Error("Campaign name is required");

      const contactsRes = await fetch("/api/contacts");
      const allContacts: any[] = await contactsRes.json();

      const listsRes = await fetch(`/api/contact-lists/${form.contactListId}/contacts`).catch(() => null);
      let contactIds: string[];

      if (listsRes && listsRes.ok) {
        const listContacts = await listsRes.json();
        contactIds = listContacts.map((c: any) => c.id);
      } else {
        contactIds = allContacts.slice(0, list.contactCount).map((c: any) => c.id);
      }

      const payload: any = {
        name: form.name,
        message: form.message,
        contactIds,
        totalContacts: contactIds.length,
        sendingPace: "medium",
        delaySeconds: form.delaySeconds,
        status: form.scheduleType === "later" ? "pending" : "pending",
        scheduledAt: form.scheduleType === "later" && form.scheduledAt ? new Date(form.scheduledAt).toISOString() : null,
        mediaBase64: media?.base64 ?? null,
        mediaFilename: media?.filename ?? null,
        mediaMimeType: media?.mimeType ?? null,
      };

      const resp = await apiRequest("POST", "/api/campaigns", payload);
      const campaign = await resp.json();

      if (form.scheduleType === "now") {
        await apiRequest("POST", `/api/campaigns/${campaign.id}/start`);
      }

      return campaign;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/campaigns"] });
      queryClient.invalidateQueries({ queryKey: ["/api/campaigns/active"] });
      toast({
        title: form.scheduleType === "later" ? "Campaign scheduled!" : "Campaign started!",
        description: form.scheduleType === "later"
          ? `Will send at ${format(new Date(form.scheduledAt), "dd MMM yyyy, hh:mm a")}`
          : "Messages are being sent now.",
      });
      setShowNew(false);
      resetForm();
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message || "Failed to create campaign", variant: "destructive" });
    },
  });

  const resetForm = () => {
    setForm({ name: "", contactListId: "", message: "", delaySeconds: 5, scheduleType: "now", scheduledAt: "" });
    setMedia(null);
  };

  const handleMediaPick = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    e.target.value = "";
    try {
      const result = await readMediaFile(file);
      setMedia(result);
    } catch {
      toast({ title: "Error", description: "Could not read file", variant: "destructive" });
    }
  };

  const mediaTypeIcon = (mimeType: string) => {
    if (mimeType.startsWith("image/")) return <ImageIcon className="h-4 w-4" />;
    if (mimeType.startsWith("audio/ogg")) return <Mic className="h-4 w-4" />;
    return <Music className="h-4 w-4" />;
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "running":
        return <Badge className="bg-secondary text-secondary-foreground">Running</Badge>;
      case "completed":
        return <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">Completed</Badge>;
      case "paused":
        return <Badge variant="outline">Paused</Badge>;
      case "failed":
        return <Badge variant="destructive">Failed</Badge>;
      case "pending":
        return <Badge variant="secondary">Scheduled</Badge>;
      default:
        return <Badge variant="secondary">Pending</Badge>;
    }
  };

  const getProgressPercentage = (campaign: Campaign) => {
    if (campaign.totalContacts === 0) return 0;
    return Math.round((campaign.sentCount! / campaign.totalContacts) * 100);
  };

  const filteredCampaigns = (campaigns as Campaign[] | undefined)?.filter((campaign) => {
    if (selectedStatus === "all") return true;
    return campaign.status === selectedStatus;
  });

  const auditSent = auditLogs?.filter(l => l.status === "sent").length ?? 0;
  const auditFailed = auditLogs?.filter(l => l.status === "failed").length ?? 0;

  return (
    <>
      <header className="bg-card border-b border-border px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-semibold" data-testid="page-title">Campaign Management</h2>
            <p className="text-muted-foreground text-sm">Monitor and manage your messaging campaigns</p>
          </div>
          <Button onClick={() => setShowNew(true)} data-testid="button-new-campaign">
            <PlusIcon className="mr-2 h-4 w-4" />
            New Campaign
          </Button>
        </div>
      </header>

      <div className="flex-1 overflow-auto p-6 space-y-6">
        {/* Status Filter */}
        <Card>
          <CardContent className="p-4">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-sm font-medium mr-2">Filter:</span>
              {["all", "pending", "running", "paused", "completed", "failed"].map((status) => (
                <Button
                  key={status}
                  variant={selectedStatus === status ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedStatus(status)}
                  data-testid={`button-filter-${status}`}
                >
                  {status === "pending" ? "Scheduled" : status.charAt(0).toUpperCase() + status.slice(1)}
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Campaigns List */}
        <div className="space-y-4">
          {isLoading ? (
            <div className="flex items-center justify-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
            </div>
          ) : (
            <>
              {filteredCampaigns?.map((campaign: Campaign) => (
                <Card key={campaign.id} className="hover:shadow-lg transition-shadow" data-testid={`campaign-${campaign.id}`}>
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-start space-x-4">
                        <div className="w-3 h-3 bg-secondary rounded-full mt-2" />
                        <div>
                          <h3 className="text-lg font-semibold">{campaign.name}</h3>
                          <p className="text-sm text-muted-foreground">
                            Created {formatDistanceToNow(new Date(campaign.createdAt!))} ago
                          </p>
                          {campaign.startedAt && (
                            <p className="text-sm text-muted-foreground">
                              Started {formatDistanceToNow(new Date(campaign.startedAt))} ago
                            </p>
                          )}
                          {campaign.status === "pending" && campaign.scheduledAt && (
                            <div className="flex items-center gap-1.5 mt-1 text-sm text-accent">
                              <CalendarClock className="h-3.5 w-3.5" />
                              <span>Scheduled: {format(new Date(campaign.scheduledAt), "dd MMM yyyy, hh:mm a")}</span>
                            </div>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center gap-2 flex-wrap justify-end">
                        <div className="text-right mr-1">
                          <p className="text-sm font-medium">
                            {campaign.sentCount} / {campaign.totalContacts}
                          </p>
                          <p className="text-xs text-muted-foreground">messages sent</p>
                        </div>
                        {getStatusBadge(campaign.status)}

                        {/* Report — show when messages have been sent */}
                        {(campaign.status === "completed" || campaign.status === "running" || (campaign.sentCount ?? 0) > 0) && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => setAuditCampaign(campaign)}
                            data-testid={`button-audit-${campaign.id}`}
                            title="View delivery report"
                          >
                            <FileTextIcon className="h-4 w-4 mr-1" />
                            Report
                          </Button>
                        )}

                        {/* Pause — running campaigns */}
                        {campaign.status === "running" && (
                          <Button
                            size="sm"
                            variant="outline"
                            className="text-amber-600 border-amber-300 hover:bg-amber-50"
                            onClick={() => pauseCampaignMutation.mutate(campaign.id)}
                            disabled={pauseCampaignMutation.isPending}
                            data-testid={`button-pause-${campaign.id}`}
                            title="Pause campaign"
                          >
                            <PauseIcon className="h-4 w-4 mr-1" />
                            Pause
                          </Button>
                        )}

                        {/* Resume — paused campaigns */}
                        {campaign.status === "paused" && (
                          <Button
                            size="sm"
                            variant="outline"
                            className="text-green-600 border-green-300 hover:bg-green-50"
                            onClick={() => startCampaignMutation.mutate(campaign.id)}
                            disabled={startCampaignMutation.isPending}
                            data-testid={`button-start-${campaign.id}`}
                            title="Resume campaign"
                          >
                            <PlayIcon className="h-4 w-4 mr-1" />
                            Resume
                          </Button>
                        )}

                        {/* Cancel Schedule — pending/scheduled campaigns */}
                        {campaign.status === "pending" && campaign.scheduledAt && (
                          <Button
                            size="sm"
                            variant="outline"
                            className="text-orange-600 border-orange-300 hover:bg-orange-50"
                            onClick={() => cancelScheduleMutation.mutate(campaign.id)}
                            disabled={cancelScheduleMutation.isPending}
                            data-testid={`button-cancel-schedule-${campaign.id}`}
                            title="Cancel scheduled campaign"
                          >
                            <Cross1Icon className="h-3.5 w-3.5 mr-1" />
                            Cancel
                          </Button>
                        )}

                        {/* Delete — completed / failed / unscheduled pending */}
                        {(campaign.status === "completed" || campaign.status === "failed" ||
                          (campaign.status === "pending" && !campaign.scheduledAt)) && (
                          <Button
                            size="sm"
                            variant="outline"
                            className="text-destructive border-destructive/30 hover:bg-destructive/10"
                            onClick={() => deleteCampaignMutation.mutate(campaign.id)}
                            disabled={deleteCampaignMutation.isPending}
                            data-testid={`button-delete-${campaign.id}`}
                            title="Delete campaign"
                          >
                            <Cross1Icon className="h-3.5 w-3.5 mr-1" />
                            Delete
                          </Button>
                        )}
                      </div>
                    </div>

                    {/* Stats Grid */}
                    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
                      <div className="text-center p-2 bg-green-50 dark:bg-green-950/30 rounded-lg">
                        <div className="text-lg font-bold text-green-600">{campaign.deliveredCount}</div>
                        <div className="text-xs text-muted-foreground">Delivered</div>
                      </div>
                      <div className="text-center p-2 bg-blue-50 dark:bg-blue-950/30 rounded-lg">
                        <div className="text-lg font-bold text-blue-600">{(campaign.sentCount ?? 0) - (campaign.deliveredCount ?? 0)}</div>
                        <div className="text-xs text-muted-foreground">Sent</div>
                      </div>
                      <div className="text-center p-2 bg-red-50 dark:bg-red-950/30 rounded-lg">
                        <div className="text-lg font-bold text-red-500">{campaign.failedCount}</div>
                        <div className="text-xs text-muted-foreground">Failed</div>
                      </div>
                      <div className="text-center p-2 bg-muted rounded-lg">
                        <div className="text-lg font-bold">{campaign.totalContacts - (campaign.sentCount ?? 0)}</div>
                        <div className="text-xs text-muted-foreground">Pending</div>
                      </div>
                    </div>

                    {/* Progress Bar */}
                    <div className="space-y-1">
                      <Progress value={getProgressPercentage(campaign)} className="h-2" />
                      <div className="flex justify-between items-center text-xs text-muted-foreground">
                        <span>{getProgressPercentage(campaign)}% complete</span>
                        {campaign.status === "running" && (
                          <span>~{Math.ceil((campaign.totalContacts - (campaign.sentCount ?? 0)) / 2)} min remaining</span>
                        )}
                        {campaign.status === "completed" && campaign.completedAt && (
                          <span>Completed {formatDistanceToNow(new Date(campaign.completedAt))} ago</span>
                        )}
                      </div>
                    </div>

                    {/* Message Preview */}
                    <div className="mt-4 p-3 bg-muted rounded-lg">
                      <p className="text-xs text-muted-foreground mb-1 font-medium">Message:</p>
                      <p className="text-sm">{campaign.message.slice(0, 150)}{campaign.message.length > 150 ? "..." : ""}</p>
                    </div>
                  </CardContent>
                </Card>
              ))}

              {(!filteredCampaigns || filteredCampaigns.length === 0) && (
                <div className="text-center py-12">
                  <CheckCircledIcon className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-medium mb-2">No campaigns found</h3>
                  <p className="text-muted-foreground mb-4">
                    {selectedStatus !== "all"
                      ? `No campaigns with status "${selectedStatus}".`
                      : "Click \"New Campaign\" above to get started."}
                  </p>
                </div>
              )}
            </>
          )}
        </div>
      </div>

      {/* New Campaign Dialog */}
      <Dialog open={showNew} onOpenChange={(open) => { if (!open) { setShowNew(false); resetForm(); } }}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>New Campaign</DialogTitle>
          </DialogHeader>
          <div className="space-y-5 py-2">
            {/* Name */}
            <div className="space-y-1.5">
              <Label htmlFor="nc-name">Campaign Name *</Label>
              <Input
                id="nc-name"
                placeholder="e.g. Diwali Offer 2026"
                value={form.name}
                onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
                data-testid="input-campaign-name"
              />
            </div>

            {/* Contact List */}
            <div className="space-y-1.5">
              <Label>Contact List *</Label>
              <Select value={form.contactListId} onValueChange={(v) => setForm((f) => ({ ...f, contactListId: v }))}>
                <SelectTrigger data-testid="select-contact-list">
                  <SelectValue placeholder="Select a contact list…" />
                </SelectTrigger>
                <SelectContent>
                  {(contactLists as any[]).map((l: any) => (
                    <SelectItem key={l.id} value={l.id}>
                      {l.name} ({l.contactCount} contacts)
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Template picker */}
            {(templates as any[]).length > 0 && (
              <div className="space-y-1.5">
                <Label>Use Template (optional)</Label>
                <Select onValueChange={(id) => {
                  const t = (templates as any[]).find((t: any) => t.id === id);
                  if (t) setForm((f) => ({ ...f, message: t.content }));
                }}>
                  <SelectTrigger data-testid="select-template">
                    <SelectValue placeholder="Pick a template…" />
                  </SelectTrigger>
                  <SelectContent>
                    {(templates as any[]).map((t: any) => (
                      <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            {/* Message */}
            <div className="space-y-1.5">
              <Label htmlFor="nc-msg">Message *</Label>
              <Textarea
                id="nc-msg"
                rows={5}
                placeholder="Hi {{name}}, here's our latest offer…"
                value={form.message}
                onChange={(e) => setForm((f) => ({ ...f, message: e.target.value }))}
                data-testid="textarea-message"
              />
              <p className="text-xs text-muted-foreground">
                Use &#123;&#123;name&#125;&#125;, &#123;&#123;company&#125;&#125;, &#123;&#123;phone&#125;&#125; for personalization
              </p>
            </div>

            {/* Media Attachment */}
            <div className="space-y-1.5">
              <Label>Attach Media (optional)</Label>
              <input
                ref={mediaInputRef}
                type="file"
                accept="image/*,audio/*,video/ogg"
                className="hidden"
                onChange={handleMediaPick}
                data-testid="input-media-file"
              />
              {media ? (
                <div className="flex items-center gap-3 p-3 border border-border rounded-lg">
                  {media.previewUrl ? (
                    <img src={media.previewUrl} alt="preview" className="h-12 w-12 object-cover rounded" />
                  ) : (
                    <div className="h-12 w-12 bg-muted rounded flex items-center justify-center text-muted-foreground">
                      {mediaTypeIcon(media.mimeType)}
                    </div>
                  )}
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{media.filename}</p>
                    <p className="text-xs text-muted-foreground">{media.mimeType}</p>
                  </div>
                  <Button size="sm" variant="ghost" onClick={() => setMedia(null)} data-testid="button-remove-media">
                    <Cross1Icon className="h-3 w-3" />
                  </Button>
                </div>
              ) : (
                <div className="flex gap-2">
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => mediaInputRef.current?.click()}
                    data-testid="button-attach-media"
                  >
                    <ImageIcon className="h-4 w-4 mr-1.5" />
                    Image
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      if (mediaInputRef.current) {
                        mediaInputRef.current.accept = "audio/mpeg,audio/mp3";
                        mediaInputRef.current.click();
                      }
                    }}
                    data-testid="button-attach-audio"
                  >
                    <Music className="h-4 w-4 mr-1.5" />
                    MP3
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      if (mediaInputRef.current) {
                        mediaInputRef.current.accept = "audio/ogg";
                        mediaInputRef.current.click();
                      }
                    }}
                    data-testid="button-attach-voice"
                  >
                    <Mic className="h-4 w-4 mr-1.5" />
                    Voice
                  </Button>
                </div>
              )}
              <p className="text-xs text-muted-foreground">
                Image: sent with caption • MP3: audio message • Voice (OGG): voice note
              </p>
            </div>

            {/* Delay */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label>Delay between messages</Label>
                <span className="font-bold text-primary">{form.delaySeconds}s</span>
              </div>
              <Slider
                min={5}
                max={60}
                step={1}
                value={[form.delaySeconds]}
                onValueChange={([v]) => setForm((f) => ({ ...f, delaySeconds: v }))}
                data-testid="slider-campaign-delay"
              />
              <div className="flex gap-2">
                {[5, 8, 10, 15, 30].map((s) => (
                  <Button
                    key={s}
                    size="sm"
                    variant={form.delaySeconds === s ? "default" : "outline"}
                    onClick={() => setForm((f) => ({ ...f, delaySeconds: s }))}
                    data-testid={`button-campaign-delay-${s}`}
                  >
                    {s}s
                  </Button>
                ))}
              </div>
            </div>

            {/* Schedule */}
            <div className="space-y-2">
              <Label>When to send</Label>
              <div className="flex gap-2">
                <Button
                  variant={form.scheduleType === "now" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setForm((f) => ({ ...f, scheduleType: "now" }))}
                  data-testid="button-send-now"
                >
                  Send Now
                </Button>
                <Button
                  variant={form.scheduleType === "later" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setForm((f) => ({ ...f, scheduleType: "later" }))}
                  data-testid="button-schedule-later"
                >
                  <CalendarClock className="h-4 w-4 mr-1.5" />
                  Schedule
                </Button>
              </div>
              {form.scheduleType === "later" && (
                <Input
                  type="datetime-local"
                  value={form.scheduledAt}
                  onChange={(e) => setForm((f) => ({ ...f, scheduledAt: e.target.value }))}
                  min={(() => { const now = new Date(); return new Date(now.getTime() - now.getTimezoneOffset() * 60000).toISOString().slice(0, 16); })()}
                  data-testid="input-scheduled-at"
                />
              )}
            </div>

            {/* Actions */}
            <div className="flex gap-3 justify-end pt-2">
              <Button variant="outline" onClick={() => { setShowNew(false); resetForm(); }} data-testid="button-cancel-campaign">
                Cancel
              </Button>
              <Button
                onClick={() => createCampaignMutation.mutate()}
                disabled={createCampaignMutation.isPending}
                data-testid="button-create-campaign"
              >
                {createCampaignMutation.isPending
                  ? "Creating…"
                  : form.scheduleType === "later"
                  ? "Schedule Campaign"
                  : "Start Campaign"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Audit Log Dialog */}
      <Dialog open={!!auditCampaign} onOpenChange={(open) => !open && setAuditCampaign(null)}>
        <DialogContent className="max-w-2xl max-h-[80vh] flex flex-col">
          <DialogHeader>
            <DialogTitle>Delivery Report — {auditCampaign?.name}</DialogTitle>
          </DialogHeader>

          {/* Summary row */}
          {auditCampaign && (
            <div className="grid grid-cols-3 gap-3 mb-2">
              <div className="flex items-center gap-2 p-3 bg-green-50 dark:bg-green-950/30 rounded-lg">
                <CheckCircle2 className="h-5 w-5 text-green-600 shrink-0" />
                <div>
                  <p className="text-xs text-muted-foreground">Sent</p>
                  <p className="font-bold text-green-600">{auditSent}</p>
                </div>
              </div>
              <div className="flex items-center gap-2 p-3 bg-red-50 dark:bg-red-950/30 rounded-lg">
                <XCircle className="h-5 w-5 text-red-500 shrink-0" />
                <div>
                  <p className="text-xs text-muted-foreground">Failed</p>
                  <p className="font-bold text-red-500">{auditFailed}</p>
                </div>
              </div>
              <div className="flex items-center gap-2 p-3 bg-muted rounded-lg">
                <Clock className="h-5 w-5 text-muted-foreground shrink-0" />
                <div>
                  <p className="text-xs text-muted-foreground">Total</p>
                  <p className="font-bold">{auditCampaign.totalContacts}</p>
                </div>
              </div>
            </div>
          )}

          {/* Per-contact table */}
          <div className="overflow-auto flex-1 border rounded-lg">
            {auditLoading ? (
              <div className="flex items-center justify-center py-8">
                <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary" />
              </div>
            ) : (
              <table className="w-full text-sm">
                <thead className="bg-muted sticky top-0">
                  <tr>
                    <th className="text-left px-4 py-2 font-medium">#</th>
                    <th className="text-left px-4 py-2 font-medium">Name</th>
                    <th className="text-left px-4 py-2 font-medium">Phone</th>
                    <th className="text-left px-4 py-2 font-medium">Status</th>
                    <th className="text-left px-4 py-2 font-medium">Sent At</th>
                    <th className="text-left px-4 py-2 font-medium">Delivered At</th>
                    <th className="text-left px-4 py-2 font-medium">Reason</th>
                  </tr>
                </thead>
                <tbody>
                  {auditLogs?.map((log, idx) => (
                    <tr key={log.id} className="border-t border-border hover:bg-muted/50" data-testid={`audit-row-${log.id}`}>
                      <td className="px-4 py-2 text-muted-foreground">{idx + 1}</td>
                      <td className="px-4 py-2 font-medium">{log.contactName}</td>
                      <td className="px-4 py-2 text-muted-foreground">{log.contactPhone}</td>
                      <td className="px-4 py-2">
                        {log.status === "sent" ? (
                          <span className="flex items-center gap-1 text-green-600">
                            <CheckCircle2 className="h-3.5 w-3.5" /> Sent
                          </span>
                        ) : (
                          <span className="flex items-center gap-1 text-red-500">
                            <XCircle className="h-3.5 w-3.5" /> Failed
                          </span>
                        )}
                      </td>
                      <td className="px-4 py-2 text-xs text-muted-foreground whitespace-nowrap">
                        {log.sentAt
                          ? format(new Date(log.sentAt), "dd MMM yy, hh:mm:ss a")
                          : "—"}
                      </td>
                      <td className="px-4 py-2 text-xs text-muted-foreground whitespace-nowrap">
                        {log.deliveredAt
                          ? format(new Date(log.deliveredAt), "dd MMM yy, hh:mm:ss a")
                          : "—"}
                      </td>
                      <td className="px-4 py-2 text-muted-foreground text-xs max-w-[160px] truncate" title={log.error ?? ""}>
                        {log.error ?? "—"}
                      </td>
                    </tr>
                  ))}
                  {(!auditLogs || auditLogs.length === 0) && (
                    <tr>
                      <td colSpan={7} className="px-4 py-8 text-center text-muted-foreground">
                        No message logs yet — logs appear as the campaign runs.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
