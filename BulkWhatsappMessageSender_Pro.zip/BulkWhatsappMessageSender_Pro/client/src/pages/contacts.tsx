import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertContactSchema, type Contact } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { PlusIcon, PersonIcon, CheckCircledIcon, Cross1Icon } from "@radix-ui/react-icons";
import UploadArea from "@/components/upload-area";

export default function Contacts() {
  const [searchTerm, setSearchTerm] = useState("");
  const { toast } = useToast();

  const { data: contacts, isLoading } = useQuery({
    queryKey: ["/api/contacts"],
  });

  const { data: contactLists } = useQuery({
    queryKey: ["/api/contact-lists"],
  });

  const createContactMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/contacts", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/contacts"] });
      toast({ title: "Success", description: "Contact created successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to create contact", variant: "destructive" });
    },
  });

  const deleteListMutation = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/contact-lists/${id}`),
    onSuccess: async () => {
      await queryClient.refetchQueries({ queryKey: ["/api/contact-lists"] });
      toast({ title: "Deleted", description: "Contact list removed." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to delete contact list.", variant: "destructive" });
    },
  });

  const deleteContactMutation = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/contacts/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/contacts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      toast({ title: "Deleted", description: "Contact removed." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to delete contact.", variant: "destructive" });
    },
  });

  const form = useForm({
    resolver: zodResolver(insertContactSchema),
    defaultValues: {
      name: "",
      phone: "",
      company: "",
      email: "",
    },
  });

  const onSubmit = (data: any) => {
    createContactMutation.mutate(data);
  };

  const filteredContacts = (contacts as Contact[])?.filter((contact: Contact) =>
    contact.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    contact.phone.includes(searchTerm) ||
    contact.company?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <>
      {/* Header */}
      <header className="bg-card border-b border-border px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-semibold" data-testid="page-title">Contact Management</h2>
            <p className="text-muted-foreground text-sm">Manage your contact lists and individual contacts</p>
          </div>
          <Dialog>
            <DialogTrigger asChild>
              <Button data-testid="button-add-contact">
                <PlusIcon className="mr-2 h-4 w-4" />
                Add Contact
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add New Contact</DialogTitle>
              </DialogHeader>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Name</FormLabel>
                        <FormControl>
                          <Input placeholder="Contact name" {...field} data-testid="input-name" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="phone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Phone</FormLabel>
                        <FormControl>
                          <Input placeholder="+1234567890" {...field} data-testid="input-phone" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="company"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Company</FormLabel>
                        <FormControl>
                          <Input placeholder="Company name" {...field} data-testid="input-company" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email</FormLabel>
                        <FormControl>
                          <Input placeholder="email@example.com" {...field} data-testid="input-email" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <Button type="submit" disabled={createContactMutation.isPending} data-testid="button-submit">
                    {createContactMutation.isPending ? "Adding..." : "Add Contact"}
                  </Button>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>
      </header>

      {/* Content */}
      <div className="flex-1 overflow-auto p-6 space-y-6">

        {/* CSV Upload */}
        <UploadArea />

        {/* Contact Lists */}
        <Card>
          <CardHeader>
            <CardTitle>Contact Lists</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {(contactLists as any[])?.map((list: any) => (
                <div key={list.id} className="p-4 border border-border rounded-lg hover:bg-muted transition-colors">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-medium truncate pr-2">{list.name}</h4>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-6 w-6 p-0 shrink-0 text-muted-foreground hover:text-destructive"
                      onClick={() => deleteListMutation.mutate(list.id)}
                      disabled={deleteListMutation.isPending}
                      data-testid={`button-delete-list-${list.id}`}
                    >
                      <Cross1Icon className="h-3 w-3" />
                    </Button>
                  </div>
                  <Badge variant="secondary" className="mb-2">{list.contactCount} contacts</Badge>
                  <p className="text-sm text-muted-foreground">
                    Uploaded {new Date(list.uploadedAt).toLocaleDateString()}
                  </p>
                </div>
              ))}
              {(!contactLists || (contactLists as any[]).length === 0) && (
                <div className="col-span-full text-center py-8 text-muted-foreground">
                  No contact lists uploaded yet. Upload a CSV file from the dashboard to get started.
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Search and Filter */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Individual Contacts</CardTitle>
              <div className="flex items-center space-x-2">
                <Input
                  placeholder="Search contacts..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-64"
                  data-testid="input-search"
                />
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex items-center justify-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
              </div>
            ) : (
              <div className="space-y-4">
                {filteredContacts?.map((contact) => (
                  <div 
                    key={contact.id} 
                    className="flex items-center justify-between p-4 border border-border rounded-lg hover:bg-muted transition-colors"
                    data-testid={`contact-${contact.id}`}
                  >
                    <div className="flex items-center space-x-4">
                      <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                        <PersonIcon className="text-primary" />
                      </div>
                      <div>
                        <h4 className="font-medium">{contact.name}</h4>
                        <p className="text-sm text-muted-foreground">{contact.phone}</p>
                        {contact.company && (
                          <p className="text-xs text-muted-foreground">{contact.company}</p>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      {contact.isWhatsAppVerified ? (
                        <Badge variant="default" className="bg-secondary text-secondary-foreground">
                          <CheckCircledIcon className="mr-1 h-3 w-3" />
                          Verified
                        </Badge>
                      ) : (
                        <Badge variant="outline">Unverified</Badge>
                      )}
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-7 w-7 p-0 text-muted-foreground hover:text-destructive hover:bg-destructive/10"
                        onClick={() => deleteContactMutation.mutate(contact.id)}
                        disabled={deleteContactMutation.isPending}
                        data-testid={`button-delete-contact-${contact.id}`}
                      >
                        <Cross1Icon className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                ))}
                {(!filteredContacts || filteredContacts.length === 0) && (
                  <div className="text-center py-8 text-muted-foreground">
                    {searchTerm ? "No contacts match your search." : "No contacts found. Add some contacts to get started."}
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </>
  );
}
