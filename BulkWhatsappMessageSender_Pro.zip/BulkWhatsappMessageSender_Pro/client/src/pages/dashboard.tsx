import { useState, useRef } from "react";
import { useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import UploadArea from "@/components/upload-area";
import MessageComposer from "@/components/message-composer";
import CampaignTracker from "@/components/campaign-tracker";
import { PaperPlaneIcon, CheckCircledIcon, PersonIcon, BarChartIcon, Cross1Icon } from "@radix-ui/react-icons";
import { ArrowUpIcon, ArrowDownIcon, CheckCircle2, XCircle, Loader2, ImageIcon, Music, Mic, ShieldCheck } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { readMediaFile } from "@/lib/compress-media";

interface VerifyResult {
  phone: string;
  exists: boolean;
  whatsappId?: string;
  error?: string;
}

interface QuickMedia {
  base64: string;
  mimeType: string;
  filename: string;
  previewUrl?: string;
}

export default function Dashboard() {
  const [, navigate] = useLocation();
  const [showQuickSend, setShowQuickSend] = useState(false);
  const [quickPhones, setQuickPhones] = useState("");
  const [quickMessage, setQuickMessage] = useState("");
  const [quickMedia, setQuickMedia] = useState<QuickMedia | null>(null);
  const [quickResults, setQuickResults] = useState<{ phone: string; status: "sent" | "failed"; error?: string }[] | null>(null);
  const quickMediaRef = useRef<HTMLInputElement>(null);

  // Verify Numbers state
  const [showVerify, setShowVerify] = useState(false);
  const [verifyPhones, setVerifyPhones] = useState("");
  const [verifyResults, setVerifyResults] = useState<VerifyResult[] | null>(null);

  const { toast } = useToast();

  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/stats"],
  });

  const { data: templates } = useQuery({
    queryKey: ["/api/templates"],
  });

  const { data: activeCampaigns } = useQuery({
    queryKey: ["/api/campaigns/active"],
    refetchInterval: 4000,
  });

  const handleQuickMediaPick = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    e.target.value = "";
    try {
      const result = await readMediaFile(file);
      setQuickMedia(result);
    } catch {
      toast({ title: "Error", description: "Could not read file", variant: "destructive" });
    }
  };

  const quickSendMutation = useMutation({
    mutationFn: async () => {
      const phones = quickPhones
        .split(/[\n,]+/)
        .map((p) => p.trim())
        .filter(Boolean);
      if (!phones.length || !quickMessage.trim()) throw new Error("Fill in phone numbers and message");
      const resp = await apiRequest("POST", "/api/quick-send", {
        phones,
        message: quickMessage,
        mediaBase64: quickMedia?.base64 ?? undefined,
        mediaMimeType: quickMedia?.mimeType ?? undefined,
        mediaFilename: quickMedia?.filename ?? undefined,
      });
      return resp.json();
    },
    onSuccess: (data) => {
      setQuickResults(data.results);
      const sent = data.results.filter((r: any) => r.status === "sent").length;
      const failed = data.results.filter((r: any) => r.status === "failed").length;
      toast({
        title: "Quick Send Complete",
        description: `${sent} sent, ${failed} failed`,
        variant: failed > 0 ? "destructive" : "default",
      });
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message || "Quick send failed", variant: "destructive" });
    },
  });

  const handleQuickSendClose = () => {
    setShowQuickSend(false);
    setQuickPhones("");
    setQuickMessage("");
    setQuickMedia(null);
    setQuickResults(null);
  };

  const verifyMutation = useMutation({
    mutationFn: async () => {
      const phones = verifyPhones
        .split(/[\n,]+/)
        .map((p) => p.trim())
        .filter(Boolean);
      if (!phones.length) throw new Error("Enter at least one phone number");
      const resp = await apiRequest("POST", "/api/verify-numbers", { phones });
      return resp.json();
    },
    onSuccess: (data) => {
      setVerifyResults(data.results);
      const found = data.results.filter((r: VerifyResult) => r.exists).length;
      const notFound = data.results.length - found;
      toast({
        title: "Verification Complete",
        description: `${found} on WhatsApp · ${notFound} not found`,
      });
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message || "Verification failed", variant: "destructive" });
    },
  });

  const handleVerifyClose = () => {
    setShowVerify(false);
    setVerifyPhones("");
    setVerifyResults(null);
  };

  return (
    <>
      {/* Header */}
      <header className="bg-card border-b border-border px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-semibold" data-testid="page-title">Message Campaign Dashboard</h2>
            <p className="text-muted-foreground text-sm">Manage your WhatsApp bulk messaging campaigns</p>
          </div>
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2 bg-secondary/10 text-secondary px-3 py-2 rounded-md">
              <div className="w-2 h-2 bg-secondary rounded-full" />
              <span className="text-sm font-medium">WhatsApp Connected</span>
            </div>
            <Button data-testid="button-new-campaign" onClick={() => navigate("/campaigns")}>
              <PaperPlaneIcon className="mr-2 h-4 w-4" />
              New Campaign
            </Button>
          </div>
        </div>
      </header>

      {/* Dashboard Content */}
      <div className="flex-1 overflow-auto p-6 space-y-6">

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-muted-foreground text-sm">Messages Sent Today</p>
                  <p className="text-2xl font-bold mt-1" data-testid="stat-messages-sent">
                    {statsLoading ? <span className="inline-block h-7 w-10 rounded bg-muted animate-pulse" /> : ((stats as any)?.messagesSentToday || 0)}
                  </p>
                </div>
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                  <PaperPlaneIcon className="text-primary text-xl" />
                </div>
              </div>
              <div className="mt-4 flex items-center text-sm">
                <ArrowUpIcon className="h-4 w-4 text-secondary mr-1" />
                <span className="text-secondary font-medium">+12.5%</span>
                <span className="text-muted-foreground ml-1">from yesterday</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-muted-foreground text-sm">Delivery Rate</p>
                  <p className="text-2xl font-bold mt-1" data-testid="stat-delivery-rate">
                    {statsLoading ? <span className="inline-block h-7 w-14 rounded bg-muted animate-pulse" /> : `${((stats as any)?.deliveryRate || 0).toFixed(1)}%`}
                  </p>
                </div>
                <div className="w-12 h-12 bg-secondary/10 rounded-lg flex items-center justify-center">
                  <CheckCircledIcon className="text-secondary text-xl" />
                </div>
              </div>
              <div className="mt-4 flex items-center text-sm">
                <ArrowUpIcon className="h-4 w-4 text-secondary mr-1" />
                <span className="text-secondary font-medium">+2.1%</span>
                <span className="text-muted-foreground ml-1">this week</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-muted-foreground text-sm">Active Contacts</p>
                  <p className="text-2xl font-bold mt-1" data-testid="stat-active-contacts">
                    {statsLoading ? <span className="inline-block h-7 w-10 rounded bg-muted animate-pulse" /> : ((stats as any)?.activeContacts || 0)}
                  </p>
                </div>
                <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center">
                  <PersonIcon className="text-accent text-xl" />
                </div>
              </div>
              <div className="mt-4 flex items-center text-sm">
                <ArrowUpIcon className="h-4 w-4 text-secondary mr-1" />
                <span className="text-secondary font-medium">+156</span>
                <span className="text-muted-foreground ml-1">new this week</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-muted-foreground text-sm">Campaign Success</p>
                  <p className="text-2xl font-bold mt-1" data-testid="stat-campaign-success">
                    {statsLoading ? <span className="inline-block h-7 w-14 rounded bg-muted animate-pulse" /> : `${((stats as any)?.campaignSuccess || 0).toFixed(1)}%`}
                  </p>
                </div>
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                  <BarChartIcon className="text-primary text-xl" />
                </div>
              </div>
              <div className="mt-4 flex items-center text-sm">
                <ArrowDownIcon className="h-4 w-4 text-destructive mr-1" />
                <span className="text-destructive font-medium">-0.8%</span>
                <span className="text-muted-foreground ml-1">from last month</span>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
          {/* CSV Upload Section */}
          <div className="xl:col-span-2">
            <UploadArea />
          </div>

          {/* Quick Actions */}
          <div className="space-y-6">
            <Card>
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold mb-4">Quick Actions</h3>
                <div className="space-y-3">
                  <Button
                    variant="outline"
                    className="w-full justify-start"
                    data-testid="button-quick-send"
                    onClick={() => setShowQuickSend(true)}
                  >
                    <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center mr-3">
                      <PaperPlaneIcon className="text-primary" />
                    </div>
                    <div className="text-left">
                      <p className="font-medium">Quick Send</p>
                      <p className="text-xs text-muted-foreground">Send to numbers manually</p>
                    </div>
                  </Button>

                  <Button variant="outline" className="w-full justify-start" data-testid="button-schedule" onClick={() => navigate("/campaigns")}>
                    <div className="w-10 h-10 bg-accent/10 rounded-lg flex items-center justify-center mr-3">
                      <svg className="w-4 h-4 text-accent" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clipRule="evenodd" />
                      </svg>
                    </div>
                    <div className="text-left">
                      <p className="font-medium">Schedule Message</p>
                      <p className="text-xs text-muted-foreground">Schedule a campaign for later</p>
                    </div>
                  </Button>

                  <Button variant="outline" className="w-full justify-start" data-testid="button-verify" onClick={() => setShowVerify(true)}>
                    <div className="w-10 h-10 bg-secondary/10 rounded-lg flex items-center justify-center mr-3">
                      <CheckCircledIcon className="text-secondary" />
                    </div>
                    <div className="text-left">
                      <p className="font-medium">Verify Numbers</p>
                      <p className="text-xs text-muted-foreground">Check WhatsApp status</p>
                    </div>
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Message Templates */}
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold">Quick Templates</h3>
                  <Button variant="link" className="text-primary hover:text-primary/80 text-sm font-medium p-0" data-testid="link-view-templates" onClick={() => navigate("/templates")}>
                    View All
                  </Button>
                </div>
                <div className="space-y-3">
                  {(templates as any[])?.slice(0, 3)?.map((template: any) => (
                    <div
                      key={template.id}
                      className="p-3 border border-border rounded-md hover:bg-muted cursor-pointer"
                      data-testid={`template-${template.id}`}
                    >
                      <p className="font-medium text-sm">{template.name}</p>
                      <p className="text-xs text-muted-foreground mt-1">{template.content.slice(0, 50)}...</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Message Composition */}
        <MessageComposer />

        {/* Real-time Tracking */}
        {(activeCampaigns as any[])?.length > 0 && (
          <CampaignTracker campaigns={activeCampaigns} />
        )}

        {/* Recent Activity */}
        <Card>
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold mb-6">Recent Activity</h3>
            <div className="space-y-4">
              <div className="flex items-start space-x-4 p-4 hover:bg-muted rounded-lg transition-colors">
                <div className="w-8 h-8 bg-secondary/10 rounded-full flex items-center justify-center mt-0.5">
                  <CheckCircledIcon className="text-secondary text-sm" />
                </div>
                <div className="flex-1">
                  <p className="font-medium text-sm">System initialized successfully</p>
                  <p className="text-muted-foreground text-xs mt-1">WhatsApp bulk messaging system is ready</p>
                </div>
                <span className="text-xs text-muted-foreground">Just now</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Verify Numbers Dialog */}
      <Dialog open={showVerify} onOpenChange={(open) => { if (!open) handleVerifyClose(); }}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <ShieldCheck className="h-5 w-5 text-secondary" />
              Verify WhatsApp Numbers
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div>
              <Label htmlFor="verify-phones">Phone Numbers</Label>
              <Textarea
                id="verify-phones"
                className="mt-2 min-h-[120px] font-mono text-sm"
                placeholder={"Enter one number per line or comma-separated:\n+919876543210\n9876543210\n+14155552671"}
                value={verifyPhones}
                onChange={(e) => setVerifyPhones(e.target.value)}
                data-testid="textarea-verify-phones"
              />
              <p className="text-xs text-muted-foreground mt-1">
                Indian 10-digit numbers (starting 6–9) are auto-formatted. Include + country code for others.
              </p>
            </div>

            <div className="flex gap-2">
              <Button
                onClick={() => verifyMutation.mutate()}
                disabled={verifyMutation.isPending || !verifyPhones.trim()}
                className="flex-1"
                data-testid="button-run-verify"
              >
                {verifyMutation.isPending ? (
                  <><Loader2 className="h-4 w-4 mr-2 animate-spin" />Checking…</>
                ) : (
                  <><ShieldCheck className="h-4 w-4 mr-2" />Check Numbers</>
                )}
              </Button>
              {verifyResults && (
                <Button variant="outline" onClick={() => { setVerifyResults(null); setVerifyPhones(""); }} data-testid="button-verify-reset">
                  Reset
                </Button>
              )}
            </div>

            {/* Results */}
            {verifyResults && (
              <div className="border rounded-lg overflow-hidden">
                {/* Summary bar */}
                <div className="flex bg-muted px-4 py-2 text-sm font-medium gap-4 border-b">
                  <span className="text-green-600">
                    ✓ {verifyResults.filter(r => r.exists).length} on WhatsApp
                  </span>
                  <span className="text-red-500">
                    ✗ {verifyResults.filter(r => !r.exists).length} not found
                  </span>
                  <span className="text-muted-foreground ml-auto">
                    {verifyResults.length} total
                  </span>
                </div>
                <div className="max-h-64 overflow-y-auto divide-y divide-border">
                  {verifyResults.map((r, i) => (
                    <div key={i} className="flex items-center gap-3 px-4 py-2.5" data-testid={`verify-result-${i}`}>
                      {r.exists ? (
                        <CheckCircle2 className="h-4 w-4 text-green-600 flex-shrink-0" />
                      ) : (
                        <XCircle className="h-4 w-4 text-red-500 flex-shrink-0" />
                      )}
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-mono font-medium">{r.phone}</p>
                        {r.whatsappId && (
                          <p className="text-xs text-muted-foreground truncate">{r.whatsappId}</p>
                        )}
                        {r.error && (
                          <p className="text-xs text-red-500 truncate">{r.error}</p>
                        )}
                      </div>
                      <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${
                        r.exists
                          ? "bg-green-100 text-green-700 dark:bg-green-950 dark:text-green-300"
                          : "bg-red-100 text-red-600 dark:bg-red-950 dark:text-red-400"
                      }`}>
                        {r.exists ? "Active" : "Not Found"}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Quick Send Dialog */}
      <Dialog open={showQuickSend} onOpenChange={(open) => { if (!open) handleQuickSendClose(); }}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Quick Send</DialogTitle>
          </DialogHeader>

          {!quickResults ? (
            <div className="space-y-4">
              <div>
                <Label htmlFor="quick-phones">Phone Numbers</Label>
                <Textarea
                  id="quick-phones"
                  className="mt-2 min-h-[100px] font-mono text-sm"
                  placeholder={"Enter one number per line or comma-separated:\n+919876543210\n+918765432109\n..."}
                  value={quickPhones}
                  onChange={(e) => setQuickPhones(e.target.value)}
                  data-testid="textarea-quick-phones"
                />
                <p className="text-xs text-muted-foreground mt-1">
                  Indian 10-digit numbers (starting 6–9) are auto-formatted. Include country code for others.
                </p>
              </div>
              <div>
                <Label htmlFor="quick-message">Message</Label>
                <Textarea
                  id="quick-message"
                  className="mt-2 min-h-[100px] resize-none"
                  placeholder="Type your message here..."
                  value={quickMessage}
                  onChange={(e) => setQuickMessage(e.target.value)}
                  data-testid="textarea-quick-message"
                />
                <p className="text-xs text-muted-foreground mt-1">
                  {quickPhones.split(/[\n,]+/).filter(p => p.trim()).length} number(s) · {quickMessage.length} chars
                </p>
              </div>

              {/* Media Attachment */}
              <div>
                <Label>Attach Media (optional)</Label>
                <input
                  ref={quickMediaRef}
                  type="file"
                  accept="image/*,audio/*"
                  className="hidden"
                  onChange={handleQuickMediaPick}
                  data-testid="input-quick-media"
                />
                {quickMedia ? (
                  <div className="flex items-center gap-3 p-3 mt-2 border border-border rounded-lg">
                    {quickMedia.previewUrl ? (
                      <img src={quickMedia.previewUrl} alt="preview" className="h-10 w-10 object-cover rounded" />
                    ) : (
                      <div className="h-10 w-10 bg-muted rounded flex items-center justify-center text-muted-foreground">
                        {quickMedia.mimeType.startsWith("audio/ogg") ? <Mic className="h-4 w-4" /> : <Music className="h-4 w-4" />}
                      </div>
                    )}
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{quickMedia.filename}</p>
                      <p className="text-xs text-muted-foreground">{quickMedia.mimeType}</p>
                    </div>
                    <Button size="sm" variant="ghost" onClick={() => setQuickMedia(null)} data-testid="button-remove-quick-media">
                      <Cross1Icon className="h-3 w-3" />
                    </Button>
                  </div>
                ) : (
                  <div className="flex gap-2 mt-2">
                    <Button
                      type="button" variant="outline" size="sm"
                      onClick={() => { if (quickMediaRef.current) { quickMediaRef.current.accept = "image/*"; quickMediaRef.current.click(); } }}
                      data-testid="button-quick-attach-image"
                    >
                      <ImageIcon className="h-4 w-4 mr-1.5" />Image
                    </Button>
                    <Button
                      type="button" variant="outline" size="sm"
                      onClick={() => { if (quickMediaRef.current) { quickMediaRef.current.accept = "audio/mpeg,audio/mp3"; quickMediaRef.current.click(); } }}
                      data-testid="button-quick-attach-mp3"
                    >
                      <Music className="h-4 w-4 mr-1.5" />MP3
                    </Button>
                    <Button
                      type="button" variant="outline" size="sm"
                      onClick={() => { if (quickMediaRef.current) { quickMediaRef.current.accept = "audio/ogg"; quickMediaRef.current.click(); } }}
                      data-testid="button-quick-attach-voice"
                    >
                      <Mic className="h-4 w-4 mr-1.5" />Voice
                    </Button>
                  </div>
                )}
              </div>

              <div className="flex gap-3 justify-end">
                <Button variant="outline" onClick={handleQuickSendClose}>Cancel</Button>
                <Button
                  onClick={() => quickSendMutation.mutate()}
                  disabled={quickSendMutation.isPending || !quickPhones.trim() || !quickMessage.trim()}
                  data-testid="button-quick-send-submit"
                >
                  {quickSendMutation.isPending ? (
                    <><Loader2 className="mr-2 h-4 w-4 animate-spin" />Sending...</>
                  ) : (
                    <><PaperPlaneIcon className="mr-2 h-4 w-4" />Send Now</>
                  )}
                </Button>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              {/* Summary */}
              <div className="grid grid-cols-2 gap-3">
                <div className="flex items-center gap-2 p-3 bg-green-50 dark:bg-green-950/30 rounded-lg">
                  <CheckCircle2 className="h-5 w-5 text-green-600" />
                  <div>
                    <p className="text-xs text-muted-foreground">Sent</p>
                    <p className="font-bold text-green-600">{quickResults.filter(r => r.status === "sent").length}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2 p-3 bg-red-50 dark:bg-red-950/30 rounded-lg">
                  <XCircle className="h-5 w-5 text-red-500" />
                  <div>
                    <p className="text-xs text-muted-foreground">Failed</p>
                    <p className="font-bold text-red-500">{quickResults.filter(r => r.status === "failed").length}</p>
                  </div>
                </div>
              </div>

              {/* Per-number results */}
              <div className="border rounded-lg overflow-hidden max-h-60 overflow-y-auto">
                <table className="w-full text-sm">
                  <thead className="bg-muted sticky top-0">
                    <tr>
                      <th className="text-left px-3 py-2 font-medium">Phone</th>
                      <th className="text-left px-3 py-2 font-medium">Status</th>
                      <th className="text-left px-3 py-2 font-medium">Reason</th>
                    </tr>
                  </thead>
                  <tbody>
                    {quickResults.map((r, i) => (
                      <tr key={i} className="border-t border-border" data-testid={`quick-result-${i}`}>
                        <td className="px-3 py-2 font-mono text-xs">{r.phone}</td>
                        <td className="px-3 py-2">
                          {r.status === "sent" ? (
                            <span className="flex items-center gap-1 text-green-600 text-xs">
                              <CheckCircle2 className="h-3.5 w-3.5" /> Sent
                            </span>
                          ) : (
                            <span className="flex items-center gap-1 text-red-500 text-xs">
                              <XCircle className="h-3.5 w-3.5" /> Failed
                            </span>
                          )}
                        </td>
                        <td className="px-3 py-2 text-xs text-muted-foreground truncate max-w-[150px]" title={r.error ?? ""}>
                          {r.error ?? "—"}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="flex gap-3 justify-end">
                <Button variant="outline" onClick={() => setQuickResults(null)}>Send More</Button>
                <Button onClick={handleQuickSendClose}>Done</Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
