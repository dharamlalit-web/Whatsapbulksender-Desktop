import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Settings2, Clock, Shield, Info } from "lucide-react";

export default function Settings() {
  const { toast } = useToast();

  const { data: settings, isLoading } = useQuery<Record<string, any>>({
    queryKey: ["/api/settings"],
  });

  const [delaySeconds, setDelaySeconds] = useState<number | null>(null);

  const currentDelay = delaySeconds ?? (settings?.defaultDelaySeconds ?? 5);

  const saveSettingsMutation = useMutation({
    mutationFn: (data: Record<string, any>) => apiRequest("POST", "/api/settings", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
      toast({ title: "Settings saved", description: "Your preferences have been updated." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to save settings", variant: "destructive" });
    },
  });

  const handleSave = () => {
    saveSettingsMutation.mutate({ defaultDelaySeconds: currentDelay });
  };

  if (isLoading) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
      </div>
    );
  }

  return (
    <>
      <header className="bg-card border-b border-border px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-semibold" data-testid="page-title">Settings</h2>
            <p className="text-muted-foreground text-sm">Configure your BulkSender Pro preferences</p>
          </div>
          <Button onClick={handleSave} disabled={saveSettingsMutation.isPending} data-testid="button-save-settings">
            {saveSettingsMutation.isPending ? "Saving…" : "Save Settings"}
          </Button>
        </div>
      </header>

      <div className="flex-1 overflow-auto p-6 space-y-6">
        {/* Account Safety */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5 text-primary" />
              Account Safety
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label className="text-sm font-medium flex items-center gap-2">
                  <Clock className="h-4 w-4" />
                  Delay between messages
                </Label>
                <span className="text-2xl font-bold text-primary" data-testid="text-delay-value">
                  {currentDelay}s
                </span>
              </div>

              <Slider
                min={5}
                max={60}
                step={1}
                value={[currentDelay]}
                onValueChange={([v]) => setDelaySeconds(v)}
                className="w-full"
                data-testid="slider-delay"
              />

              <div className="flex justify-between text-xs text-muted-foreground">
                <span>5s (minimum safe)</span>
                <span>30s</span>
                <span>60s (safest)</span>
              </div>

              <div className="flex gap-2 flex-wrap">
                {[5, 8, 10, 15, 30, 60].map((s) => (
                  <Button
                    key={s}
                    size="sm"
                    variant={currentDelay === s ? "default" : "outline"}
                    onClick={() => setDelaySeconds(s)}
                    data-testid={`button-delay-${s}`}
                  >
                    {s}s
                  </Button>
                ))}
              </div>

              <div className="p-3 bg-amber-50 dark:bg-amber-950/30 rounded-lg border border-amber-200 dark:border-amber-800 flex gap-2 text-sm text-amber-800 dark:text-amber-200">
                <Info className="h-4 w-4 shrink-0 mt-0.5" />
                <div>
                  <strong>Recommended: 5–10 seconds minimum.</strong> Sending too fast risks getting your number flagged or banned by WhatsApp. A delay of 5–10 seconds mimics human behaviour and keeps your account safe.
                </div>
              </div>
            </div>

            <div className="space-y-1">
              <Label htmlFor="input-custom-delay" className="text-sm">Custom delay (seconds)</Label>
              <Input
                id="input-custom-delay"
                type="number"
                min={5}
                max={300}
                value={currentDelay}
                onChange={(e) => setDelaySeconds(Math.max(5, parseInt(e.target.value) || 5))}
                className="w-32"
                data-testid="input-custom-delay"
              />
              <p className="text-xs text-muted-foreground">Minimum 5 seconds</p>
            </div>
          </CardContent>
        </Card>

        {/* Sending Pace Reference */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Settings2 className="h-5 w-5 text-primary" />
              Sending Pace Reference
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {[
                { label: "Slow", delay: "15s", desc: "Safest — mimics casual messaging", color: "text-green-600" },
                { label: "Medium", delay: "8s", desc: "Balanced speed and safety", color: "text-blue-600" },
                { label: "Fast", delay: "5s", desc: "Minimum recommended delay", color: "text-amber-600" },
              ].map(({ label, delay, desc, color }) => (
                <div key={label} className="p-4 border border-border rounded-lg">
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-medium">{label}</span>
                    <span className={`font-bold ${color}`}>{delay}</span>
                  </div>
                  <p className="text-xs text-muted-foreground">{desc}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
