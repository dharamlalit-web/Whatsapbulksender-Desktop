import { useState, useEffect, useRef } from "react";

interface WebSocketHook {
  lastMessage: string | null;
  connectionStatus: "Connecting" | "Open" | "Closing" | "Closed";
  sendMessage: (message: string) => void;
}

export function useWebSocket(): WebSocketHook {
  const [lastMessage, setLastMessage] = useState<string | null>(null);
  const [connectionStatus, setConnectionStatus] = useState<"Connecting" | "Open" | "Closing" | "Closed">("Closed");
  const ws = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout>();
  const reconnectAttempts = useRef(0);
  const maxReconnectAttempts = 5;

  const connect = () => {
    try {
      const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
      const wsUrl = `${protocol}//${window.location.host}/ws`;
      
      ws.current = new WebSocket(wsUrl);
      setConnectionStatus("Connecting");

      ws.current.onopen = () => {
        setConnectionStatus("Open");
        reconnectAttempts.current = 0;
        console.log("WebSocket connected");
      };

      ws.current.onmessage = (event) => {
        setLastMessage(event.data);
      };

      ws.current.onclose = (event) => {
        setConnectionStatus("Closed");
        console.log("WebSocket disconnected:", event.code, event.reason);
        
        // Attempt to reconnect if not intentionally closed
        if (event.code !== 1000 && reconnectAttempts.current < maxReconnectAttempts) {
          const timeout = Math.min(1000 * Math.pow(2, reconnectAttempts.current), 30000);
          reconnectTimeoutRef.current = setTimeout(() => {
            reconnectAttempts.current++;
            console.log(`Attempting to reconnect... (${reconnectAttempts.current}/${maxReconnectAttempts})`);
            connect();
          }, timeout);
        }
      };

      ws.current.onerror = (error) => {
        console.error("WebSocket error:", error);
        setConnectionStatus("Closed");
      };

    } catch (error) {
      console.error("Failed to create WebSocket connection:", error);
      setConnectionStatus("Closed");
    }
  };

  const sendMessage = (message: string) => {
    if (ws.current && ws.current.readyState === WebSocket.OPEN) {
      ws.current.send(message);
    } else {
      console.warn("WebSocket is not connected");
    }
  };

  useEffect(() => {
    connect();

    return () => {
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
      }
      if (ws.current) {
        ws.current.close(1000, "Component unmounting");
      }
    };
  }, []);

  return {
    lastMessage,
    connectionStatus,
    sendMessage,
  };
}
