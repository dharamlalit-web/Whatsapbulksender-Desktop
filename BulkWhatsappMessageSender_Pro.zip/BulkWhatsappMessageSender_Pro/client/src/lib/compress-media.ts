const MAX_IMAGE_PX = 1280;
const JPEG_QUALITY = 0.82;

export interface MediaResult {
  base64: string;
  mimeType: string;
  filename: string;
  previewUrl?: string;
}

function compressImage(dataUrl: string, filename: string): Promise<MediaResult> {
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => {
      let { width, height } = img;
      if (width > MAX_IMAGE_PX || height > MAX_IMAGE_PX) {
        if (width >= height) {
          height = Math.round((height / width) * MAX_IMAGE_PX);
          width = MAX_IMAGE_PX;
        } else {
          width = Math.round((width / height) * MAX_IMAGE_PX);
          height = MAX_IMAGE_PX;
        }
      }
      const canvas = document.createElement("canvas");
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext("2d")!;
      ctx.drawImage(img, 0, 0, width, height);
      const compressed = canvas.toDataURL("image/jpeg", JPEG_QUALITY);
      resolve({
        base64: compressed.split(",")[1],
        mimeType: "image/jpeg",
        filename: filename.replace(/\.[^.]+$/, ".jpg"),
        previewUrl: compressed,
      });
    };
    img.src = dataUrl;
  });
}

export function readMediaFile(file: File): Promise<MediaResult> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("Failed to read file"));
    reader.onload = async (ev) => {
      const dataUrl = ev.target?.result as string;
      if (file.type.startsWith("image/")) {
        const result = await compressImage(dataUrl, file.name);
        resolve(result);
      } else {
        resolve({
          base64: dataUrl.split(",")[1],
          mimeType: file.type,
          filename: file.name,
        });
      }
    };
    reader.readAsDataURL(file);
  });
}
