import Papa from "papaparse";
import { type InsertContact } from "@shared/schema";

export interface CSVParseResult {
  contacts: InsertContact[];
  errors: string[];
  totalRows: number;
  validRows: number;
}

export interface CSVValidationOptions {
  requiredFields?: string[];
  maxRows?: number;
  allowEmptyFields?: boolean;
}

const DEFAULT_FIELD_MAPPING = {
  name: ["name", "full_name", "fullname", "contact_name", "customer_name"],
  phone: ["phone", "mobile", "number", "phone_number", "mobile_number", "contact_number"],
  company: ["company", "organization", "business", "company_name", "org"],
  email: ["email", "email_address", "e_mail", "mail"],
};

/**
 * Validates and formats a phone number
 */
function validatePhoneNumber(phone: string): string | null {
  if (!phone) return null;
  
  // Remove all non-digit characters except + at the beginning
  const cleaned = phone.replace(/[^\d+]/g, "");
  
  // Check if it's a valid phone number format
  if (cleaned.length < 7 || cleaned.length > 15) {
    return null;
  }
  
  // Ensure it starts with + if it doesn't already
  if (!cleaned.startsWith("+")) {
    // If it starts with 1 and is 10 digits, assume US number
    if (cleaned.length === 10 && !cleaned.startsWith("1")) {
      return `+1${cleaned}`;
    }
    // If it starts with 1 and is 11 digits, assume US number with country code
    if (cleaned.length === 11 && cleaned.startsWith("1")) {
      return `+${cleaned}`;
    }
    // For other formats, add + at the beginning
    return `+${cleaned}`;
  }
  
  return cleaned;
}

/**
 * Validates an email address
 */
function validateEmail(email: string): string | null {
  if (!email) return null;
  
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email.trim()) ? email.trim() : null;
}

/**
 * Maps CSV headers to standard field names
 */
function mapHeaders(headers: string[]): Record<string, string> {
  const mapping: Record<string, string> = {};
  
  headers.forEach((header, index) => {
    const normalizedHeader = header.toLowerCase().trim();
    
    // Find matching field
    for (const [fieldName, variations] of Object.entries(DEFAULT_FIELD_MAPPING)) {
      if (variations.includes(normalizedHeader)) {
        mapping[fieldName] = header;
        break;
      }
    }
    
    // If no mapping found, use the header as-is if it matches our schema
    if (!mapping[normalizedHeader] && ["name", "phone", "company", "email"].includes(normalizedHeader)) {
      mapping[normalizedHeader] = header;
    }
  });
  
  return mapping;
}

/**
 * Parses a CSV file and returns structured contact data
 */
export function parseCSV(
  file: File,
  options: CSVValidationOptions = {}
): Promise<CSVParseResult> {
  const {
    requiredFields = ["name", "phone"],
    maxRows = 10000,
    allowEmptyFields = false,
  } = options;

  return new Promise((resolve) => {
    const result: CSVParseResult = {
      contacts: [],
      errors: [],
      totalRows: 0,
      validRows: 0,
    };

    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      transformHeader: (header: string) => header.trim(),
      complete: (parseResult) => {
        if (parseResult.errors.length > 0) {
          result.errors.push(
            ...parseResult.errors.map((error) => `Row ${error.row}: ${error.message}`)
          );
        }

        const data = parseResult.data as Record<string, any>[];
        result.totalRows = data.length;

        if (result.totalRows === 0) {
          result.errors.push("CSV file is empty or contains no valid data");
          resolve(result);
          return;
        }

        if (result.totalRows > maxRows) {
          result.errors.push(`CSV file contains too many rows. Maximum allowed: ${maxRows}`);
          resolve(result);
          return;
        }

        // Map headers to field names
        const headers = Object.keys(data[0] || {});
        const fieldMapping = mapHeaders(headers);

        // Check if required fields are present
        const missingFields = requiredFields.filter(field => !fieldMapping[field]);
        if (missingFields.length > 0) {
          result.errors.push(
            `Missing required columns: ${missingFields.join(", ")}. ` +
            `Available columns: ${headers.join(", ")}`
          );
          resolve(result);
          return;
        }

        // Process each row
        data.forEach((row, index) => {
          const rowNumber = index + 2; // +2 because CSV is 1-indexed and we skip header
          const contact: Partial<InsertContact> = {};
          const rowErrors: string[] = [];

          // Extract and validate name
          if (fieldMapping.name) {
            const name = row[fieldMapping.name]?.toString().trim();
            if (name) {
              contact.name = name;
            } else if (requiredFields.includes("name")) {
              rowErrors.push("Name is required");
            }
          }

          // Extract and validate phone
          if (fieldMapping.phone) {
            const phone = row[fieldMapping.phone]?.toString().trim();
            if (phone) {
              const validatedPhone = validatePhoneNumber(phone);
              if (validatedPhone) {
                contact.phone = validatedPhone;
              } else {
                rowErrors.push("Invalid phone number format");
              }
            } else if (requiredFields.includes("phone")) {
              rowErrors.push("Phone number is required");
            }
          }

          // Extract and validate company (optional)
          if (fieldMapping.company) {
            const company = row[fieldMapping.company]?.toString().trim();
            if (company) {
              contact.company = company;
            }
          }

          // Extract and validate email (optional)
          if (fieldMapping.email) {
            const email = row[fieldMapping.email]?.toString().trim();
            if (email) {
              const validatedEmail = validateEmail(email);
              if (validatedEmail) {
                contact.email = validatedEmail;
              } else {
                rowErrors.push("Invalid email format");
              }
            }
          }

          // Check if all required fields are present
          const hasAllRequired = requiredFields.every(field => 
            contact[field as keyof InsertContact] !== undefined
          );

          if (rowErrors.length > 0) {
            result.errors.push(`Row ${rowNumber}: ${rowErrors.join(", ")}`);
          } else if (hasAllRequired) {
            // Set default values for optional fields
            if (!contact.company) contact.company = "";
            if (!contact.email) contact.email = "";
            if (!contact.customFields) contact.customFields = null;
            if (contact.isWhatsAppVerified === undefined) contact.isWhatsAppVerified = false;

            result.contacts.push(contact as InsertContact);
            result.validRows++;
          } else if (!allowEmptyFields) {
            result.errors.push(`Row ${rowNumber}: Missing required fields`);
          }
        });

        resolve(result);
      },
      error: (error) => {
        result.errors.push(`Failed to parse CSV: ${error.message}`);
        resolve(result);
      },
    });
  });
}

/**
 * Generates a sample CSV template with proper headers
 */
export function generateCSVTemplate(): string {
  const headers = ["name", "phone", "company", "email"];
  const sampleData = [
    ["John Doe", "+1234567890", "Acme Corp", "john@acme.com"],
    ["Jane Smith", "+1234567891", "Tech Inc", "jane@tech.com"],
    ["Bob Johnson", "+1234567892", "Global LLC", "bob@global.com"],
  ];

  const csvContent = [
    headers.join(","),
    ...sampleData.map(row => row.join(","))
  ].join("\n");

  return csvContent;
}

/**
 * Downloads a CSV template file
 */
export function downloadCSVTemplate(filename: string = "contacts_template.csv"): void {
  const csvContent = generateCSVTemplate();
  const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
  const url = window.URL.createObjectURL(blob);
  
  const link = document.createElement("a");
  link.style.display = "none";
  link.href = url;
  link.download = filename;
  
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  
  window.URL.revokeObjectURL(url);
}

/**
 * Validates if a file is a valid CSV file
 */
export function validateCSVFile(file: File): { isValid: boolean; error?: string } {
  // Check file type
  const validTypes = [
    "text/csv",
    "application/csv",
    "text/comma-separated-values",
    "application/vnd.ms-excel",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
  ];

  const validExtensions = [".csv", ".xls", ".xlsx"];
  const fileExtension = file.name.toLowerCase().substring(file.name.lastIndexOf("."));

  if (!validTypes.includes(file.type) && !validExtensions.includes(fileExtension)) {
    return {
      isValid: false,
      error: "Invalid file type. Please upload a CSV, XLS, or XLSX file.",
    };
  }

  // Check file size (50MB limit)
  const maxSize = 50 * 1024 * 1024; // 50MB
  if (file.size > maxSize) {
    return {
      isValid: false,
      error: "File size too large. Maximum allowed size is 50MB.",
    };
  }

  return { isValid: true };
}
