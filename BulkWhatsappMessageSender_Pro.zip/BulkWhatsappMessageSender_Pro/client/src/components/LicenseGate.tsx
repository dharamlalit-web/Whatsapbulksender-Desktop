import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Shield, Key, CheckCircle, AlertTriangle, Clock, TrendingUp, Lock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";

interface LicenseStatus {
  totalSent: number;
  dailySent: number;
  dailyLimit: number;
  freeLimit: number;
  freeRemaining: number;
  hasKey: boolean;
  isExpired: boolean;
  isLicensed: boolean;
  blocked: boolean;
  blockReason: string | null;
  key: string | null;
  activatedAt: string | null;
  expiresAt: string | null;
}

export function useLicenseStatus() {
  return useQuery<LicenseStatus>({
    queryKey: ["/api/license/status"],
    refetchInterval: 30000,
  });
}

// ── Small status badge for the sidebar ────────────────────────────────────────
export function LicenseBadge() {
  const { data } = useLicenseStatus();
  if (!data) return null;

  if (data.isLicensed && !data.blocked) {
    return (
      <div className="flex items-center gap-1.5 text-xs text-emerald-400">
        <CheckCircle className="w-3 h-3" />
        <span>Licensed</span>
      </div>
    );
  }
  if (!data.isLicensed && !data.blocked) {
    const pct = Math.round(((data.freeLimit - data.freeRemaining) / data.freeLimit) * 100);
    return (
      <div className="text-xs text-slate-400">
        <div className="flex justify-between mb-0.5">
          <span>Free trial</span>
          <span>{data.freeRemaining} left</span>
        </div>
        <div className="w-full bg-slate-700 rounded-full h-1">
          <div
            className="bg-amber-400 h-1 rounded-full transition-all"
            style={{ width: `${pct}%` }}
          />
        </div>
      </div>
    );
  }
  return (
    <div className="flex items-center gap-1.5 text-xs text-red-400">
      <Lock className="w-3 h-3" />
      <span>Blocked</span>
    </div>
  );
}

// ── Full-screen blocking modal ─────────────────────────────────────────────────
export function LicenseGate({ children }: { children: React.ReactNode }) {
  const { data: license, isLoading } = useLicenseStatus();
  const qc = useQueryClient();
  const [keyInput, setKeyInput] = useState("");
  const [activateError, setActivateError] = useState<string | null>(null);
  const [activateSuccess, setActivateSuccess] = useState<string | null>(null);

  const activateMutation = useMutation({
    mutationFn: async (key: string) => {
      const res = await apiRequest("POST", "/api/license/activate", { key });
      return res.json();
    },
    onSuccess: (data) => {
      if (data.success) {
        const exp = data.expiresAt ? new Date(data.expiresAt).toLocaleDateString() : "?";
        setActivateSuccess(`✅ Activated! ${data.dailyLimit} messages/day until ${exp}`);
        setActivateError(null);
        setKeyInput("");
        qc.invalidateQueries({ queryKey: ["/api/license/status"] });
      } else {
        setActivateError(data.error || "Invalid key");
        setActivateSuccess(null);
      }
    },
    onError: () => {
      setActivateError("Activation failed. Please try again.");
    },
  });

  if (isLoading) return <>{children}</>;
  if (!license?.blocked) return <>{children}</>;

  const isTrial = !license.hasKey || license.isExpired;
  const isDailyLimit = license.isLicensed && license.blocked;

  const tiers = [
    { name: "Starter", daily: 200, duration: "30 days", price: "₹199/mo" },
    { name: "Basic",   daily: 500, duration: "30 days", price: "₹399/mo" },
    { name: "Pro",     daily: 1000, duration: "30 days", price: "₹699/mo" },
    { name: "Business",daily: 2000, duration: "30 days", price: "₹999/mo" },
    { name: "Unlimited",daily: 9999, duration: "1 year",  price: "₹4999/yr" },
  ];

  return (
    <>
      {children}
      {/* Blocking overlay */}
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/90 backdrop-blur-sm">
        <div className="w-full max-w-lg mx-4 bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl overflow-hidden">

          {/* Header */}
          <div className="bg-gradient-to-r from-slate-800 to-slate-900 border-b border-slate-700 px-6 py-5 flex items-start gap-4">
            <div className="w-11 h-11 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center flex-shrink-0 mt-0.5">
              {isDailyLimit ? (
                <Clock className="w-5 h-5 text-amber-400" />
              ) : (
                <Shield className="w-5 h-5 text-amber-400" />
              )}
            </div>
            <div>
              <h2 className="text-white font-semibold text-lg leading-tight">
                {isDailyLimit ? "Daily Limit Reached" : isTrial && license.isExpired ? "License Expired" : "Free Trial Ended"}
              </h2>
              <p className="text-slate-400 text-sm mt-1">{license.blockReason}</p>
            </div>
          </div>

          {/* Stats strip */}
          <div className="grid grid-cols-3 divide-x divide-slate-700/60 border-b border-slate-700/60 bg-slate-800/40">
            <div className="px-4 py-3 text-center">
              <p className="text-xl font-bold text-white">{license.totalSent.toLocaleString()}</p>
              <p className="text-xs text-slate-400 mt-0.5">Total sent</p>
            </div>
            <div className="px-4 py-3 text-center">
              <p className="text-xl font-bold text-white">{license.dailySent.toLocaleString()}</p>
              <p className="text-xs text-slate-400 mt-0.5">Sent today</p>
            </div>
            <div className="px-4 py-3 text-center">
              <p className="text-xl font-bold text-amber-400">
                {isDailyLimit ? "0" : license.freeRemaining.toLocaleString()}
              </p>
              <p className="text-xs text-slate-400 mt-0.5">
                {isDailyLimit ? "Daily remaining" : "Free remaining"}
              </p>
            </div>
          </div>

          <div className="p-6 space-y-5">
            {/* Key input */}
            <div>
              <label className="text-sm font-medium text-slate-300 flex items-center gap-2 mb-2">
                <Key className="w-4 h-4 text-amber-400" />
                Enter License Key
              </label>
              <div className="flex gap-2">
                <Input
                  placeholder="BSP-XXXXXXXX-XXXXXXXX"
                  value={keyInput}
                  onChange={(e) => {
                    setKeyInput(e.target.value.toUpperCase());
                    setActivateError(null);
                    setActivateSuccess(null);
                  }}
                  onKeyDown={(e) => e.key === "Enter" && keyInput.trim() && activateMutation.mutate(keyInput.trim())}
                  className="bg-slate-800 border-slate-600 text-white placeholder:text-slate-500 font-mono text-sm"
                  disabled={activateMutation.isPending}
                />
                <Button
                  onClick={() => activateMutation.mutate(keyInput.trim())}
                  disabled={!keyInput.trim() || activateMutation.isPending}
                  className="bg-amber-500 hover:bg-amber-400 text-slate-900 font-semibold shrink-0"
                >
                  {activateMutation.isPending ? "Checking…" : "Activate"}
                </Button>
              </div>
              {activateError && (
                <p className="text-red-400 text-sm mt-2 flex items-center gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5" /> {activateError}
                </p>
              )}
              {activateSuccess && (
                <p className="text-emerald-400 text-sm mt-2 flex items-center gap-1.5">
                  <CheckCircle className="w-3.5 h-3.5" /> {activateSuccess}
                </p>
              )}
            </div>

            {/* Tier cards */}
            <div>
              <p className="text-xs font-medium text-slate-400 uppercase tracking-wider mb-2.5 flex items-center gap-1.5">
                <TrendingUp className="w-3.5 h-3.5" />
                Available Plans
              </p>
              <div className="grid grid-cols-5 gap-1.5">
                {tiers.map((t) => (
                  <div
                    key={t.name}
                    className={`rounded-lg border p-2 text-center ${
                      t.name === "Pro"
                        ? "border-amber-500/60 bg-amber-500/5"
                        : "border-slate-700 bg-slate-800/50"
                    }`}
                  >
                    {t.name === "Pro" && (
                      <Badge className="bg-amber-500 text-slate-900 text-[10px] px-1.5 py-0 mb-1 font-bold">
                        POPULAR
                      </Badge>
                    )}
                    <p className="text-xs font-semibold text-white">{t.name}</p>
                    <p className="text-[11px] text-slate-300 mt-0.5">
                      {t.daily >= 9999 ? "Unlimited" : `${t.daily}/day`}
                    </p>
                    <p className="text-[10px] text-slate-400">{t.duration}</p>
                    <p className="text-[11px] text-amber-400 font-medium mt-1">{t.price}</p>
                  </div>
                ))}
              </div>
            </div>

            <a
              href="https://wa.me/919855123933?text=Hi%2C%20I%20want%20to%20buy%20a%20BulkSender%20Pro%20license%20key"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 w-full py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 transition-colors text-white font-semibold text-sm"
            >
              <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893A11.821 11.821 0 0020.885 3.785"/>
              </svg>
              Buy a Key on WhatsApp — +91 98551 23933
            </a>
          </div>
        </div>
      </div>
    </>
  );
}
