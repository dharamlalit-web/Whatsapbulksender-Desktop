import { useState, useEffect, useMemo } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { PaperPlaneIcon, ClockIcon, PersonIcon, CalendarIcon } from "@radix-ui/react-icons";
import { Tag } from "lucide-react";

const STANDARD_FIELDS = ["name", "phone", "email", "company"];

export default function MessageComposer() {
  const [message, setMessage] = useState("");
  const [campaignName, setCampaignName] = useState("");
  const [sendingPace, setSendingPace] = useState("medium");
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [selectedContacts, setSelectedContacts] = useState(0);
  const [scheduleEnabled, setScheduleEnabled] = useState(false);
  const [scheduledAt, setScheduledAt] = useState("");
  const { toast } = useToast();

  const { data: contacts } = useQuery<any[]>({
    queryKey: ["/api/contacts"],
    staleTime: 0,
    refetchOnMount: true,
  });

  const { data: templates } = useQuery({
    queryKey: ["/api/templates"],
  });

  const availableFields = useMemo(() => {
    const customKeys = new Set<string>();
    if (contacts && contacts.length > 0) {
      for (const contact of contacts) {
        const cf = contact.customFields as Record<string, string> | null;
        if (cf) Object.keys(cf).forEach(k => customKeys.add(k));
      }
    }
    return { standard: STANDARD_FIELDS, custom: Array.from(customKeys) };
  }, [contacts]);

  const sampleContact = useMemo(() => {
    if (contacts && contacts.length > 0) return contacts[0];
    return { name: "John Doe", phone: "+911234567890", email: "john@example.com", company: "Acme Corp", customFields: {} };
  }, [contacts]);

  // Create + optionally start campaign
  const createCampaignMutation = useMutation({
    mutationFn: async (data: any) => {
      const resp = await apiRequest("POST", "/api/campaigns", data);
      const created = await resp.json();
      // Only start immediately if not scheduled
      if (!data.scheduledAt) {
        await apiRequest("POST", `/api/campaigns/${created.id}/start`);
      }
      return created;
    },
    onSuccess: (_data, variables) => {
      queryClient.invalidateQueries({ queryKey: ["/api/campaigns"] });
      queryClient.invalidateQueries({ queryKey: ["/api/campaigns/active"] });
      setShowSuccessModal(true);
      setMessage("");
      setCampaignName("");
      setScheduleEnabled(false);
      setScheduledAt("");
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to create campaign", variant: "destructive" });
    },
  });

  useEffect(() => {
    if (contacts) setSelectedContacts(contacts.length);
  }, [contacts]);

  const getEstimatedTime = () => {
    if (selectedContacts === 0) return "0 minutes";
    const paceTiming = { slow: 45, medium: 22.5, fast: 10 };
    const totalMinutes = Math.ceil((selectedContacts * paceTiming[sendingPace as keyof typeof paceTiming]) / 60);
    return `~${totalMinutes} minutes`;
  };

  const getPreviewMessage = () => {
    if (!message) return "Hi {{name}}, welcome to {{company}}! We're excited to have you on board.";
    let preview = message
      .replace(/\{\{name\}\}/gi, sampleContact.name || "John Doe")
      .replace(/\{\{phone\}\}/gi, sampleContact.phone || "+911234567890")
      .replace(/\{\{email\}\}/gi, sampleContact.email || "john@example.com")
      .replace(/\{\{company\}\}/gi, sampleContact.company || "Acme Corp");
    const cf = sampleContact.customFields as Record<string, string> | null;
    if (cf) {
      for (const [key, value] of Object.entries(cf)) {
        preview = preview.replace(new RegExp(`\\{\\{${key}\\}\\}`, "gi"), value || "");
      }
    }
    return preview;
  };

  const insertVariable = (variable: string) => {
    const textarea = document.querySelector('textarea[data-testid="textarea-message"]') as HTMLTextAreaElement;
    if (textarea) {
      const start = textarea.selectionStart;
      const end = textarea.selectionEnd;
      const token = `{{${variable}}}`;
      const newMessage = message.slice(0, start) + token + message.slice(end);
      setMessage(newMessage);
      setTimeout(() => {
        textarea.focus();
        textarea.setSelectionRange(start + token.length, start + token.length);
      }, 0);
    } else {
      setMessage(prev => prev + `{{${variable}}}`);
    }
  };

  const handleStartCampaign = () => {
    if (!message.trim()) {
      toast({ title: "Error", description: "Please enter a message", variant: "destructive" });
      return;
    }
    if (!campaignName.trim()) {
      toast({ title: "Error", description: "Please enter a campaign name", variant: "destructive" });
      return;
    }
    if (selectedContacts === 0) {
      toast({ title: "Error", description: "No contacts available. Please upload a CSV first.", variant: "destructive" });
      return;
    }
    if (scheduleEnabled && !scheduledAt) {
      toast({ title: "Error", description: "Please pick a date and time to schedule", variant: "destructive" });
      return;
    }
    if (scheduleEnabled && new Date(scheduledAt) <= new Date()) {
      toast({ title: "Error", description: "Scheduled time must be in the future", variant: "destructive" });
      return;
    }

    createCampaignMutation.mutate({
      name: campaignName,
      message,
      sendingPace,
      totalContacts: selectedContacts,
      contactIds: contacts?.map((c: any) => c.id) || [],
      scheduledAt: scheduleEnabled ? new Date(scheduledAt).toISOString() : undefined,
    });
  };

  const isScheduled = scheduleEnabled && !!scheduledAt;

  return (
    <>
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold">Compose Message</h3>
          </div>

          {/* Variable insertion bar */}
          <div className="mb-4 p-3 bg-muted/50 rounded-lg border border-border">
            <div className="flex items-center gap-2 mb-2">
              <Tag className="h-3.5 w-3.5 text-muted-foreground" />
              <span className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Insert Variable</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {availableFields.standard.map((field) => (
                <button
                  key={field}
                  onClick={() => insertVariable(field)}
                  data-testid={`button-variable-${field}`}
                  className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-mono font-medium bg-primary/10 text-primary hover:bg-primary/20 transition-colors border border-primary/20 cursor-pointer"
                >
                  {`{{${field}}}`}
                </button>
              ))}
              {availableFields.custom.length > 0 && (
                <>
                  <span className="self-center text-muted-foreground text-xs">|</span>
                  {availableFields.custom.map((field) => (
                    <button
                      key={field}
                      onClick={() => insertVariable(field)}
                      data-testid={`button-variable-custom-${field}`}
                      className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-mono font-medium bg-amber-500/10 text-amber-700 dark:text-amber-400 hover:bg-amber-500/20 transition-colors border border-amber-500/20 cursor-pointer"
                    >
                      {`{{${field}}}`}
                    </button>
                  ))}
                </>
              )}
              {availableFields.custom.length === 0 && contacts && contacts.length > 0 && (
                <span className="text-xs text-muted-foreground self-center">Upload a CSV with extra columns to get more variables</span>
              )}
              {(!contacts || contacts.length === 0) && (
                <span className="text-xs text-muted-foreground self-center">Upload contacts to enable personalization</span>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <Label htmlFor="message">Message Content</Label>
                <Textarea
                  id="message"
                  className="mt-2 min-h-36 resize-none font-mono text-sm"
                  placeholder={`Hi {{name}}, welcome to {{company}}!\n\nClick the variable buttons above to personalize your message.`}
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  data-testid="textarea-message"
                />
                <div className="flex justify-between items-center mt-2 text-xs text-muted-foreground">
                  <span>Click any tag above to insert at cursor position</span>
                  <span data-testid="text-character-count">{message.length}/1000</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="pace">Sending Pace</Label>
                  <Select value={sendingPace} onValueChange={setSendingPace}>
                    <SelectTrigger id="pace" className="mt-2" data-testid="select-pace">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="slow">Slow (30–60s)</SelectItem>
                      <SelectItem value="medium">Medium (15–30s)</SelectItem>
                      <SelectItem value="fast">Fast (5–15s)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="campaign-name">Campaign Name</Label>
                  <Input
                    id="campaign-name"
                    className="mt-2"
                    placeholder="e.g. July Promo"
                    value={campaignName}
                    onChange={(e) => setCampaignName(e.target.value)}
                    data-testid="input-campaign-name"
                  />
                </div>
              </div>

              {/* Schedule toggle */}
              <div className="p-3 border border-border rounded-lg space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <CalendarIcon className="h-4 w-4 text-accent" />
                    <Label htmlFor="schedule-toggle" className="cursor-pointer font-medium">
                      Schedule for later
                    </Label>
                  </div>
                  <Switch
                    id="schedule-toggle"
                    checked={scheduleEnabled}
                    onCheckedChange={setScheduleEnabled}
                    data-testid="switch-schedule"
                  />
                </div>
                {scheduleEnabled && (
                  <div>
                    <Label htmlFor="scheduled-at" className="text-xs text-muted-foreground">Send at date & time</Label>
                    <Input
                      id="scheduled-at"
                      type="datetime-local"
                      className="mt-1"
                      value={scheduledAt}
                      onChange={(e) => setScheduledAt(e.target.value)}
                      min={(() => { const now = new Date(Date.now() + 60000); return new Date(now.getTime() - now.getTimezoneOffset() * 60000).toISOString().slice(0, 16); })()}
                      data-testid="input-scheduled-at"
                    />
                    <p className="text-xs text-muted-foreground mt-1">
                      Campaign will start automatically at this time
                    </p>
                  </div>
                )}
              </div>
            </div>

            {/* Live preview */}
            <div>
              <Label>Preview <span className="text-xs text-muted-foreground font-normal ml-1">(using first contact's data)</span></Label>
              <div className="mt-2 bg-muted p-4 rounded-lg min-h-36 flex flex-col justify-between">
                <div className="message-bubble bg-primary text-primary-foreground p-3 rounded-lg rounded-br-none max-w-xs ml-auto">
                  <p className="text-sm whitespace-pre-wrap" data-testid="text-message-preview">
                    {getPreviewMessage()}
                  </p>
                  <div className="flex items-center justify-end mt-2 text-xs opacity-70">
                    <span>{new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</span>
                    <svg className="ml-1 h-3 w-3" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                    <svg className="ml-0.5 h-3 w-3" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                  </div>
                </div>
                {availableFields.custom.length > 0 && (
                  <div className="mt-3 text-xs text-muted-foreground">
                    <span className="font-medium">CSV fields:</span>{" "}
                    {[...availableFields.standard, ...availableFields.custom].join(", ")}
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between mt-6 pt-6 border-t border-border">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <PersonIcon className="h-4 w-4 text-primary" />
                <span className="text-sm font-medium" data-testid="text-selected-contacts">
                  {selectedContacts} contacts selected
                </span>
              </div>
              <div className="flex items-center space-x-2">
                <ClockIcon className="h-4 w-4 text-accent" />
                <span className="text-sm text-muted-foreground" data-testid="text-estimated-time">
                  {getEstimatedTime()} estimated
                </span>
              </div>
            </div>

            <div className="flex items-center space-x-3">
              <Button variant="outline" data-testid="button-save-draft">Save Draft</Button>
              <Button
                onClick={handleStartCampaign}
                disabled={createCampaignMutation.isPending}
                data-testid="button-start-campaign"
                variant={isScheduled ? "outline" : "default"}
                className={isScheduled ? "border-accent text-accent hover:bg-accent/10" : ""}
              >
                {isScheduled ? (
                  <><CalendarIcon className="mr-2 h-4 w-4" />{createCampaignMutation.isPending ? "Scheduling..." : "Schedule Campaign"}</>
                ) : (
                  <><PaperPlaneIcon className="mr-2 h-4 w-4" />{createCampaignMutation.isPending ? "Starting..." : "Start Campaign"}</>
                )}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Success Modal */}
      <Dialog open={showSuccessModal} onOpenChange={setShowSuccessModal}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="text-center">
              <div className="w-16 h-16 bg-secondary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-secondary" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                </svg>
              </div>
              {isScheduled ? "Campaign Scheduled!" : "Campaign Started!"}
            </DialogTitle>
          </DialogHeader>
          <div className="text-center space-y-4">
            <p className="text-muted-foreground">
              {isScheduled
                ? "Your campaign is scheduled and will start automatically at the set time."
                : "Your campaign is running. Track progress in the active campaign bar above."}
            </p>
            <div className="bg-muted p-4 rounded-lg text-left text-sm space-y-1">
              <div className="flex justify-between"><span>Total contacts:</span><span className="font-medium">{selectedContacts}</span></div>
              <div className="flex justify-between"><span>Estimated time:</span><span className="font-medium">{getEstimatedTime()}</span></div>
              <div className="flex justify-between"><span>Sending pace:</span><span className="font-medium capitalize">{sendingPace}</span></div>
              {isScheduled && scheduledAt && (
                <div className="flex justify-between"><span>Scheduled at:</span><span className="font-medium">{new Date(scheduledAt).toLocaleString()}</span></div>
              )}
            </div>
            <Button className="w-full" onClick={() => setShowSuccessModal(false)} data-testid="button-close-modal">
              Got it!
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
