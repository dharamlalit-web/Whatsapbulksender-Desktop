import { useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useQueryClient } from "@tanstack/react-query";
import {
  LayoutDashboard,
  Upload,
  Users,
  MessageSquare,
  FileText,
  BarChart2,
  Settings,
  Smartphone,
  Wifi,
  WifiOff,
  Loader2,
} from "lucide-react";
import { LicenseBadge } from "@/components/LicenseGate";

type ConnectionStatus = "disconnected" | "initializing" | "qr_ready" | "connected" | "auth_failed";

const navigation = [
  { name: "Dashboard", href: "/", icon: LayoutDashboard },
  { name: "Upload Contacts", href: "/contacts", icon: Upload },
  { name: "Send Messages", href: "/campaigns", icon: MessageSquare },
  { name: "Templates", href: "/templates", icon: FileText },
  { name: "Analytics", href: "/analytics", icon: BarChart2 },
  { name: "WhatsApp", href: "/whatsapp", icon: Smartphone },
  { name: "Settings", href: "/settings", icon: Settings },
];

function WhatsAppStatusDot({ status }: { status: ConnectionStatus }) {
  if (status === "connected") return <span className="w-2 h-2 rounded-full bg-green-500 inline-block" />;
  if (status === "initializing" || status === "qr_ready") return <Loader2 className="w-3 h-3 animate-spin text-yellow-500" />;
  return <span className="w-2 h-2 rounded-full bg-red-400 inline-block" />;
}

export default function Sidebar() {
  const [location, navigate] = useLocation();
  const queryClient = useQueryClient();
  const [wsStatus, setWsStatus] = useState<ConnectionStatus | null>(null);

  const { data: waState } = useQuery<{ status: ConnectionStatus; phoneNumber: string | null }>({
    queryKey: ["/api/whatsapp/status"],
    refetchInterval: 5000,
  });

  const status: ConnectionStatus = wsStatus ?? waState?.status ?? "disconnected";

  useEffect(() => {
    const protocol = window.location.protocol === "https:" ? "wss" : "ws";
    const ws = new WebSocket(`${protocol}://${window.location.host}/ws`);

    ws.onmessage = (e) => {
      try {
        const msg = JSON.parse(e.data);
        if (msg.type === "whatsapp_status") {
          setWsStatus(msg.data.status);
          queryClient.invalidateQueries({ queryKey: ["/api/whatsapp/status"] });
        }
      } catch (_) {}
    };

    return () => ws.close();
  }, [queryClient]);

  return (
    <aside className="w-64 bg-card border-r border-border flex flex-col">
      <div className="p-6 border-b border-border">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
            <svg className="w-6 h-6 text-primary-foreground" fill="currentColor" viewBox="0 0 24 24">
              <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893A11.821 11.821 0 0020.885 3.785" />
            </svg>
          </div>
          <div>
            <h1 className="font-bold text-lg" data-testid="app-title">BulkSender Pro</h1>
            <p className="text-xs text-muted-foreground">WhatsApp Automation</p>
          </div>
        </div>
      </div>

      <nav className="flex-1 p-4 space-y-1">
        {navigation.map((item) => {
          const isActive =
            location === item.href ||
            (item.href !== "/" && location.startsWith(item.href));

          return (
            <button
              key={item.name}
              onClick={() => navigate(item.href)}
              className={cn(
                "w-full flex items-center space-x-3 px-4 py-3 rounded-md transition-colors text-left",
                isActive
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:text-foreground hover:bg-muted"
              )}
              data-testid={`nav-${item.name.toLowerCase().replace(/\s+/g, "-")}`}
            >
              <item.icon className="w-5 h-5 flex-shrink-0" />
              <span className="font-medium flex-1">{item.name}</span>
              {item.name === "WhatsApp" && (
                <WhatsAppStatusDot status={status} />
              )}
            </button>
          );
        })}
      </nav>

      {/* WhatsApp connection status footer */}
      <div className="p-4 border-t border-border space-y-2">
        <div className="px-1 pb-1">
          <LicenseBadge />
        </div>
        <button
          onClick={() => navigate("/whatsapp")}
          className={cn(
            "w-full flex items-center space-x-2 px-3 py-2 rounded-md text-sm transition-colors",
            status === "connected"
              ? "bg-green-50 text-green-700 dark:bg-green-950/30 dark:text-green-400"
              : "bg-muted text-muted-foreground hover:bg-muted/80"
          )}
          data-testid="status-whatsapp-connection"
        >
          {status === "connected" ? (
            <Wifi className="w-4 h-4 text-green-500" />
          ) : status === "initializing" || status === "qr_ready" ? (
            <Loader2 className="w-4 h-4 animate-spin text-yellow-500" />
          ) : (
            <WifiOff className="w-4 h-4 text-red-400" />
          )}
          <span className="flex-1 font-medium">
            {status === "connected"
              ? "WhatsApp Connected"
              : status === "initializing"
              ? "Connecting…"
              : status === "qr_ready"
              ? "Scan QR Code"
              : "Not Connected"}
          </span>
        </button>
      </div>
    </aside>
  );
}
