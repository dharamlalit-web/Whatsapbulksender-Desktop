import { useState, useCallback } from "react";
import { useDropzone } from "react-dropzone";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { UploadIcon, FileIcon, DownloadIcon, Cross1Icon, CheckCircledIcon } from "@radix-ui/react-icons";

export default function UploadArea() {
  const { toast } = useToast();

  const { data: contactLists = [] } = useQuery<any[]>({
    queryKey: ["/api/contact-lists"],
    staleTime: 0,
    refetchOnMount: true,
  });

  const uploadMutation = useMutation({
    mutationFn: async (file: File) => {
      // Read file as text on the client, send as JSON — avoids multipart proxy issues
      const text = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = (e) => resolve(e.target?.result as string);
        reader.onerror = () => reject(new Error("Failed to read file"));
        reader.readAsText(file, "utf-8");
      });
      const res = await fetch("/api/contacts/bulk", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ csv: text, filename: file.name }),
      });
      const data = await res.json().catch(() => null);
      if (!res.ok) {
        throw new Error((data && data.error) || `Upload failed (${res.status})`);
      }
      return data as { contactsCreated: number; contactsAdded: number };
    },
    onSuccess: async (result) => {
      await queryClient.invalidateQueries({ queryKey: ["/api/contacts"] });
      await queryClient.invalidateQueries({ queryKey: ["/api/contact-lists"] });
      await queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      toast({
        title: "Upload successful",
        description: `${result?.contactsCreated ?? 0} contacts imported and ready to use.`,
      });
    },
    onError: (err: any) => {
      toast({
        title: "Upload failed",
        description: err.message || "Please check your file format and try again.",
        variant: "destructive",
      });
    },
  });

  const deleteListMutation = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/contact-lists/${id}`),
    onSuccess: async () => {
      await queryClient.refetchQueries({ queryKey: ["/api/contact-lists"] });
      await queryClient.refetchQueries({ queryKey: ["/api/stats"] });
      toast({ title: "Removed", description: "Contact list deleted." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to delete list.", variant: "destructive" });
    },
  });

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (file) uploadMutation.mutate(file);
  }, [uploadMutation]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'text/csv': ['.csv'],
      'application/vnd.ms-excel': ['.xls'],
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ['.xlsx'],
    },
    maxFiles: 1,
    maxSize: 50 * 1024 * 1024,
  });

  const downloadTemplate = () => {
    const csvContent = "name,phone,company,email\nLalit Kumar,9855123933,Acme Corp,lalit@acme.com\nSeema Sharma,7888623100,Tech Inc,seema@tech.com";
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.style.display = 'none';
    a.href = url;
    a.download = 'contacts_template.csv';
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    document.body.removeChild(a);
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Upload Contact List</CardTitle>
          <Button variant="ghost" size="sm" onClick={downloadTemplate} data-testid="button-download-template">
            <DownloadIcon className="h-4 w-4 mr-2" />
            CSV Template
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">

        {/* Dropzone */}
        <div
          {...getRootProps()}
          className={cn(
            "border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-all",
            "hover:border-primary/50 hover:bg-muted/50",
            isDragActive && "border-primary bg-primary/5",
            uploadMutation.isPending && "opacity-50 cursor-not-allowed"
          )}
          data-testid="upload-dropzone"
        >
          <input {...getInputProps()} />
          <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
            <UploadIcon className="h-8 w-8 text-muted-foreground" />
          </div>

          {uploadMutation.isPending ? (
            <div className="space-y-2">
              <h4 className="font-semibold">Processing file...</h4>
              <div className="w-32 h-2 bg-muted rounded-full mx-auto overflow-hidden">
                <div className="h-full bg-primary rounded-full animate-pulse"></div>
              </div>
            </div>
          ) : (
            <>
              <h4 className="font-semibold mb-2">
                {isDragActive ? "Drop your CSV file here" : "Drop your CSV file here"}
              </h4>
              <p className="text-muted-foreground text-sm mb-4">or click to browse files</p>
              <div className="flex items-center justify-center space-x-4 text-xs text-muted-foreground">
                <span>Supports: CSV, Excel</span>
                <span>•</span>
                <span>Max: 50MB</span>
              </div>
            </>
          )}
        </div>

        {/* Uploaded Lists (from server) */}
        {contactLists.length > 0 && (
          <div className="space-y-3">
            <h4 className="font-semibold text-sm">Uploaded Files</h4>
            {contactLists.map((list: any) => (
              <div
                key={list.id}
                className="flex items-center justify-between p-4 bg-muted rounded-lg"
                data-testid={`uploaded-file-${list.id}`}
              >
                <div className="flex items-center space-x-3">
                  <FileIcon className="h-8 w-8 text-secondary" />
                  <div>
                    <p className="font-medium">{list.name}</p>
                    <p className="text-sm text-muted-foreground">
                      {list.contactCount} contacts • {new Date(list.uploadedAt).toLocaleString()}
                    </p>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Badge className="bg-secondary text-secondary-foreground">
                    <CheckCircledIcon className="mr-1 h-3 w-3" />
                    Imported
                  </Badge>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => deleteListMutation.mutate(list.id)}
                    disabled={deleteListMutation.isPending}
                    data-testid={`button-remove-${list.id}`}
                  >
                    <Cross1Icon className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
