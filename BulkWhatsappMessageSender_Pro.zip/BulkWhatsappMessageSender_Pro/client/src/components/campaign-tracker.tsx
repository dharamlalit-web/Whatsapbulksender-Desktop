import { useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useWebSocket } from "@/hooks/use-websocket";
import { type Campaign } from "@shared/schema";
import { PauseIcon } from "@radix-ui/react-icons";
import { formatDistanceToNow } from "date-fns";

interface CampaignTrackerProps {
  campaigns: Campaign[];
}

export default function CampaignTracker({ campaigns }: CampaignTrackerProps) {
  const { toast } = useToast();
  const { lastMessage } = useWebSocket();

  const pauseCampaignMutation = useMutation({
    mutationFn: (id: string) => apiRequest("POST", `/api/campaigns/${id}/pause`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/campaigns/active"] });
      queryClient.invalidateQueries({ queryKey: ["/api/campaigns"] });
      toast({
        title: "Success",
        description: "Campaign paused successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to pause campaign",
        variant: "destructive",
      });
    },
  });

  // Handle real-time updates
  useEffect(() => {
    if (lastMessage) {
      try {
        const data = JSON.parse(lastMessage);
        
        if (data.type === "campaign_progress") {
          queryClient.invalidateQueries({ queryKey: ["/api/campaigns/active"] });
          queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
        } else if (data.type === "campaign_completed") {
          toast({
            title: "Campaign Completed",
            description: `Campaign "${data.data.name}" has finished successfully.`,
          });
          queryClient.invalidateQueries({ queryKey: ["/api/campaigns/active"] });
          queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
        }
      } catch (error) {
        console.error("Error parsing WebSocket message:", error);
      }
    }
  }, [lastMessage, queryClient, toast]);

  const getProgressPercentage = (campaign: Campaign) => {
    if (campaign.totalContacts === 0) return 0;
    return Math.round((campaign.sentCount / campaign.totalContacts) * 100);
  };

  const getEstimatedTimeRemaining = (campaign: Campaign) => {
    const remaining = campaign.totalContacts - campaign.sentCount;
    if (remaining <= 0) return "Complete";
    
    const paceTiming = {
      slow: 45,
      medium: 22.5,
      fast: 10,
    };
    
    const secondsPerMessage = paceTiming[campaign.sendingPace as keyof typeof paceTiming] || 22.5;
    const totalMinutes = Math.ceil((remaining * secondsPerMessage) / 60);
    
    return `~${totalMinutes} min remaining`;
  };

  if (!campaigns || campaigns.length === 0) {
    return null;
  }

  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold">Active Campaigns</h3>
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-secondary rounded-full animate-pulse"></div>
            <span className="text-sm text-muted-foreground">Live tracking</span>
          </div>
        </div>
        
        <div className="space-y-4">
          {campaigns.map((campaign) => (
            <div 
              key={campaign.id} 
              className="border border-border rounded-lg p-4"
              data-testid={`active-campaign-${campaign.id}`}
            >
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <div className="w-3 h-3 bg-secondary rounded-full"></div>
                  <div>
                    <h4 className="font-semibold">{campaign.name}</h4>
                    <p className="text-sm text-muted-foreground">
                      {campaign.startedAt 
                        ? `Started ${formatDistanceToNow(new Date(campaign.startedAt))} ago`
                        : "Preparing to start"
                      }
                    </p>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="text-right">
                    <p className="text-sm font-medium" data-testid={`progress-${campaign.id}`}>
                      {campaign.sentCount} / {campaign.totalContacts}
                    </p>
                    <p className="text-xs text-muted-foreground">messages sent</p>
                  </div>
                  {campaign.status === "running" && (
                    <Button
                      size="sm"
                      variant="outline"
                      className="text-destructive hover:text-destructive"
                      onClick={() => pauseCampaignMutation.mutate(campaign.id)}
                      disabled={pauseCampaignMutation.isPending}
                      data-testid={`button-pause-${campaign.id}`}
                    >
                      <PauseIcon className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              </div>
              
              {/* Stats Grid */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
                <div className="text-center">
                  <div className="text-lg font-bold status-delivered" data-testid={`delivered-${campaign.id}`}>
                    {campaign.deliveredCount}
                  </div>
                  <div className="text-xs text-muted-foreground">Delivered</div>
                </div>
                <div className="text-center">
                  <div className="text-lg font-bold status-sent" data-testid={`sent-${campaign.id}`}>
                    {campaign.sentCount - campaign.deliveredCount}
                  </div>
                  <div className="text-xs text-muted-foreground">Sent</div>
                </div>
                <div className="text-center">
                  <div className="text-lg font-bold status-failed" data-testid={`failed-${campaign.id}`}>
                    {campaign.failedCount}
                  </div>
                  <div className="text-xs text-muted-foreground">Failed</div>
                </div>
                <div className="text-center">
                  <div className="text-lg font-bold status-pending" data-testid={`pending-${campaign.id}`}>
                    {campaign.totalContacts - campaign.sentCount}
                  </div>
                  <div className="text-xs text-muted-foreground">Pending</div>
                </div>
              </div>
              
              {/* Progress Bar */}
              <div className="space-y-2">
                <Progress value={getProgressPercentage(campaign)} className="h-3" />
                <div className="flex justify-between items-center text-xs text-muted-foreground">
                  <span data-testid={`percentage-${campaign.id}`}>
                    {getProgressPercentage(campaign)}% complete
                  </span>
                  {campaign.status === "running" && (
                    <span data-testid={`eta-${campaign.id}`}>
                      {getEstimatedTimeRemaining(campaign)}
                    </span>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
