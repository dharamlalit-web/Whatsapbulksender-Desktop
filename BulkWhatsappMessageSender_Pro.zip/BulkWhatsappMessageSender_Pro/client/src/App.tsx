import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Dashboard from "@/pages/dashboard";
import Contacts from "@/pages/contacts";
import Templates from "@/pages/templates";
import Campaigns from "@/pages/campaigns";
import WhatsAppConnect from "@/pages/whatsapp-connect";
import Settings from "@/pages/settings";
import Analytics from "@/pages/analytics";
import NotFound from "@/pages/not-found";
import Sidebar from "@/components/sidebar";
import { LicenseGate } from "@/components/LicenseGate";

function Router() {
  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar />
      <main className="flex-1 flex flex-col overflow-hidden">
        <Switch>
          <Route path="/" component={Dashboard} />
          <Route path="/contacts" component={Contacts} />
          <Route path="/templates" component={Templates} />
          <Route path="/campaigns" component={Campaigns} />
          <Route path="/analytics" component={Analytics} />
          <Route path="/whatsapp" component={WhatsAppConnect} />
          <Route path="/settings" component={Settings} />
          <Route component={NotFound} />
        </Switch>
      </main>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <LicenseGate>
          <Router />
        </LicenseGate>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
