#!/bin/bash
set -e

echo "[post-merge] Installing dependencies..."
npm install --prefer-offline

echo "[post-merge] Done."
